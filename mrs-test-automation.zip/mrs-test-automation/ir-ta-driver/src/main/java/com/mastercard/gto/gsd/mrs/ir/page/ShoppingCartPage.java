package com.mastercard.gto.gsd.mrs.ir.page;

import com.mastercard.gto.gsd.mrs.ir.component.*;

import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;

@Component
public class ShoppingCartPage extends AbstractPage {
	
	@Autowired
	ViewShoppingCartLoggedInComponent viewShoppingCartLoggedInComponent;

	@Autowired
	CheckoutLoggedInComponent checkoutLoggedInComponent;

	@Autowired
	ShippingAddressSelectionModalComponent shippingAddressSelectionModalComponent;

	@Autowired
	ShippingAddressInclusionModalComponent shippingAddressInclusionModalComponent;
	
	@Autowired
	ReviewOrderInformationLoggedInComponent reviewOrderInformationLoggedInComponent;
	
	@Autowired
	CompleteCheckoutComponent completeCheckoutComponent;
	
	@Autowired
	CompleteCheckoutConfirmationComponent completeCheckoutConfirmationComponent;
	
	
	/**
	 * @return the viewShoppingCartLoggedInComponent
	 */
	public ViewShoppingCartLoggedInComponent getViewShoppingCartLoggedInComponent() {
		return viewShoppingCartLoggedInComponent;
	}

	/**
	 * @return the checkoutLoggedInComponent
	 */
	public CheckoutLoggedInComponent getCheckoutLoggedInComponent() {
		return checkoutLoggedInComponent;
	}

	/**
	 * @return the shippingAddressSelectionModalComponent
	 */
	public ShippingAddressSelectionModalComponent getShippingAddressSelectionModalComponent() {
		return shippingAddressSelectionModalComponent;
	}

	/**
	 * @return the shippingAddressInclusionModalComponent
	 */
	public ShippingAddressInclusionModalComponent getShippingAddressInclusionModalComponent() {
		return shippingAddressInclusionModalComponent;
	}
	
	

	/**
	 * @return the reviewOrderInformationLoggedInComponent
	 */
	public ReviewOrderInformationLoggedInComponent getReviewOrderInformationLoggedInComponent() {
		return reviewOrderInformationLoggedInComponent;
	}

	/**
	 * @return the completeCheckoutConfirmationComponent
	 */
	public CompleteCheckoutConfirmationComponent getCompleteCheckoutConfirmationComponent() {
		return completeCheckoutConfirmationComponent;
	}

	/**
	 * @return the completeCheckoutComponent
	 */
	public CompleteCheckoutComponent getCompleteCheckoutComponent() {
		return completeCheckoutComponent;
	}

	public void navigateToPage(String url){
		getFinder().getWebDriver().get(url);
		log.info("Hitting url :" + url);
	}
	
	public String getCurrentUrl(){
		log.info("Current URL : " + getFinder().getWebDriver().getCurrentUrl());
		return getFinder().getWebDriver().getCurrentUrl();
	}
	

	@Override
	protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		Collection<ExpectedCondition<WebElement>> conditions = new ArrayList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"offer_offer_highlight\"]/li[1]/a")));
		return conditions;
	}

}
