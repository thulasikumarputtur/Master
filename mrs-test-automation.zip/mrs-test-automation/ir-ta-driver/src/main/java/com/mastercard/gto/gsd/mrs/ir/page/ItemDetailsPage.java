package com.mastercard.gto.gsd.mrs.ir.page;

import com.mastercard.gto.gsd.mrs.ir.component.ItemDetailsLoggedInComponent;

import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;

@Component
public class ItemDetailsPage extends AbstractPage {
	
	@Autowired
	ItemDetailsLoggedInComponent itemDetailsLoggedInComponent;
	
	/**
	 * @return the itemDetailsLoggedInComponent
	 */
	public ItemDetailsLoggedInComponent getItemDetailsLoggedInComponent() {
		return itemDetailsLoggedInComponent;
	}

	public void navigateToPage(String url){
		getFinder().getWebDriver().get(url);
		log.info("Hitting url :" + url);
	}
	
	public String getCurrentUrl(){
		log.info("Current URL : " + getFinder().getWebDriver().getCurrentUrl());
		return getFinder().getWebDriver().getCurrentUrl();
	}
	

	@Override
	protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		Collection<ExpectedCondition<WebElement>> conditions = new ArrayList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"offer_offer_highlight\"]/li[1]/a")));
		return conditions;
	}

}
