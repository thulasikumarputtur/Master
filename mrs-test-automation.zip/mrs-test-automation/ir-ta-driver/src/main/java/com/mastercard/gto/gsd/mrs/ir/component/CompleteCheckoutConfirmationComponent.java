package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
/**
 * @author e040514
 * 
 */

@Component
public class CompleteCheckoutConfirmationComponent extends AbstractComponent {
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='form_checkout_confirmation_2']/fieldset/p[2]")
	private MCWebElement checkoutConfirmationText;
	
	@PageElement(findBy = FindBy.ID, valueToFind = "okSubmit")
	private MCWebElement okSubmitButton;

	public boolean verifyCheckoutCompleteFormText(String verifyText){
		log.info("Verifying checkout confirmation page text :"+ checkoutConfirmationText.getText());
		
		return checkoutConfirmationText.getText().contains(verifyText);
	}
	
	public void clickOkSubmitButton(){
		okSubmitButton.click();
		log.info("Clicked ok submit button");
	}
	
	@Override
	public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='form_checkout_confirmation_2']/fieldset/p[2]")));
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("okSubmit")));
		return conditions;
	}

	

	
}
