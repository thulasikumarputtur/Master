package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

@Component
public class LoginFormNoQuestionComponent extends AbstractComponent {
	
    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//div[@id='fancybox-content']/div/header/h3")
    private MCWebElement pageTitle;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_submit")
    private MCWebElement submitButton;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_cancel")
    private MCWebElement cancelButton;
    
    @PageElement(findBy = FindBy.CLASS, valueToFind = "error")
    private MCWebElement errorMessage;
    

    /**
     * @return the errorMessage
     */
    public MCWebElement getErrorMessage() {
        return errorMessage;
    }

    /**
     * @return the pageTitle
     */
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

	
    
	public void clickSubmitButton(){
		submitButton.click();
		log.info("Clicked on Submit button");
	}

	@Override
	public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_submit")));
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_cancel")));
		return conditions;
	}
	
}
