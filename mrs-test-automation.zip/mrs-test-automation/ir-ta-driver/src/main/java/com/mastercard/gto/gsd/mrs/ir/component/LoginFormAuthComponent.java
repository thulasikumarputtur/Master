package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

@Component
public class LoginFormAuthComponent extends AbstractComponent {

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//div[@id='fancybox-content']/div/header/h3")
    private MCWebElement pageTitle;

    @PageElement(findBy = FindBy.ID, valueToFind = "answer0")
    private MCWebElement answer0Input;

    @PageElement(findBy = FindBy.ID, valueToFind = "answer1")
    private MCWebElement answer1Input;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_submit")
    private MCWebElement submitButton;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_cancel")
    private MCWebElement cancelButton;
    
    @PageElement(findBy = FindBy.CLASS, valueToFind = "error")
    private MCWebElement errorMessage;


    /**
     * @return the errorMessage
     */
    public MCWebElement getErrorMessage() {
        return errorMessage;
    }

    /**
     * @return the pageTitle
     */
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    /**
     * @return the answer0Input
     */
    public MCWebElement getAnswer0Input() {
        return answer0Input;
    }

    /**
     * @return the answer1Input
     */
    public MCWebElement getAnswer1Input() {
        return answer1Input;
    }

    /**
     * @return the submitButton
     */
    public MCWebElement getSubmitButton() {
        return submitButton;
    }
    
    
    public void typeAnswer0(String answer0) {
        answer0Input.sendKeys(answer0);
        log.info("Typing answer 0: " + answer0);
    }
    
    public void typeAnswer1(String answer1) {
        answer1Input.sendKeys(answer1);
        log.info("Typing answer 1: " + answer1);
    }

    public void clickSubmit() {
        submitButton.click();
        log.info("Clicked on Submit Button.");
    }


    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("answer0")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("answer1")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_submit")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_cancel")));
        return conditions;
    }

}
