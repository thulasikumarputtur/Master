package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.element.MCWebElements;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

@Component
public class LoginFormAccountComponent extends AbstractComponent {
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//div[@id='fancybox-content']/div/header/h3")
	private MCWebElement pageTitle;
	
    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='form_login']/fieldset/div/div")
    private MCWebElements accountLoginFieldsContainer;
    
	@PageElement(findBy=FindBy.ID, valueToFind="bank_product_id")
	private MCWebElement accountTypeList;
	
	@PageElement(findBy=FindBy.ID, valueToFind="bank_account_num")
	private MCWebElement accountNumberInput;
	
	@PageElement(findBy=FindBy.ID, valueToFind="login_submit_account_num")
	private MCWebElement loginUsingAccountNumberButton;

	@PageElement(findBy = FindBy.ID, valueToFind = "status_msg")
	private MCWebElement statusMessage;
	
	/**
	 * @return the pageTitle
	 */
	public MCWebElement getPageTitle() {
		return pageTitle;
	}
	
	public void clickLoginUsingAccountNumberSubmitButton(){
		loginUsingAccountNumberButton.click();
		log.info("Clicked on loginUsingAccountNumberButton");
		
	}

	public MCWebElement getStatusMessage() {
		return statusMessage;
	}

    public boolean isAccountTypeListDisplayed() {
    	try {
    		return getFinder().getWebDriver().findElement(By.id("bank_product_id")).isDisplayed();
    	} catch (NoSuchElementException e) {
			return false;
		}
    }
    
	public void selectDropDownValue(String accountTypeName){
		accountTypeList.getSelect().selectByVisibleText(accountTypeName);
		log.info("Account Type List Name selected: "+accountTypeName);
	}
	
	public MCWebElement getAccountTypeList(){
		return accountTypeList;
	}
	
	public MCWebElement getAccountNumberInput(){
		return accountNumberInput;
	}
	
	public void typeCardNumber(String cardNumber){
		accountNumberInput.sendKeys(cardNumber);
		log.info("Typying card number: "+ cardNumber);
	}
	
	@Override
	public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("bank_account_num")));
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("login_submit_account_num")));
		return conditions;
	}
	
}
