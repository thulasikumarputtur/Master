package com.mastercard.gto.gsd.mrs.ir.page;

import java.util.ArrayList;
import java.util.Collection;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.element.MCWebElements;
import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

@Component
public class HomePage extends AbstractPage {
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//nav[@id='aux']/ul/li/a")
	private MCWebElements topNavItemsRight;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//nav[@id='main']/ul/li/a")
	private MCWebElements topNavItemsLeft;	
	
	public void clickOnTopRightLinkByName(String linkName){
		
		for(MCWebElement result : topNavItemsRight.getElements()){
			log.info("There is the link: " + result.getText());
			if(linkName.equalsIgnoreCase(result.getText())){
				log.info("Clicking on link: " + result.getText());
				result.click();
				break;
			}
		}
	}
	
	public void clickOnTopLeftLinkByName(String linkName){
		
		for(MCWebElement result : topNavItemsLeft.getElements()){
			log.info("There is the link: " + result.getText());
			if(linkName.equalsIgnoreCase(result.getText())){
				log.info("Clicking on link: " + result.getText());
				result.click();
				break;
			}
		}
	}
	
	
	@Override
	protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		Collection<ExpectedCondition<WebElement>> conditions = new ArrayList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//nav[@id='aux']")));
		return conditions;
	}
	
}
