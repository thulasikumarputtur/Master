package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 11/11/2016.
 */

@Component
public class UpdateProfileComponent extends AbstractComponent {

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="user_id")
    private MCWebElement userIdInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="user_pwd")
    private MCWebElement userPasswordInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="user_pwd_cfm")
    private MCWebElement userPasswordConfirmationInput;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "usrProfUpdButton")
    private MCWebElement updateProfileButton;

    /**
     *
     * @return the userIdInput
     */
    public MCWebElement getUserIdInput() {
        return userIdInput;
    }

    /**
     *
     * @return the userPasswordInput
     */
    public MCWebElement getUserPasswordInput() {
        return userPasswordInput;
    }

    /**
     *
     * @return the userPasswordConfirmationInput
     */
    public MCWebElement getUserPasswordConfirmationInput() {
        return userPasswordConfirmationInput;
    }

    /**
     *
     * @return the updateProfileButton
     */
    public MCWebElement getUpdateProfileButton() {
        return updateProfileButton;
    }

    /**Type the new user password
     *
     * @param password the new user password
     */
    public void typePassword(String password){
        this.userPasswordInput.sendKeys(password);
        log.info("Typing the user new password : " + password);
    }

    /**Type the user id
     *
     * @param userId the user id
     */
    public void typeUserId(String userId){
        this.userIdInput.sendKeys(userId);
        log.info("Typing the user new password : " + userId);
    }

    /**
     * Retype the new user password
     *
     * @param newPassword the new user password
     */
    public void reTypePassword(String newPassword){
        this.userPasswordConfirmationInput.sendKeys(newPassword);
        log.info("Retyping the user new password : " + newPassword);
    }

    /**
     * Clicks on the update button
     */
    public void clickOnSubmitButton(){
        this.updateProfileButton.click();
        log.info("Clicked on Update button");
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("usrProfUpdButton")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("user_id")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("user_pwd")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("user_pwd_cfm")));

        return conditions;
    }
}
