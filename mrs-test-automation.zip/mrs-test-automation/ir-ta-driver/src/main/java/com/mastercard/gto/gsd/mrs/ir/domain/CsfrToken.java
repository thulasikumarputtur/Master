package com.mastercard.gto.gsd.mrs.ir.domain;

import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 11/11/2016.
 */

@Component
public class CsfrToken {

    private static String CRFS_TOKEN;

    public static String getCrfsToken() {
        return CRFS_TOKEN;
    }

    public static void setCrfsToken(String crfsToken) {
        CRFS_TOKEN = crfsToken;
    }
}
