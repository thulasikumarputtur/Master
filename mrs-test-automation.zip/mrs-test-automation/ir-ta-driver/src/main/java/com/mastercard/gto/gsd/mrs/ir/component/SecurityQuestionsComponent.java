package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 8/23/2016.
 */
@Component
public class SecurityQuestionsComponent extends AbstractComponent {

    @PageElement(findBy= ElementsBase.FindBy.X_PATH, valueToFind="//*[@id=\"div_restore\"]/header/h3")
    private MCWebElement pageTitle;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="answer0")
    private MCWebElement firstAnswer;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="answer1")
    private MCWebElement secondAnswer;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="btn_submit")
    private MCWebElement submitButton;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="btn_cancel")
    private MCWebElement cancelButton;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="restore_msg")
    private MCWebElement wrongAnswerMessage;

    /**
     *
     * @return the firstAnswer input
     */
    public MCWebElement getFirstAnswer() {
        return firstAnswer;
    }

    /**
     *
     * @return the secondAnswer input
     */
    public MCWebElement getSecondAnswer() {
        return secondAnswer;
    }

    /**
     *
     * @return the submitButton
     */
    public MCWebElement getSubmitButton() {
        return submitButton;
    }

    /**
     *
     * @return the cancelButton
     */
    public MCWebElement getCancelButton() {
        return cancelButton;
    }

    /**
     *
     * @return the pageTitle
     */
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    /**
     * Types the first answer in the input field.
     * @param firstAnswerText the text to be typed
     */
    public void typeFirstAnswer(String firstAnswerText){
        firstAnswer.sendKeys(firstAnswerText);
        log.info("Typing first answer text: " + firstAnswer);
    }

    /**
     * Types the second answer in the input field.
     * @param secondAnswerText the text to be typed
     */
    public void typeSecondAnswer(String secondAnswerText){
        secondAnswer.sendKeys(secondAnswerText);
        log.info("Typing second answer text: " + secondAnswerText);
    }

    /**
     * Click on submit button
     */
    public void clickOnSubmitButton(){
        this.submitButton.click();
        log.info("Clicked on security questions' Submit Button.");
    }

    /**
     * Click on cancel button
     */
    public void clickOnCancelButton(){
        this.cancelButton.click();
        log.info("Clicked on security questions' Cancel button");
    }
    
    

    public String getWrongAnswerMsgText() {
    	//necessary wait time to reload component
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
        return wrongAnswerMessage.getText();
    }
    

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_submit")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_cancel")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("answer0")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("answer1")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"div_restore\"]/header/h3")));
        return conditions;
    }
}
