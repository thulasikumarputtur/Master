package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

/**
 * Created by e054649 on 8/18/2016.
 */

@Component
public class ForgotPasswordComponent extends AbstractComponent{
    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = "//*[@id='div_restore']/header/h3")
    private MCWebElement pageTitle;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="user_id")
    private MCWebElement userIdInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="btn_submit")
    private MCWebElement forgotPasswordSubmitButton;

    @PageElement(findBy = ElementsBase.FindBy.CLASS, valueToFind = "error")
    private MCWebElement errorMessage;

    /**
     *
     * @return the pageTitle
     */
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    /**
     *
     * @return the userIdInput
     */
    public MCWebElement getUserIdInput() {
        return userIdInput;
    }

    /**
     *
     * @return the forgotPasswordSubmitButton
     */
    public MCWebElement getForgotPasswordSubmitButton() {
        return forgotPasswordSubmitButton;
    }

    /**
     *
     * @return the errorMessage
     */
    public MCWebElement getErrorMessage() {
        return errorMessage;
    }

    /**Type the userID in the input field.
     *
     * @param userID the userId to be inserted
     */
    public void typeUserId(String userID){
        userIdInput.sendKeys(userID);
        log.info("Typing userID text: " + userID);
    }

    /**
     * Click on submit button
     */
    public void clickSubmitButton(){
        forgotPasswordSubmitButton.click();
        log.info("Clicked on Submit Button.");
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("user_id")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_submit")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='div_restore']/header/h3")));
        return conditions;
    }
}
