package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;


@Component
public class ForgotUserIdComponent extends AbstractComponent{
    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = "//*[@id='fancybox-content']/div/header/h3")
    private MCWebElement pageTitle;

    @PageElement(findBy= ElementsBase.FindBy.X_PATH, valueToFind = "//*[@id='fancybox-content']/div/div/fieldset/div[1]/div/p")
    private MCWebElement forgotUserIdMsg;

    @PageElement(findBy= ElementsBase.FindBy.X_PATH, valueToFind = "//*[@id='fancybox-content']/div/div/fieldset/div[2]/div/button/span")
    private MCWebElement closeButton;

    @PageElement(findBy = ElementsBase.FindBy.CLASS, valueToFind = "error")
    private MCWebElement errorMessage;

    
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    public MCWebElement getErrorMessage() {
        return errorMessage;
    }

    public String getForgotUserIdMsgText() {
        return forgotUserIdMsg.getText();
    }
    
    public void clickCloseButton(){
    	closeButton.click();
        log.info("Clicked on Close Button.");
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='fancybox-content']/div/div/fieldset/div[1]/div/p")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='fancybox-content']/div/div/fieldset/div[2]/div/button/span")));
        return conditions;
    }
}
