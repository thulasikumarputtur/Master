package com.mastercard.gto.gsd.mrs.ir.component;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

/**
 * Created by e053700 on 04/24/2017.
 */

@Component
public class PointBalanceComponent extends AbstractComponent {

    @PageElement(findBy = FindBy.ID, valueToFind = "ajax_user_points")
    private MCWebElement pointBalanceFrame;
    
    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//dl[@id='ajax_user_points']/dd/span")
    private MCWebElement pointBalanceAmount;
 

    public int getPointBalanceAmount() {
        try {
			return NumberFormat.getNumberInstance(java.util.Locale.US).parse(pointBalanceAmount.getText()).intValue();
		} catch (ParseException e) {
			log.info("Could not parse String to int.");
			e.printStackTrace();
			return 0;
		}
    }    

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("ajax_user_points")));

        return conditions;
    }
}
