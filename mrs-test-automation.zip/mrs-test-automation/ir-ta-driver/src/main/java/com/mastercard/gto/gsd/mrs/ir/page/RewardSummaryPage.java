package com.mastercard.gto.gsd.mrs.ir.page;

import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 5/22/2017.
 */

@Component
public class RewardSummaryPage extends AbstractPage {

    public static final String POINT_SUMMARY_LOCATOR = "faq1";
    public static final String POINT_SUMMARY_BANK_PRODUCT_LOCATOR = "faq2";
    public static final String ACCUMULATION_DETAILS_LOCATOR = "faq4";
    public static final String ADJUSTMENT_DETAILS_LOCATOR = "faq5";
    public static final String REDEMPTION_DETAILS_LOCATOR = "faq6";
    public static final String POINTS_EXPIRED_LOCATOR = "faq8";
    public static final String QUALIFICATIONS_LOCATOR = "faq9";
    public static final String PAY_WITH_REWARDS_REDEMPTION_DETAILS_LOCATOR = "faq11";

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = POINT_SUMMARY_LOCATOR)
    private MCWebElement pointSummary;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = POINT_SUMMARY_BANK_PRODUCT_LOCATOR)
    private MCWebElement pointSummaryBankProduct;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = ACCUMULATION_DETAILS_LOCATOR)
    private MCWebElement accumulationDetails;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = ADJUSTMENT_DETAILS_LOCATOR)
    private MCWebElement adjustmentDetails;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = REDEMPTION_DETAILS_LOCATOR)
    private MCWebElement redemptionDetails;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = POINTS_EXPIRED_LOCATOR)
    private MCWebElement pointsExpired;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = QUALIFICATIONS_LOCATOR)
    private MCWebElement qualifications;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = PAY_WITH_REWARDS_REDEMPTION_DETAILS_LOCATOR)
    private MCWebElement payWithRewardsRedemptionDetails;

    /**
     * Navigate to landing page url.
     *
     * @param landingPageUrl the landing page url
     */
    public void navigateToLandingPageUrl(String landingPageUrl) {
        getFinder().getWebDriver().get(landingPageUrl);
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(POINT_SUMMARY_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(POINT_SUMMARY_BANK_PRODUCT_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(ACCUMULATION_DETAILS_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(ADJUSTMENT_DETAILS_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(REDEMPTION_DETAILS_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(POINTS_EXPIRED_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(QUALIFICATIONS_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(PAY_WITH_REWARDS_REDEMPTION_DETAILS_LOCATOR)));

        return conditions;
    }
}
