package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import com.mastercard.testing.mtaf.bindings.element.MCWebElements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

@Component
public class ShippingAddressSelectionModalComponent extends AbstractComponent {

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='fancybox-content']/div/div/header/div/div/h3")
    private MCWebElement pageTitle;

    @PageElement(findBy = FindBy.NAME, valueToFind = "shipping_address_id")
    private MCWebElement selectAddressRadioButton;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_ship")
    private MCWebElement shipToAddressButton;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_edit")
    private MCWebElement editShippingAddressButton;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_delete")
    private MCWebElement deleteShippingAddressButton;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_add")
    private MCWebElement addShippingAddressButton;

    @PageElement(findBy = FindBy.ID, valueToFind = "fancybox-close")
    private MCWebElement closeShippingAddressModalButton;

    @PageElement(findBy = FindBy.CLASS, valueToFind = "scrollBox")
    private MCWebElements addresses;

    /**
     * Gets addresses.
     *
     * @return the addresses
     */
    public MCWebElements getAddresses() {
        return addresses;
    }

    /**
     * @return the pageTitle
     */
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    /**
     * select address
     */
    public void clickSelectAddressRadioButton() {
        selectAddressRadioButton.click();
        log.info("Clicked to select Address radio button.");
    }

    /**
     * Click on delete shipping address button.
     */
    public void clickOnDeleteShippingAddressButton() {
        deleteShippingAddressButton.click();
        log.info("Clicked on Delete Shipping Address button.");
    }

    /**
     * @return the shipToAddressButton
     */
    public MCWebElement getShipToAddressButton() {
        return shipToAddressButton;
    }

    public void clickShipToAddressButton() {
        shipToAddressButton.click();
        log.info("Clicked on Ship to Address button.");
    }

    /**
     * @return the addShippingAddressButton
     */
    public MCWebElement getAddShippingAddressButton() {
        return addShippingAddressButton;
    }

    public void clickAddShippingAddressButton() {
        addShippingAddressButton.click();
        log.info("Clicked on Add Shipping Address button.");
    }

    public void clickOnEditShippingAddressButton() {
        editShippingAddressButton.click();
        log.info("Clicked on Edit Shipping Address button.");
    }

    public int addressShippingNameCount(String addressShippingName) {
        int occurrences = 0;
        this.addresses = this.getFinder().findMany(FindBy.CLASS, "scrollBox");

        String currentAddresses = addresses.getText().toString();
        int lastIndex = 0;

        while (lastIndex != -1) {
            lastIndex = currentAddresses.indexOf(addressShippingName, lastIndex);

            if (lastIndex != -1) {
                occurrences++;
                lastIndex += addressShippingName.length();
            }
        }

        return occurrences;

    }

    /**
     * @return the closeShippingAddressModalButton
     */
    public MCWebElement getCloseShippingAddressModalButton() {
        return closeShippingAddressModalButton;
    }

    public void clickCloseShippingAddressModalButton() {
        closeShippingAddressModalButton.click();
        log.info("Clicked on Shipping Address close button.");
    }


    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='fancybox-content']/div/div/header/div/div/h3")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_ship")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_add")));
        return conditions;
    }

}
