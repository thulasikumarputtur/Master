package com.mastercard.gto.gsd.mrs.ir.page;

import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * Created by e054649 on 5/29/2017.
 */

@Component
public class ThirdPartyOnlineTravelPage extends AbstractPage {

    /**
     * Get page title string.
     *
     * @return the string
     */
    public String getPageTitle() {
        return getFinder().getWebDriver().getTitle();
    }

    @Override
    protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        return null;
    }
}
