package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

/**
 * Created by e054649 on 8/24/2016.
 */
@Component
public class ForgotPasswordConfirmationComponent extends AbstractComponent {

    @PageElement(findBy= ElementsBase.FindBy.X_PATH, valueToFind="//*[@id=\"div_restore\"]/div/fieldset/div[2]/div/button")
    private MCWebElement okButton;

    @PageElement(findBy= ElementsBase.FindBy.X_PATH, valueToFind="//*[@id=\"div_restore\"]/div/fieldset/div[1]/div/p[1]")
    private MCWebElement successMessage;

    public MCWebElement getOkButton() {
        return okButton;
    }

    public MCWebElement getSuccessMessage() {
        return successMessage;
    }

    public void clickOnOkButton(){
        this.okButton.click();
        log.info("Clicked on OK button");
    }

    @Override
    public boolean isLoaded() {
        log.info("at isLoaded");
        return super.isLoaded();

    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"div_restore\"]/div/fieldset/div[2]/div/button")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"div_restore\"]/div/fieldset/div[1]/div/p[1]")));
        return conditions;
    }
}
