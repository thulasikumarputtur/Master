package com.mastercard.gto.gsd.mrs.ir.page;

import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * Created by e054649 on 6/13/2017.
 */

@Component
public class TransferPointsPage extends AbstractPage {

    public static final String ACCOUNT_ORIGIN_LOCATOR = "acc_origin";
    public static final String ACCOUNT_TYPE_LOCATOR = "acc_type";
    public static final String RECIPIENT_ACCOUNT_NUMBER_LOCATOR = "rec_acc_num";
    public static final String RECIPIENT_LAST_NAME_LOCATOR = "rec_last_name";
    public static final String BUTTON_NEXT_LOCATOR = "btn_submit";
    public static final String TRANSFER_AMOUNT_LOCATOR = "trans_amt_orig";
    public static final String CONFIRM_TRANSFER_OK_BUTTON_LOCATOR = "//*[@id=\"form_point_transfer_confirm\"]/fieldset/div[2]/div[1]/button";
    public static final String TRANSFER_MESSAGE_LOCATOR = "//*[@id=\"form_point_transfer_complete\"]/fieldset/div[1]/div/p";
    public static final String TRANSFER_COMPLETE_RETURN_BUTTON_LOCATOR = "//*[@id=\"form_point_transfer_complete\"]/fieldset/div[2]/button";


    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = ACCOUNT_ORIGIN_LOCATOR)
    private MCWebElement originAccountNumberDropdown;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = ACCOUNT_TYPE_LOCATOR)
    private MCWebElement recipientAccountTypeDropdown;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = RECIPIENT_ACCOUNT_NUMBER_LOCATOR)
    private MCWebElement recipientAccountNumberInput;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = RECIPIENT_LAST_NAME_LOCATOR)
    private MCWebElement recipientLastNameInput;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = BUTTON_NEXT_LOCATOR)
    private MCWebElement nextButton;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = TRANSFER_AMOUNT_LOCATOR)
    private MCWebElement transferAmountInput;

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = CONFIRM_TRANSFER_OK_BUTTON_LOCATOR)
    private MCWebElement okButton;

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = TRANSFER_MESSAGE_LOCATOR)
    private MCWebElement transferCompleteMessage;

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = TRANSFER_COMPLETE_RETURN_BUTTON_LOCATOR)
    private MCWebElement returnToMainPageButton;

    public void clickOnOkButton(){
        this.okButton.click();
        log.info("Clicked on confirmation ok button.");
    }

    public void selectOriginAccountNumber(String accountNumber){
        this.originAccountNumberDropdown.getSelect().selectByVisibleText(accountNumber);
        log.info("Selected origin account number: " + accountNumber);
    }

    public void selectRecipientAccountType(String accountType){
        this.recipientAccountTypeDropdown.getSelect().selectByVisibleText(accountType);
        log.info("Selected recipient account type: " + accountType);
    }

    public void typeRecipientAccountNumber(String accountNumber){
        this.recipientAccountNumberInput.sendKeys(accountNumber);
        log.info("Typed account number.");
    }

    public void typeRecipientLastName(String lastName){
        this.recipientLastNameInput.sendKeys(lastName);
        log.info("Typed recipient last name: " + lastName);
    }

    public void clickOnButtonNext(){
        this.nextButton.click();
        log.info("Clicked on button next");
    }

    public void typeTransferAmount(String pointsToTransfer){
        this.transferAmountInput.sendKeys(pointsToTransfer);
        log.info("Typed the amount of points to transfer: " + pointsToTransfer);
    }

    public void navigateToLandingPageUrl(String landingPageUrl) {
        getFinder().getWebDriver().get(landingPageUrl);
    }

    public MCWebElement getTransferCompleteMessage() {
        return transferCompleteMessage;
    }

    public void clickOnReturnToMainPage(){
        this.returnToMainPageButton.click();
        log.info("Clicked on return to main page button.");
    }

    @Override
    protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        return null;
    }
}
