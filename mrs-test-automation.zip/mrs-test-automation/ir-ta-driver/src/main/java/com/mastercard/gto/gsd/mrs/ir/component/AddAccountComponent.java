package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 12/22/2016.
 */
@Component
public class AddAccountComponent extends AbstractComponent {

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "bankProductId")
    private MCWebElement bankProduct;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "accountNumber")
    private MCWebElement accountNumber;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "accountNickname")
    private MCWebElement accountNickname;

    /**
     * Select bank product.
     *
     * @param bankProduct the bank product
     */
    public void selectBankProduct(String bankProduct) {
        this.bankProduct.getSelect().selectByVisibleText(bankProduct);
        log.info("Selecting bank product : " + bankProduct);
    }

    /**
     * Type account number.
     *
     * @param accountNumber the account number
     */
    public void typeAccountNumber(String accountNumber){
        this.accountNumber.sendKeys(accountNumber);
        log.info("Typing account number: " + accountNumber);
    }

    /**
     * Type account nick name.
     *
     * @param accountNickname the account nickname
     */
    public void typeAccountNickName(String accountNickname){
        this.accountNickname.sendKeys(accountNickname);
        log.info("Typing account nickname: " + accountNickname);
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("bankProductId")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("accountNumber")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("accountNickname")));

        return conditions;
    }


}
