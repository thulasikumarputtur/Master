package com.mastercard.gto.gsd.mrs.ir.page;

import java.util.ArrayList;
import java.util.Collection;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

@Component
public class RegistrationPage3 extends AbstractPage {
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='RegisterForm']/h2")
    private MCWebElement pageTitle;
		
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='RegisterForm']/fieldset/p")
    private MCWebElement regSuccessMessage;
	
    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='RegisterForm']/fieldset/div/button")
    private MCWebElement reg3ReturnButton;

	
	
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    public MCWebElement getFormMessage() {
        return regSuccessMessage;
    }
   

    /**
     * @return the returnButton
     */
    public MCWebElement getRegReturnButton() {
        return reg3ReturnButton;
    }

    public void clickReturnButton() {
    	reg3ReturnButton.click();
        log.info("Clicked on Return Button.");
    }

    
	public String getCurrentUrl(){
		log.info("Current URL : " + getFinder().getWebDriver().getCurrentUrl());
		return getFinder().getWebDriver().getCurrentUrl();
	}
	

	@Override
	protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		Collection<ExpectedCondition<WebElement>> conditions = new ArrayList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='RegisterForm']/h2")));
		return conditions;
	}

}
