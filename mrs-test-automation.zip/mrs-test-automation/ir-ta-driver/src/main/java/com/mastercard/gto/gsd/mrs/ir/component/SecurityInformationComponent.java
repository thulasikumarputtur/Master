package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 11/16/2016.
 */
@Component
public class SecurityInformationComponent extends AbstractComponent {

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "challenge_question0")
    private MCWebElement challengeQuestions0;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "challenge_answer0")
    private MCWebElement challengeAnswer0;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "challenge_answer_cfm0")
    private MCWebElement challengeAnswerConfirmation0;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "challenge_question1")
    private MCWebElement challengeQuestions1;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "challenge_answer1")
    private MCWebElement challengeAnswer1;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "challenge_answer_cfm1")
    private MCWebElement challengeAnswerConfirmation1;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "challenge_question2")
    private MCWebElement challengeQuestions2;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "challenge_answer2")
    private MCWebElement challengeAnswer2;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "challenge_answer_cfm2")
    private MCWebElement challengeAnswerConfirmation2;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "securityInfoUpdBtn")
    private MCWebElement updateSecurityInformationButton;

    /**
     * Selects an option in the list based on the given text
     *
     * @param mcWebElement  the mcWebElements
     * @param elementToClick the String to look for.
     */
    public void selectChallengeQuestion(MCWebElement mcWebElement, String elementToClick) {

        mcWebElement.getSelect().selectByVisibleText(elementToClick);
        log.info("Challenge question selected: " + elementToClick);
    }

    /**
     * Types the new challenge answer
     *
     * @param mcWebElement    - the mcWebElement
     * @param challengeAnswer - The new answer
     */
    public void inputChallengeAnswer(MCWebElement mcWebElement, String challengeAnswer) {
        this.inputText(mcWebElement, challengeAnswer);
        log.info("Retyping the new challenge answer : " + challengeAnswer);
    }

    /**
     * Type the given text to the input field.
     *
     * @param mcWebElement - The input field
     * @param text         - The text to be inserted.
     * @throws NullPointerException
     */
    private void inputText(MCWebElement mcWebElement, String text) {
        mcWebElement.sendKeys(text);
    }

    /**
     * Retype the new challenge answer
     *
     * @param mcWebElement    - the mcWebElement
     * @param challengeAnswer - The new answer
     */
    public void reTypeAnswer(MCWebElement mcWebElement, String challengeAnswer) {
        this.inputText(mcWebElement, challengeAnswer);
        log.info("Retyping the new challenge answer : " + challengeAnswer);
    }

    /**
     * Clicks on the update button
     */
    public void clickOnSubmitButton() {
        this.updateSecurityInformationButton.click();
        log.info("Clicked on Update button");
    }

    /**
     * Gets challenge questions 0.
     *
     * @return the challenge questions 0
     */
    public MCWebElement getChallengeQuestions0() {
        return challengeQuestions0;
    }

    /**
     * Gets challenge answer 0.
     *
     * @return the challenge answer 0
     */
    public MCWebElement getChallengeAnswer0() {
        return challengeAnswer0;
    }

    /**
     * Gets challenge answer confirmation 0.
     *
     * @return the challenge answer confirmation 0
     */
    public MCWebElement getChallengeAnswerConfirmation0() {
        return challengeAnswerConfirmation0;
    }

    /**
     * Gets challenge questions 1.
     *
     * @return the challenge questions 1
     */
    public MCWebElement getChallengeQuestions1() {
        return challengeQuestions1;
    }

    /**
     * Gets challenge answer 1.
     *
     * @return the challenge answer 1
     */
    public MCWebElement getChallengeAnswer1() {
        return challengeAnswer1;
    }

    /**
     * Gets challenge answer confirmation 1.
     *
     * @return the challenge answer confirmation 1
     */
    public MCWebElement getChallengeAnswerConfirmation1() {
        return challengeAnswerConfirmation1;
    }

    /**
     * Gets challenge questions 2.
     *
     * @return the challenge questions 2
     */
    public MCWebElement getChallengeQuestions2() {
        return challengeQuestions2;
    }

    /**
     * Gets challenge answer 2.
     *
     * @return the challenge answer 2
     */
    public MCWebElement getChallengeAnswer2() {
        return challengeAnswer2;
    }

    /**
     * Gets challenge answer confirmation 2.
     *
     * @return the challenge answer confirmation 2
     */
    public MCWebElement getChallengeAnswerConfirmation2() {
        return challengeAnswerConfirmation2;
    }

    /**
     * Gets update security information button.
     *
     * @return the update security information button
     */
    public MCWebElement getUpdateSecurityInformationButton() {
        return updateSecurityInformationButton;
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("challenge_question0")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("challenge_answer0")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("challenge_answer_cfm0")));

        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("challenge_question1")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("challenge_answer1")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("challenge_answer_cfm1")));

        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("challenge_question2")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("challenge_answer2")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("challenge_answer_cfm2")));

        return conditions;
    }
}
