package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

@Component
public class ShippingAddressInclusionModalComponent extends AbstractComponent {

    @PageElement(findBy = FindBy.ID, valueToFind = "address_header")
    private MCWebElement pageTitle;

	@PageElement(findBy = FindBy.ID, valueToFind = "country_code")
    private MCWebElement shippingCountrySelection;

	@PageElement(findBy = FindBy.ID, valueToFind = "name")
    private MCWebElement shippingNameInput;

	@PageElement(findBy = FindBy.ID, valueToFind = "company_addr_sw_n")
    private MCWebElement shippingAddressResidentialRadio;

	@PageElement(findBy = FindBy.ID, valueToFind = "company_addr_sw_y")
    private MCWebElement shippingAddressBusinessRadio;

    @PageElement(findBy = FindBy.ID, valueToFind = "address1")
    private MCWebElement shippingAddress1Input;

    @PageElement(findBy = FindBy.ID, valueToFind = "city")
    private MCWebElement shippingCityInput;

    @PageElement(findBy = FindBy.ID, valueToFind = "phone")
    private MCWebElement shippingPhoneInput;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_submit")
    private MCWebElement shipAddressSubmitButton;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_cancel")
    private MCWebElement shipAddressCancelButton;

    @PageElement(findBy = FindBy.CLASS, valueToFind = "error")
    private MCWebElement errorMessage;


    public MCWebElement getErrorMessage() {
        return errorMessage;
    }
    
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    public void selectShippingCountry(String shippingCountry) {
    	shippingCountrySelection.getSelect().selectByVisibleText(shippingCountry);
        log.info("Selecting shipping country: " + shippingCountry);
    }
    
    public void typeShippingNameInput(String shippingName) {
        shippingNameInput.sendKeys(shippingName);
        log.info("Typing shipping name: " + shippingName);
    }
    
    public void clickAddressTypeResidentialRadioButton() {
    	shippingAddressResidentialRadio.click();
        log.info("Clicked on Residential type radio button.");
    }
    
    public void clickAddressTypeBusinessRadioButton() {
    	shippingAddressBusinessRadio.click();
        log.info("Clicked on Business type radio button.");
    }
    
    public void typeShippingAddress1Input(String shippingAddress1) {
        shippingAddress1Input.sendKeys(shippingAddress1);
        log.info("Typing shipping address1: " + shippingAddress1);
    }
    
    public void typeShippingCityInput(String shippingCity) {
        shippingCityInput.sendKeys(shippingCity);
        log.info("Typing shipping city: " + shippingCity);
    }
    
    public void typeShippingPhoneInput(String shippingPhone) {
        shippingPhoneInput.sendKeys(shippingPhone);
        log.info("Typing shipping phone: " + shippingPhone);
    }

    public void clickSubmitButton() {
    	shipAddressSubmitButton.click();
        log.info("Clicked on Submit Shipping Address button.");
    }

    public void clickCancelButton() {
    	shipAddressCancelButton.click();
        log.info("Clicked on Cancel Shipping Address button.");
    }


    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("address_header")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("name")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_submit")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_cancel")));
        return conditions;
    }

}
