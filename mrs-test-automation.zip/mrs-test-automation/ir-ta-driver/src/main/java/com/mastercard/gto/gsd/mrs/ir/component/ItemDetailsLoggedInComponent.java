package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.element.MCWebElements;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * @author e040514
 * 
 */

@Component
public class ItemDetailsLoggedInComponent extends AbstractComponent {

	public static final String SEARCH_INPUT_LOCATOR = "search_param";
	public static final String SEARCH_BUTTON_LOCATOR = "button_icon_left";
	public static final String CHECKBOX_RECUR_REDEEM_LOCATOR = "itemRecurRedeem";
	public static final String INPUT_ITEM_FREQ_LOCATOR = "itemFreq";
	public static final String MESSAGE_LOCATOR = "//*[@id=\"form_10088\"]/div/div[1]/div[1]/div[1]/div/p";
	@Value("${redemptionItemName}")
	String itemName;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id=\"offer_offer_highlight\"]/li/a")
	private MCWebElements redemptionItemList;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "/html/body/div[1]/div/section/section[1]/div/div[2]/div/div/div[2]/div/h2")
	private MCWebElement redemptionItemDescription;

	@PageElement(findBy = FindBy.ID, valueToFind = "qty")
	private MCWebElement quantityDropdown;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='form_10088']/div/div[1]/div[1]/div[2]/button")
	private MCWebElement addToCardButton;

	@PageElement(findBy = FindBy.ID, valueToFind = SEARCH_INPUT_LOCATOR)
	private MCWebElement searchInput;

	@PageElement(findBy = FindBy.CLASS, valueToFind = SEARCH_BUTTON_LOCATOR)
	private MCWebElement searchButton;

	@PageElement(findBy = FindBy.NAME, valueToFind = INPUT_ITEM_FREQ_LOCATOR)
	private MCWebElement itemFreqInput;

	@PageElement(findBy = FindBy.ID, valueToFind = CHECKBOX_RECUR_REDEEM_LOCATOR)
	private MCWebElement itemRecurRedeemCheckBox;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = MESSAGE_LOCATOR)
	private MCWebElement message;

	/**
	 * Gets message.
	 *
	 * @return the message
	 */
	public MCWebElement getMessage() {
		return message;
	}

	/**
	 * Input frequency.
	 *
	 * @param text the text
	 */
	public void inputFrequency(String text){
		this.itemFreqInput.sendKeys(text);
	}

	/**
	 * Click on check box.
	 */
	public void clickOnCheckBox(){
		this.itemRecurRedeemCheckBox.click();
	}

	/**
	 * Click on search button.
	 */
	public void clickOnSearchButton(){
		this.searchButton.click();
	}

	/**
	 * Type search.
	 *
	 * @param searchCriteria the search criteria
	 */
	public void typeSearch(String searchCriteria){
		this.searchInput.sendKeys(searchCriteria);
	}


	/**
	 * @return
	 */
	public MCWebElement getRedemptionItemDescription() {
		return redemptionItemDescription;
	}

	/**
	 * @param redemptionItemDescription
	 */
	public void setRedemptionItemDescription(MCWebElement redemptionItemDescription) {
		this.redemptionItemDescription = redemptionItemDescription;
	}

	public MCWebElement getItemRecurRedeemCheckBox() {
		return itemRecurRedeemCheckBox;
	}

	public MCWebElement getQuantityDropdown() {
		return quantityDropdown;
	}

	public void setQuantityDropdown(MCWebElement quantityDropdown) {
		this.quantityDropdown = quantityDropdown;
	}

	public boolean clickOnRedemptionItemByDesc(String redemptionItemDesc) {
		///log.info("Given Item Desc : "+ redemptionItemDesc);
		for(MCWebElement result : redemptionItemList.getElements()){
			log.info("There is the link: " + result.getAttribute("data-analytics-event"));
			if(redemptionItemDesc.contains(result.getAttribute("data-analytics-event"))){
				log.info("Clicking on link: " + result.getAttribute("data-analytics-event"));
				result.click();
				return true;
			}
		}
		return false;
	}

	public String getRedemptionItemDescText() {
		log.info("Add cart button is null? " + addToCardButton == null);
		log.info("Redemption Item Desc: " + redemptionItemDescription.getText());

		return redemptionItemDescription.getText();
	}

	public void selectQuantityValueTo(String value) {
		if(quantityDropdown.getTagName().equalsIgnoreCase("select"))
			quantityDropdown.getSelect().selectByVisibleText(value);
		else
			quantityDropdown.sendKeys(value);
		log.info("Selected quantity dropdown to : " + value);
	}

	public void clickAddToCardButton() {
		addToCardButton.click();
		log.info("Clicked Add to Cart Button");
	}


	@Override
	public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='offer_offer_highlight']/li[1]/a/img")));
		return conditions;
	}

}
