package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * @author e040514
 * 
 */

@Component
public class CheckoutLoggedInComponent extends AbstractComponent {

	@PageElement(findBy = FindBy.CLASS, valueToFind = "change_address")
	private MCWebElement changeAddressButton;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='ajaxEventDiv']/div[1]/div/div/div/div/div/div[4]/div/div/div/div/button[2]")
	private MCWebElement sendToDifferentAddress;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='ajaxEventDiv']/div[1]/div/div/div/div/div/div[4]/div/div/div/div/label[2]/span[2]")
	private MCWebElement shippingAddressInfoBox;

	@PageElement(findBy = FindBy.ID, valueToFind = "email_conf")
	private MCWebElement emailAddressInput;

	@PageElement(findBy = FindBy.ID, valueToFind = "retype_email_conf")
	private MCWebElement confirmEmailAddressInput;

	@PageElement(findBy = FindBy.CLASS, valueToFind = "primary continue")
	private MCWebElement continueButton;
	


	public void clickChangeAddressButton() {
		changeAddressButton.click();
		log.info("Click on changeAddressButton");
	}

	public void clickOnSendToDifferentAddress(){
		this.sendToDifferentAddress.click();
		log.info("Click on sendToDifferentAddress");
	}
	
	public MCWebElement getShippingAddressInfoBox(){
		return shippingAddressInfoBox;
	}

	public void setEmailAddressInput(MCWebElement emailAddressInput) {
		this.emailAddressInput = emailAddressInput;
	}

	public MCWebElement getConfirmEmailAddressInput() {
		return confirmEmailAddressInput;
	}

	public void setConfirmEmailAddressInput(
			MCWebElement confirmEmailAddressInput) {
		this.confirmEmailAddressInput = confirmEmailAddressInput;
	}

	public void typeEmailAddressInput(String emailId) {
		emailAddressInput.clearField();
		emailAddressInput.sendKeys(emailId);
		log.info("Typing email address text field: " + emailId);
	}

	public void typeConfirmEmailAddressInput(String confirmEmailId) {
		confirmEmailAddressInput.clearField();
		confirmEmailAddressInput.sendKeys(confirmEmailId);
		log.info("Typing confirm email address text field: " + confirmEmailId);
	}

	public void clickContinueButton() {
		continueButton.click();
		log.info("Click on continueButton");
	}

	@Override
	public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("email_conf")));
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("retype_email_conf")));
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='ajaxEventDiv']/div[2]/div/div/div/div/div[3]/div[1]/div/div[1]/button")));
		return conditions;
	}

}
