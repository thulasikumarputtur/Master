package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

@Component
public class RegistrationModalComponent extends AbstractComponent {

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//div[@id='fancybox-content']/div/header/h3")
    private MCWebElement pageTitle;

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='RegisterSubDiv']/div[1]/div/label/span")
    private MCWebElement accountTypeLabel;

    @PageElement(findBy = FindBy.ID, valueToFind = "bank_product_id")
    private MCWebElement accountTypeSelection;

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='RegisterSubDiv']/div[2]/div/label/span")
    private MCWebElement accountNumberLabel;
    
    @PageElement(findBy = FindBy.ID, valueToFind = "bank_account_num")
    private MCWebElement accountNumberInput;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_submit")
    private MCWebElement regNextButton;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_cancel")
    private MCWebElement cancelButton;

    @PageElement(findBy = FindBy.CLASS, valueToFind = "error")
    private MCWebElement errorMessage;


    /**
     * @return the errorMessage
     */
    public MCWebElement getErrorMessage() {
        return errorMessage;
    }

    /**
     * @return the pageTitle
     */
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    /**
     * @return the accountTypeLabel
     */
    public MCWebElement getAccountTypeLabel() {
        return accountTypeLabel;
    }

    /**
     * @return the accountTypeSelection
     */
    public MCWebElement getAccountTypeSelection() {
        return accountTypeSelection;
    }

    /**
     * @return the accountNumberLabel
     */
    public MCWebElement getAccountNumberLabel() {
        return accountNumberLabel;
    }

    /**
     * @return the accountNumberInput
     */
    public MCWebElement getAccountNumberInput() {
        return accountNumberInput;
    }

    /**
     * @return the submitButton
     */
    public MCWebElement getRegNextButton() {
        return regNextButton;
    }

    public void clickNextButton() {
    	regNextButton.click();
        log.info("Clicked on Next Button.");
    }

    /**
     * @return the cancelButton
     */
    public MCWebElement getCancelButton() {
        return cancelButton;
    }

    public void clickCancelButton() {
    	cancelButton.click();
        log.info("Clicked on Cancel Button.");
    }
    

    public void selectAccountType(String accountType) {
    	accountTypeSelection.getSelect().selectByVisibleText(accountType);
        log.info("Selecting account type: " + accountType);
    }

    public void typeAccountNumberInput(String accountNumber) {
        accountNumberInput.sendKeys(accountNumber);
        log.info("Typing account number text: " + accountNumber);
    }



    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();

        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("bank_account_num")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_submit")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_cancel")));
        return conditions;
    }

}
