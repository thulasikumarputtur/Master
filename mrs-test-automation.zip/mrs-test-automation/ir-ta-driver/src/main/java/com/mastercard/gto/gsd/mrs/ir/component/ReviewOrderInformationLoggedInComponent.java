package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
/**
 * @author e040514
 * 
 */

@Component
public class ReviewOrderInformationLoggedInComponent extends AbstractComponent {


	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='ajaxEventDiv']/div[1]/div/h2")
	private MCWebElement reviewOrderPageHeader;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id='ajaxEventDiv']/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/button")
	private MCWebElement reviewContinueButton;


	public void clickReviewContinueButton() {
		reviewContinueButton.click();
		log.info("Clicked on reviewContinueButton");
	}
	
	public boolean verifyReviewOrderPage(String verifyText){
		log.info("Verifying review order page text : "+ reviewOrderPageHeader.getText());
		return verifyText.equalsIgnoreCase(reviewOrderPageHeader.getText());
	}

	@Override
	public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='ajaxEventDiv']/div[1]/div/h2")));
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='ajaxEventDiv']/div[2]/div/div/div/div/div[2]/div[1]/div/div[1]/button")));
		return conditions;
	}


}
