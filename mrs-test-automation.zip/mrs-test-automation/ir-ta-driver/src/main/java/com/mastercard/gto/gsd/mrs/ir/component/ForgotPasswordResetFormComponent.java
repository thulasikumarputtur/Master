package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

/**
 * Created by e054649 on 8/24/2016.
 */
@Component
public class ForgotPasswordResetFormComponent extends AbstractComponent{

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="user_pwd")
    private MCWebElement userPasswordInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="user_pwd_cfm")
    private MCWebElement userPasswordConfirmationInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="btn_submit")
    private MCWebElement submitButton;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="btn_cancel")
    private MCWebElement cancelButton;

    @PageElement(findBy= ElementsBase.FindBy.X_PATH, valueToFind="//*[@id=\"div_restore\"]/header/h3")
    private MCWebElement pageTitle;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="restore_msg")
    private MCWebElement invalidPasswordMessage;

    /**
     *
     * @return the passwordInput
     */
    public MCWebElement getUserPasswordInput() {
        return userPasswordInput;
    }

    /**
     *
     * @return the passwordConfirmationInput
     */
    public MCWebElement getUserPasswordConfirmationInput() {
        return userPasswordConfirmationInput;
    }

    /**
     *
     * @return the submitButton
     */
    public MCWebElement getSubmitButton() {
        return submitButton;
    }

    /**
     *
     * @return cancelButton
     */
    public MCWebElement getCancelButton() {
        return cancelButton;
    }

    /**
     *
     * @return the pageTitle
     */
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    /**Type the new user password
     *
     * @param password the new user password
     */
    public void typePassword(String password){
        this.userPasswordInput.sendKeys(password);
        log.info("Typing the user password : " + password);
    }

    /**
     * Retype the new user password
     *
     * @param password the new user password
     */
    public void reTypePassword(String password){
        this.userPasswordConfirmationInput.sendKeys(password);
        log.info("Retyping the user password : " + password);
    }

    /**
     * Click on submit button
     */
    public void clickOnSubmitButton(){
        this.submitButton.click();
        log.info("Clicked on reset password's Submit Button.");
    }

    /**
     * Click on cancel button
     */
    public void clickOnCancelButton(){
        this.cancelButton.click();
        log.info("Clicked on reset password's Cancel button");
    }
    

    public String getInvalidPasswordMsgText() {
    	//necessary wait time to reload component
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
        return invalidPasswordMessage.getText();
    }
    
    

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_submit")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_cancel")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("user_pwd")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("user_pwd_cfm")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"div_restore\"]/header/h3")));
        return conditions;
    }
}
