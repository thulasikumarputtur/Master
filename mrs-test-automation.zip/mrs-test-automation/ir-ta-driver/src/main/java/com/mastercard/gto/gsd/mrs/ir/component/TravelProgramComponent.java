package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 5/30/2017.
 */

@Component
public class TravelProgramComponent extends AbstractComponent{

    public static final String TRAVEL_PROGRAM_NAME_LOCATOR = "travelProgramNameNew";
    public static final String TRAVEL_PROGRAM_NUMBER_LOCATOR = "travelProgramNumberNew";
    public static final String ADD_BUTTON_LOCATOR = "updateLinkNew";
    public static final String TRAVEL_PROGRAM_NAME_EDIT_LOCATOR = "//*[@id=\"travel_program\"]/div[1]/div[2]/label/input";
    public static final String TRAVEL_PROGRAM_NUMBER_EDIT_LOCATOR = "//*[@id=\"travel_program\"]/div[1]/div[3]/label/input";
    public static final String UPDATE_BUTTON_LOCATOR = "//*[@id=\"travel_program\"]/div[1]/div[4]/label/button";
    public static final String REMOVE_BUTTON_LOCATOR = "//*[@id=\"travel_program\"]/div[1]/div[5]/label/button";
    public static final String RADIO_BUTTON_EDIT_LOCATOR = "//*[@id=\"travel_program\"]/div[1]/div[1]/label/input";
    public static final String RADIO_BUTTON_NEW_LOCATOR = "//*[@value=\"newTravelProgram\"]";

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = TRAVEL_PROGRAM_NAME_LOCATOR)
    private MCWebElement programNameInput;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = TRAVEL_PROGRAM_NUMBER_LOCATOR)
    private MCWebElement programNumberInput;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = ADD_BUTTON_LOCATOR)
    private MCWebElement buttonAdd;

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = RADIO_BUTTON_NEW_LOCATOR)
    private MCWebElement radioButtonNew;

    //Update section

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = TRAVEL_PROGRAM_NAME_EDIT_LOCATOR)
    private MCWebElement programNameEditInput;

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = TRAVEL_PROGRAM_NUMBER_EDIT_LOCATOR)
    private MCWebElement programNumberEditInput;

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = UPDATE_BUTTON_LOCATOR)
    private MCWebElement buttonEdit;

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = RADIO_BUTTON_EDIT_LOCATOR)
    private MCWebElement radioButtonEdit;

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = REMOVE_BUTTON_LOCATOR)
    private MCWebElement buttonRemove;

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(ADD_BUTTON_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(TRAVEL_PROGRAM_NAME_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(TRAVEL_PROGRAM_NUMBER_LOCATOR)));

        return conditions;
    }

    /**
     * Type program name.
     *
     * @param programName the program name
     */
    public void typeProgramName(String programName) {
        this.programNameInput.sendKeys(programName);
        log.info("Typed program name " + programName);
    }

    /**
     * Type program number.
     *
     * @param programNumber the program number
     */
    public void typeProgramNumber(String programNumber) {
        this.programNumberInput.sendKeys(programNumber);
        log.info("Typed program number " + programNumber);
    }

    /**
     * Click on add button.
     */
    public void clickOnAddButton() {
        this.buttonAdd.click();
        log.info("Clicked on add button");
    }

    /**
     * Edit program name.
     *
     * @param programName the program name
     */
    public void editProgramName(String programName) {
        this.programNameEditInput.clearField();
        this.programNameEditInput.sendKeys(programName);
        log.info("Edited program name to " + programName);
    }

    /**
     * Edit program number.
     *
     * @param programNumber the program number
     */
    public void editProgramNumber(String programNumber) {
        this.programNumberEditInput.clearField();
        this.programNumberEditInput.sendKeys(programNumber);
        log.info("Edited program number to " + programNumber);
    }

    /**
     * Click on edit button.
     */
    public void clickOnEditButton() {
        this.buttonEdit.click();
        log.info("Clicked on edit button");
    }

    /**
     * Select radio button edit.
     */
    public void selectRadioButtonEdit() {
        this.radioButtonEdit.click();
        log.info("Clicked on radio button to edit");
    }

    /**
     * Click on remove button.
     */
    public void clickOnRemoveButton() {
        this.buttonRemove.click();
        log.info("Clicked on remove button");
    }

    /**
     * Click on ok alert button.
     */
    public void clickOnOkAlertButton() {
        this.getFinder().getWebDriver().switchTo().alert().accept();
    }
}
