package com.mastercard.gto.gsd.mrs.ir.page;

import com.mastercard.gto.gsd.mrs.ir.component.*;
import com.mastercard.gto.gsd.mrs.ir.domain.CsfrToken;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.element.MCWebElements;
import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;

@Component
public class LandingPage extends AbstractPage {
    public static final String TEXT = "text";
    public static final String PASSWORD = "password";
    public static final String DROPDOWN = "select";
    public static final String SPLIT_VALUE = "=";

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = "//nav[@id='aux']/ul/li")
    private MCWebElements topNavItemsRight;

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//nav[@id='main']/h1/a")
    private MCWebElements topNavItemsLeft;

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = "//*[@id='aux']/ul/li[1]/a")
    private MCWebElement loginButton;

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//nav[@class='landing_offer_categories']/ul/li/a")
    private MCWebElements catalogList;

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//ul[@class='card_list small-block-grid-2 medium-block-grid-4']/li/a")
    private MCWebElements itemList;

    @PageElement(findBy = FindBy.CLASS, valueToFind = "item_price")
    private MCWebElements itemPrice;

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//nav[@class='landing_offer_categories']/a")
    private MCWebElement seeMoreLink;

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//nav[@id='hero']/div/div/div/div/img")
    private MCWebElements backGroundImage;

    @Autowired
    LoginFormComponent loginFormComponent;

    @Autowired
    LoginFormAuthComponent loginFormAuthComponent;

    @Autowired
    RegistrationModalComponent registrationModalComponent;

    @Autowired
    LoginFormAccountComponent loginFormAccountComponent;

    @Autowired
    LoginFormNoQuestionComponent loginFormNoQuestionComponent;

    @Autowired
    LoginFormBirthdateComponent loginFormBirthdateComponent;

    @Autowired
    LoginFormGenericComponent loginFormGenericComponent;

    @Autowired
    LoginFormMotherNameComponent loginFormMotherNameComponent;

    @Autowired
    LoginFormSecurityQuestionsComponent loginFormSecurityQuestionsComponent;

    @Autowired
    LoginFormPhoneNumberComponent loginFormPhoneNumberComponent;

    @Autowired
    LoginFormResultsComponent loginFormResultsComponent;


    /**
     * @return the loginFormComponent
     */
    public LoginFormComponent getLoginFormComponent() {
        return loginFormComponent;
    }

    public LoginFormResultsComponent getLoginFormResultsComponent() {
        return loginFormResultsComponent;
    }

    /**
     * @return the loginFormAuthComponent
     */
    public LoginFormAuthComponent getLoginFormAuthComponent() {
        return loginFormAuthComponent;
    }

    /**
     * @return the login Security Questions Components
     */
    public LoginFormNoQuestionComponent getLoginFormNoQuestionComponent() {
        return loginFormNoQuestionComponent;
    }

    public LoginFormBirthdateComponent getLoginFormBirthdateComponent() {
        return loginFormBirthdateComponent;
    }

    public LoginFormGenericComponent getLoginFormGenericComponent() {
        return loginFormGenericComponent;
    }

    public LoginFormMotherNameComponent getLoginFormMotherNameComponent() {
        return loginFormMotherNameComponent;
    }

    public LoginFormSecurityQuestionsComponent getLoginFormSecurityQuestionsComponent() {
        return loginFormSecurityQuestionsComponent;
    }

    public LoginFormPhoneNumberComponent getLoginFormPhoneNumberComponent() {
        return loginFormPhoneNumberComponent;
    }

    /**
     * @return the loginFormAccountComponent
     */
    public LoginFormAccountComponent getLoginFormAccountComponent() {
        return loginFormAccountComponent;
    }


    /**
     * @return the registrationModalComponent
     */
    public RegistrationModalComponent getregistrationModalComponent() {
        return registrationModalComponent;
    }

    public boolean clickOnTopRightLinkByName(String linkName) {

        for (MCWebElement result : topNavItemsRight.getElements()) {
            log.info("There is the link: " + result.getText());
            if (linkName.equalsIgnoreCase(result.getText())) {
                log.info("Clicking on link: " + result.getText());
                result.click();
                return true;
            }
        }
        return false;
    }

    public String getLoginButtonText() {
        return loginButton.getText();
    }

    public void clickOnTopLeftLinkByName(String linkName) {

        for (MCWebElement result : topNavItemsLeft.getElements()) {
            log.info("There is the link: " + result.getText());
            if (linkName.equalsIgnoreCase(result.getText())) {
                log.info("Clicking on link: " + result.getText());
                result.click();
                break;
            }
        }
    }

    public void navigateToLandingPageUrl(String landingPageUrl) {
        getFinder().getWebDriver().get(landingPageUrl);
    }


    /**
     * @return the topNavItemsRight
     */
    public MCWebElements getTopNavItemsRight() {
        return topNavItemsRight;
    }

    public boolean isTopNavItemsRightDisplayed() {
        try {
            return getFinder().getWebDriver().findElement(By.xpath("//nav[@id='aux']/ul/li")).isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    /**
     * @return the topNavItemsLeft
     */
    public MCWebElements getTopNavItemsLeft() {
        return topNavItemsLeft;
    }

    public boolean isTopNavItemsLeftDisplayed() {
        try {
            return getFinder().getWebDriver().findElement(By.xpath("//nav[@id='main']/h1/a")).isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public boolean isShopCatalogLinkDisplayed() {
        try {
            return getFinder().getWebDriver().findElement(By.xpath("//nav[@id='main']/ul/li/a")).isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    /**
     * @return the catalogList
     */
    public MCWebElements getCatalogList() {
        return catalogList;
    }

    public boolean isCatalogListDisplayed() {
        try {
            return getFinder().getWebDriver().findElement(By.className("landing_offer_categories")).isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    /**
     * @return the itemList
     */
    public MCWebElements getItemList() {
        return itemList;
    }

    public boolean isItemPriceDisplayed() {
        try {
            return getFinder().getWebDriver().findElement(By.className("item_price")).isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    /**
     * @return the seeMoreLink
     */
    public MCWebElement getSeeMoreLink() {
        return seeMoreLink;
    }

    /**
     * Saves the token to enable access by URL
     */
    public void saveCsrfToken() {
        String currentURL = getFinder().getWebDriver().getCurrentUrl();
        CsfrToken.setCrfsToken(currentURL.split(SPLIT_VALUE)[1]);
    }


    @Override
    protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        Collection<ExpectedCondition<WebElement>> conditions = new ArrayList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("aux")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='aux']/ul/li[1]/a")));
        return conditions;
    }

}
