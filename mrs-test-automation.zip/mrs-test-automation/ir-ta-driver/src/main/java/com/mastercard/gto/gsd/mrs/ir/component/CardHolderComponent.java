package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 12/15/2016.
 */
@Component
public class CardHolderComponent extends AbstractComponent {

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="first_nam")
    private MCWebElement firstNameInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="last_nam")
    private MCWebElement lastNameInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="country")
    private MCWebElement countrySelect;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="address")
    private MCWebElement address1Input;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="address2")
    private MCWebElement address2Input;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="city")
    private MCWebElement cityInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="state")
    private MCWebElement stateInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="zip")
    private MCWebElement zipInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="phone")
    private MCWebElement businessPhoneInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="fax_num")
    private MCWebElement faxNumInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="ssn")
    private MCWebElement ssnInput;

    @PageElement(findBy= ElementsBase.FindBy.ID, valueToFind="birth_date")
    private MCWebElement birthDateInput;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "updateButton")
    private MCWebElement updateButton;

    /**
     * Type first name.
     *
     * @param firstName the first name
     */
    public void typeFirstName(String firstName) {
        this.firstNameInput.sendKeys(firstName);
        log.info("Typing the first name : " + firstName);
    }

    /**
     * Type last name.
     *
     * @param lastName the last name
     */
    public void typeLastName(String lastName) {
        this.lastNameInput.sendKeys(lastName);
        log.info("Typing the last name : " + lastName);
    }

    /**
     * Select country.
     *
     * @param country the country
     */
    public void selectCountry(String country) {
        this.countrySelect.getSelect().selectByVisibleText(country);
        log.info("Selecting country : " + country);
    }

    /**
     * Type address 1.
     *
     * @param address1 the address 1
     */
    public void typeAddress1(String address1) {
        this.address1Input.sendKeys(address1);
        log.info("Typing the address 1: " + address1);
    }

    /**
     * Type address 2.
     *
     * @param address2 the address 2
     */
    public void typeAddress2(String address2) {
        this.address2Input.sendKeys(address2);
        log.info("Typing the address 2: " + address2);
    }

    /**
     * Type city.
     *
     * @param city the city
     */
    public void typeCity(String city) {
        this.cityInput.sendKeys(city);
        log.info("Typing the city: " + city);
    }

    /**
     * Type state.
     *
     * @param state the state
     */
    public void typeState(String state) {
        this.stateInput.sendKeys(state);
        log.info("Typing the state: " + state);
    }

    /**
     * Type zip.
     *
     * @param zip the zip
     */
    public void typeZip(String zip) {
        this.zipInput.sendKeys(zip);
        log.info("Typing the zip: " + zip);
    }

    /**
     * Type business phone.
     *
     * @param businessPhone the business phone
     */
    public void typeBusinessPhone(String businessPhone) {
        this.businessPhoneInput.sendKeys(businessPhone);
        log.info("Typing the business phone: " + businessPhone);
    }

    /**
     * Type fax number.
     *
     * @param faxNumber the fax number
     */
    public void typeFaxNumber(String faxNumber) {
        this.faxNumInput.sendKeys(faxNumber);
        log.info("Typing the fax number: " + faxNumber);
    }

    /**
     * Type ssn.
     *
     * @param ssnNumber the ssn number
     */
    public void typeSSN(String ssnNumber) {
        this.ssnInput.sendKeys(ssnNumber);
        log.info("Typing the ssn: ***");
    }

    /**
     * Type date of birth.
     *
     * @param dateOfBirth the date of birth
     */
    public void typeDateOfBirth(String dateOfBirth) {
        this.birthDateInput.sendKeys(dateOfBirth);
        log.info("Typing the date of birth: " + dateOfBirth);
    }

    /**
     * Click on submit button.
     */
    public void clickOnSubmitButton(){
        this.updateButton.click();
        log.info("Clicked on Update button");
    }

    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("first_nam")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("last_nam")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("country")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("address")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("address2")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("city")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("state")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("zip")));

        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("business_phone")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("fax_num")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("ssn")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("birth_date")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("updateButton")));

        return conditions;
    }
}
