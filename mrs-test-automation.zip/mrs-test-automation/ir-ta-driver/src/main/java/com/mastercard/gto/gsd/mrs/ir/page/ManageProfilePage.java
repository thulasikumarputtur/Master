package com.mastercard.gto.gsd.mrs.ir.page;

import com.mastercard.gto.gsd.mrs.ir.component.UpdateProfileComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * Created by e054649 on 11/11/2016.
 */
@Component
public class ManageProfilePage extends AbstractPage {

    @PageElement(findBy = ElementsBase.FindBy.CLASS, valueToFind = "success")
    private MCWebElement successMessage;

    @PageElement(findBy = ElementsBase.FindBy.CLASS, valueToFind = "error")
    private MCWebElement errorMessage;

    @PageElement(findBy = ElementsBase.FindBy.CLASS, valueToFind = "update_security_info")
    private MCWebElement securityInformationSection;

    @PageElement(findBy = ElementsBase.FindBy.CLASS, valueToFind = "notification_preferences")
    private MCWebElement notificationPreferenceSection;

    @PageElement(findBy = ElementsBase.FindBy.CLASS, valueToFind = "personal_information")
    private MCWebElement cardHolderInformation;

    @PageElement(findBy = ElementsBase.FindBy.CLASS, valueToFind = "travel_program")
    private MCWebElement travelProgramSection;

    @Autowired
    private UpdateProfileComponent updateProfileComponent;

    public void navigateToLandingPageUrl(String landingPageUrl){
        getFinder().getWebDriver().get(landingPageUrl);

    }

    /**
     *
     * @return the UpdateProfileComponent
     */
    public UpdateProfileComponent getUpdateProfileComponent() {
        return updateProfileComponent;
    }

    /**
     *
     * @return the successMessage
     */
    public MCWebElement getSuccessMessage() {
        return successMessage;
    }

    /**
     *
     * @return the errorMessage
     */
    public MCWebElement getErrorMessage() {
        return errorMessage;
    }

    /**
     * Gets security information section.
     *
     * @return the security information section
     */
    public MCWebElement getSecurityInformationSection() {
        return securityInformationSection;
    }

    /**
     * Get notification preference section.
     *
     * @return the notification preference section
     */
    public  MCWebElement getNotificationPreferenceSection(){
        return notificationPreferenceSection;
    }

    /**
     * Gets card holder information section.
     *
     * @return the card holder information section.
     */
    public MCWebElement getCardHolderInformation() {
        return cardHolderInformation;
    }

    /**
     * Gets travel program section.
     *
     * @return the travel program section
     */
    public MCWebElement getTravelProgramSection() {
        return travelProgramSection;
    }

    @Override
    protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        return null;
    }
}
