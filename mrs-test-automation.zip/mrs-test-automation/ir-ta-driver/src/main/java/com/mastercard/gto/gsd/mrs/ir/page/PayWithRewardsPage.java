package com.mastercard.gto.gsd.mrs.ir.page;

import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.element.MCWebElements;
import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Locale;

/**
 * Created by e053700 on 04/25/2017.
 */

@Component
public class PayWithRewardsPage extends AbstractPage {

	public static final String ENABLED_FOR_ALL_TRANSACTIONS_BUTTON_LOCATOR = "//*[@id=\"tab1Content\"]/dd[1]/div/fieldset/div[2]/div[2]/div/button";
	public static final String DISABLE_PAY_WITH_REWARDS_BUTTON_LOCATOR = "//*[@id=\"tab1Content\"]/dd[1]/div/fieldset/div[2]/div[3]/div/button";
	public static final String ENABLED_ONLY_NEXT_TRANSACTION_BUTTON = "//*[@id=\"tab1Content\"]/dd[1]/div/fieldset/div[2]/div[1]/div/button";
	public static final String CARDHOLDER_THRESHOLD_INPUT_LOCATOR = "cardholderThreshold";
	public static final String APPLY_THRESHOLD_BUTTON_LOCATOR = "//*[@id=\"tab1Content\"]/dd[1]/div/fieldset/div[1]/div[4]/label/button";
	public static final String CURRENT_STATUS_LABEL_LOCATOR = "//*[@id=\"tab1Content\"]/dd[1]/div/fieldset/div[1]/div[1]/label/span[2]";
	public static final String CONFIRMATION_MESSSAGE_LOCATOR = "//*[@id=\"page_status_rtr\"]/ul/li";


	@PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = "//div[@class='small-54 small-offset-3 columns']//h2")
	private MCWebElement pageTitle;

	// PWR ENROLLMENT
	@PageElement(findBy = FindBy.CLASS, valueToFind = "pwr_select_card_button")
	private MCWebElement selectCardButton;
	
	@PageElement(findBy = FindBy.CLASS, valueToFind = "pwr_update_card_button")
	private MCWebElement updateCardButton;

	@PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "pwrl_account_id")
	private MCWebElement selectCardDropdown;//select[@id="pwrl_account_id"]/option[2]  UBC CREDIT XXXXXXXXXXXX0060

	@PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "enrollButton")
	private MCWebElement enrollButton;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//dd[@id='card_settings_view_1']//p[2]/span")
	private MCWebElement enrollPWRSuccessMessage;	
	
	// AUTOMATIC REDEMPTION

	private MCWebElement automaticWithRewardsTitle;

	// MANUAL REDEMPTION
	@PageElement(findBy = FindBy.CLASS, valueToFind = "pwr_manual_redeem_button")
	private MCWebElement manualPayButton;

	@PageElement(findBy = FindBy.CLASS, valueToFind = "value currency")
	private MCWebElement pointsAvailable;

	@PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "redeem_pts_select")
	private MCWebElement pointsInputField;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//dd[@id='ajaxManual']//div[@class='row'][1]//span[@class='value']")
	private MCWebElement pointsToRedeem;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//dd[@id='ajaxManual']//div[@class='row'][2]//span[@class='value']")
	private MCWebElement pointsRemaining;

	@PageElement(findBy = FindBy.CLASS, valueToFind = "pwr_manual_calculate_button")
	private MCWebElement calculateButton;

	@PageElement(findBy = FindBy.CLASS, valueToFind = "pwr_manual_confirm_button primary")
	private MCWebElement continueManualPwrButton;

	@PageElement(findBy = FindBy.CLASS, valueToFind = "pwr_manual_confirm_sec_button primary")
	private MCWebElement confirmManualPwrButton;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//dd[@id='ajaxManual']//p")
	private MCWebElement manualPWRSuccessMessage;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@class='tabs']//dd//a")
	private MCWebElements tabs;

	/*# REAL TIME REWARDS#*/

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id=\"tab1Content\"]/dd[1]/div/fieldset/div/div[1]/label/span[1]")
	private MCWebElement accountStatusLabel;

	@PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = ENABLED_FOR_ALL_TRANSACTIONS_BUTTON_LOCATOR)
	private MCWebElement enabledAllTransactionButton;

	@PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = ENABLED_ONLY_NEXT_TRANSACTION_BUTTON)
	private MCWebElement enabledOnlyNextTransactionButton;

	@PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = DISABLE_PAY_WITH_REWARDS_BUTTON_LOCATOR)
	private MCWebElement disablePayWithRewardsButton;

	@PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = CARDHOLDER_THRESHOLD_INPUT_LOCATOR)
	private MCWebElement minimumCashAmount;

	@PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = APPLY_THRESHOLD_BUTTON_LOCATOR)
	private MCWebElement applyThresholdButton;

	@PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = CURRENT_STATUS_LABEL_LOCATOR)
	private MCWebElement currentStatusLabel;

	@PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = CONFIRMATION_MESSSAGE_LOCATOR)
	private MCWebElement confirmationMessage;

	public void clickOnEnabledOnlyForNextTransactionButton(){
		this.enabledOnlyNextTransactionButton.click();
		log.info("Clicked on enabledOnlyNextTransactionButton");
	}

	public void clickOnEnabledForAllTransactionsButton(){
		this.enabledAllTransactionButton.click();
		log.info("Clicked on enabledAllTransactionButton");
	}

	public void clickOnDisablePayWithRewardsButton(){
		this.disablePayWithRewardsButton.click();
		log.info("Clicked on disablePayWithRewardsButton");
	}

	public void typeMinimumAmount(String amount){
		this.minimumCashAmount.sendKeys(amount);
		log.info("Typed minimum amount: " + amount);
	}

	public void clickOnApplyThresholdButton(){
		this.applyThresholdButton.click();
		log.info("Clicked on applyThresholdButton");
	}

	public MCWebElement getCurrentStatusLabel() {
		return currentStatusLabel;
	}

	public boolean checkConfirmationMessageVisibility() {
		try{
			confirmationMessage = getFinder().findOne(FindBy.X_PATH, CONFIRMATION_MESSSAGE_LOCATOR, 2, 1000);
			return confirmationMessage.isVisible();
		}catch(Exception e){
			log.info("Confirmation message label is not visible.");
			return false;
		}
	}

	public String getPageTitleText() {
		log.info("Page Title: " + pageTitle.getText());
		return pageTitle.getText();
	}

    public boolean checkSelectCardButtonIsVisible() {
		try {
			MCWebElement selectCardButtonLocal = getFinder().findOne(FindBy.CLASS, "pwr_select_card_button", 2, 1000);
			log.info("Select Card button is visible.");
			return selectCardButtonLocal.isVisible();
		} catch (Exception e) {
			log.info("Select Card button is not visible.");
			return false;
		}
    }

	public boolean checkAutomaticPayWithRewardsIsVisible() {
		try {
			automaticWithRewardsTitle = getFinder().findOne(FindBy.X_PATH, "//*[@id=\"ajax\"]/h3", 2, 1000);
			log.info("Automatic pay with rewards section is visible.");
			return automaticWithRewardsTitle.isVisible();
		} catch (Exception e) {
			log.info("Automatic pay with rewards section is not visible.");
			return false;
		}
	}

    public boolean checkUpdateCardButtonIsVisible() {
		try {
			MCWebElement updateCardButtonLocal = getFinder().findOne(FindBy.CLASS, "pwr_update_card_button", 2, 1000);
			log.info("Update Card button is visible.");
			return updateCardButtonLocal.isVisible();
		} catch (Exception e) {
			log.info("Update Card button is not visible.");
			return false;
		}
    }
	
	public void clickSelectCardButton() {
		selectCardButton.click();
		log.info("Clicked on Select Card button.");
	}

	public MCWebElement getAutomaticWithRewardsTitle() {
		return automaticWithRewardsTitle;
	}

	public void clickUpdateCardButton() {
		updateCardButton.click();
		log.info("Clicked on Update Card button.");
	}

    public boolean checkSelectCardIsVisible() {
		boolean visibility = selectCardDropdown.isVisible();
		log.info("Select Card dropdown is visible.");
		return visibility;
    }
    
	public void selectCardDropDownValue(int cardIndex){
		selectCardDropdown.getSelect().selectByIndex(cardIndex);
		log.info("Card on index number " + cardIndex + " selected.");
	}
	
	public void clickEnrollPWRCardButton() {
		enrollButton.click();
		log.info("Clicked on Confirm Card for PWR button.");
	}
	
	public String getEnrollPWRSuccessMessageText() {
		return enrollPWRSuccessMessage.getText();
	}

	public boolean checkManualPayButtonIsVisible() {
		try {
			MCWebElement manualPWRButtonLocal = getFinder().findOne(FindBy.CLASS, "pwr_manual_redeem_button", 2, 1000);
			log.info("Manual PWR button is visible.");
			return manualPWRButtonLocal.isVisible();
		} catch (Exception e) {
			log.info("Manual PWR button is not visible.");
			return false;
		}
	}
		
	public void clickManualPayButton() {
		manualPayButton.click();
		log.info("Clicked on Manual PWR button.");
	}

	public MCWebElement getEnabledAllTransactionButton() {
		return enabledAllTransactionButton;
	}

	public MCWebElement getEnabledOnlyNextTransactionButton() {
		return enabledOnlyNextTransactionButton;
	}

	public MCWebElement getDisablePayWithRewardsButton() {
		return disablePayWithRewardsButton;
	}

	public boolean checkTypePWRAmountFieldIsVisible() {
		boolean visibility = pointsInputField.isVisible();
		log.info("Points input field is visible.");
		return visibility;
	}	

	public void typePWRAmount(int amount) {
		pointsInputField.sendKeys(String.valueOf(amount));
		log.info("Input amount of " + amount);
	}

	public int getPointsAvailableValue() {
		int pa = 0;
		String v = pointsAvailable.getText().substring(1);
		try {
			pa = NumberFormat.getNumberInstance(Locale.US).parse(v).intValue();
		} catch (ParseException e) {
			log.info("Could not parse Points Available amount to INT.");
			e.printStackTrace();
		}
		log.info("Points available = " + pa);
		return pa;
	}

	public int getPointsToRedeemValue() {
		int ptr = 0;
		try {
			ptr = NumberFormat.getNumberInstance(Locale.US).parse(pointsToRedeem.getText()).intValue();
		} catch (ParseException e) {
			log.info("Could not parse Points to Redeem amount to INT.");
			e.printStackTrace();
		}
		log.info("Points to redeem = " + ptr);
		return ptr;
	}

	public int getPointsRemainingValue() {
		int pr = 0;
		try {
			pr = NumberFormat.getNumberInstance(Locale.US).parse(pointsRemaining.getText()).intValue();
		} catch (ParseException e) {
			log.info("Could not parse Points Remaining amount to INT.");
			e.printStackTrace();
		}
		log.info("Points remaining = " + pr);
		return pr;
	}
	
	public void clickCalculateButton() {
		calculateButton.click();
		log.info("Clicked on Calculate button.");
	}
	
	public void clickContinueManualPWRButton() {
		continueManualPwrButton.click();
		log.info("Clicked on Continue button.");
	}

	public boolean checkConfirmManualPWRButtonIsVisible() {
		boolean visibility = confirmManualPwrButton.isVisible();
		log.info("Confirmation button is visible.");
		return visibility;
	}	
	
	public void clickConfirmManualPWRButton() {
		confirmManualPwrButton.click();
		log.info("Clicked on Confirm button.");
	}
	
	public String getManualPWRSuccessMessageText() {
		return manualPWRSuccessMessage.getText();
	}

	public boolean isTabPresent(String tabName) {
		for (MCWebElement mcWebElement : tabs.getElements()) {
			if(mcWebElement.getText().equalsIgnoreCase(tabName))
				return true;
		}

		return false;
	}

	public void clickOnTab(String tabName){
		for (MCWebElement mcWebElement : tabs.getElements()) {
			if(mcWebElement.getText().equalsIgnoreCase(tabName))
				return;
		}
	}

	public MCWebElement getAccountStatusLabel(){
		return this.accountStatusLabel;
	}
	

	@Override
	protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		Collection<ExpectedCondition<WebElement>> conditions = new ArrayList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//div[@class='small-54 small-offset-3 columns']//h2")));
		return conditions;
	}
}
