package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.element.MCWebElements;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;


@Component
public class NavigationMenuComponent extends AbstractComponent {

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = "//nav[@class='sidebar_menu hide-for-small-only']//a")
    private MCWebElements navigationMenu;

    /**Clicks on a navigation item link
     *
     * @param navigationItem the navigation item to be clicked.
     */

    public void clickOnNavigationItem(String navigationItem) {

        log.info("Navigation item links:\n" + navigationMenu.getText());
        for(MCWebElement result : navigationMenu.getElements()){
            if(navigationItem.equalsIgnoreCase(result.getText())){
                log.info("Clicking on link: " + result.getText());
                result.click();
                break;
            }
        }
    }
    
    public boolean navigationItemIsPresent(String navigationItem) {
    	
    	boolean itemExistence = false;
        log.info("Navigation item links:\n" + navigationMenu.getText());
    	for(MCWebElement result : navigationMenu.getElements()){
            if(result.getText().contains(navigationItem)){
                log.info("Link " + result.getText() + " exists.");
                itemExistence = true;
                break;
            }
        }
    	return itemExistence;
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.className("sidebar_menu hide-for-small-only")));

        return conditions;
    }
}
