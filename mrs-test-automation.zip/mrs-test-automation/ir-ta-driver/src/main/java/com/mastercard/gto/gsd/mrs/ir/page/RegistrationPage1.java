package com.mastercard.gto.gsd.mrs.ir.page;

import java.util.ArrayList;
import java.util.Collection;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

@Component
public class RegistrationPage1 extends AbstractPage {
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//form[@id='RegisterForm']/h2")
    private MCWebElement pageTitle;
		
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//form[@id='RegisterForm']/p")
    private MCWebElement formMessage;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='label_customer_num']")
    private MCWebElement customerNumLabel;
	
	@PageElement(findBy = FindBy.ID, valueToFind = "bank_customer_num")
    private MCWebElement customerNumInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='reg_name_prefix']")
    private MCWebElement namePrefixLabel;
	
	@PageElement(findBy = FindBy.NAME, valueToFind = "reg_name_prefix")
    private MCWebElement namePrefixInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='first_name']")
    private MCWebElement firstNameLabel;
	
	@PageElement(findBy = FindBy.ID, valueToFind = "first_nam")
    private MCWebElement firstNameInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='last_name']")
    private MCWebElement lastNameLabel;
	
	@PageElement(findBy = FindBy.ID, valueToFind = "last_nam")
    private MCWebElement lastNameInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='reg_name_suffix']")
    private MCWebElement nameSuffixLabel;
	
	@PageElement(findBy = FindBy.NAME, valueToFind = "reg_name_suffix")
    private MCWebElement nameSuffixInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='country']/span")
    private MCWebElement countryLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "country")
    private MCWebElement countrySelection;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='address_line_1']")
    private MCWebElement address1Label;

	@PageElement(findBy = FindBy.ID, valueToFind = "address")
    private MCWebElement address1Input;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='address_line_2']")
    private MCWebElement address2Label;

	@PageElement(findBy = FindBy.ID, valueToFind = "address2")
    private MCWebElement address2Input;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='city']")
    private MCWebElement cityLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "city")
    private MCWebElement cityInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='state']")
    private MCWebElement stateLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "state")
    private MCWebElement stateInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='postal']")
    private MCWebElement zipLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "zip")
    private MCWebElement zipInput;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='business_phone']")
    private MCWebElement busPhoneLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "business_phone")
    private MCWebElement busPhoneInput;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='fax_phone']")
    private MCWebElement faxPhoneLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "fax_num")
    private MCWebElement faxPhoneInput;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='ssn']")
    private MCWebElement ssnLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "ssn")
    private MCWebElement ssnInput;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='date_of_birth']")
    private MCWebElement birthLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "birth_date")
    private MCWebElement birthInput;

	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='accept_terms']")
    private MCWebElement termsAndCondText;

	@PageElement(findBy = FindBy.ID, valueToFind = "tandc")
    private MCWebElement termsAndCondCheckbox;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_submit")
    private MCWebElement reg1NextButton;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_cancel")
    private MCWebElement reg1CancelButton;
	
	
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    public MCWebElement getFormMessage() {
        return formMessage;
    }

    /**
     * @return the Form Labels
     */
    public MCWebElement getCustomerNumberLabel() {
        return customerNumLabel;
    }

    public MCWebElement getNamePrefixLabel() {
        return namePrefixLabel;
    }

    public MCWebElement getFirstNameLabel() {
        return firstNameLabel;
    }

    public MCWebElement getLastNameLabel() {
        return lastNameLabel;
    }

    public MCWebElement getNameSuffixLabel() {
        return nameSuffixLabel;
    }

    public MCWebElement getCountryLabel() {
        return countryLabel;
    }

    public MCWebElement getAddress1Label() {
        return address1Label;
    }

    public MCWebElement getAddress2Label() {
        return address2Label;
    }

    public MCWebElement getCityLabel() {
        return cityLabel;
    }

    public MCWebElement getStateLabel() {
        return stateLabel;
    }

    public MCWebElement getZipLabel() {
        return zipLabel;
    }

    public MCWebElement getBusPhoneLabel() {
        return busPhoneLabel;
    }

    public MCWebElement getFaxPhoneLabel() {
        return faxPhoneLabel;
    }

    public MCWebElement getSsnLabel() {
        return ssnLabel;
    }

    public MCWebElement getBirthLabel() {
        return birthLabel;
    }
    
    /**
     * Form Inputs
     */
    public void typeCustomerNumberInput(String regCustomerNumber) {
        customerNumInput.sendKeys(regCustomerNumber);
        log.info("Typing Customer Number: " + regCustomerNumber);
    }

    public void typeNamePrefixInput(String regNamePrefix) {
    	namePrefixInput.sendKeys(regNamePrefix);
        log.info("Typing Name Prefix: " + regNamePrefix);
    }

    public void typeFirstNameInput(String regFirstName) {
        firstNameInput.sendKeys(regFirstName);
        log.info("Typing First Name: " + regFirstName);
    }

    public void typeLastNameInput(String regLastName) {
    	lastNameInput.sendKeys(regLastName);
        log.info("Typing Last Name: " + regLastName);
    }

    public void typeNameSuffixInput(String regNameSuffix) {
    	nameSuffixInput.sendKeys(regNameSuffix);
        log.info("Typing Name Suffix: " + regNameSuffix);
    }

    public void selectCountry(String regCountry) {
    	countrySelection.getSelect().selectByVisibleText(regCountry);
        log.info("Selecting Country: " + regCountry);
    }

    public void typeAddress1Input(String regAddress1) {
    	address1Input.sendKeys(regAddress1);
        log.info("Typing Address 1: " + regAddress1);
    }

    public void typeAddress2Input(String regAddress2) {
    	address2Input.sendKeys(regAddress2);
        log.info("Typing Address 2: " + regAddress2);
    }

    public void typeCityInput(String regCity) {
    	cityInput.sendKeys(regCity);
        log.info("Typing City: " + regCity);
    }

    public void typeStateInput(String regState) {
    	stateInput.sendKeys(regState);
        log.info("Typing State: " + regState);
    }

    public void typeZipInput(String regZip) {
    	zipInput.sendKeys(regZip);
        log.info("Typing Zip: " + regZip);
    }

    public void typeBusPhoneInput(String regBusPhone) {
    	busPhoneInput.sendKeys(regBusPhone);
        log.info("Typing Bus Phone: " + regBusPhone);
    }

    public void typeFaxPhoneInput(String regFax) {
    	faxPhoneInput.sendKeys(regFax);
        log.info("Typing Fax: " + regFax);
    }

    public void typeSsnInput(String regSsn) {
    	ssnInput.sendKeys(regSsn);
        log.info("Typing SSN: " + regSsn);
    }

    public void typeBirthInput(String regBirth) {
    	birthInput.sendKeys(regBirth);
        log.info("Typing Birthdate: " + regBirth);
    }

    /**
     * Terms and Conditions field
     */
    public MCWebElement getTermsAndCondText() {
        return termsAndCondText;
    }

    public void checkTermsAndCondCheckbox() {
    	termsAndCondCheckbox.click();
        log.info("Checked Terms and Conditions");
    }
    
    /**
     * submitButton
     */
    public MCWebElement getRegNextButton() {
        return reg1NextButton;
    }
    
    public void clickNextButton() {
    	reg1NextButton.click();
        log.info("Clicked on Next Button.");
    }

    /**
     * click the cancelButton
     */
    public void clickCancelButton() {
    	reg1CancelButton.click();
        log.info("Clicked on Cancel Button.");
    }
	
	public String getCurrentUrl(){
		log.info("Current URL : " + getFinder().getWebDriver().getCurrentUrl());
		return getFinder().getWebDriver().getCurrentUrl();
	}
	

	@Override
	protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		Collection<ExpectedCondition<WebElement>> conditions = new ArrayList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form[@id='RegisterForm']/h2")));
		return conditions;
	}

}
