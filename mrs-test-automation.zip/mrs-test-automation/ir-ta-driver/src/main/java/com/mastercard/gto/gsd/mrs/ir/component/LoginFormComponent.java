package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.element.MCWebElements;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

@Component
public class LoginFormComponent extends AbstractComponent {

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//div[@id='fancybox-content']/div/header/h3")
    private MCWebElement pageTitle;

    @PageElement(findBy = FindBy.ID, valueToFind = "user_id")
    private MCWebElement userIdInput;

    @PageElement(findBy = FindBy.ID, valueToFind = "user_pwd")
    private MCWebElement passwordInput;

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id=\"form_login\"]/fieldset/div[3]/div/button")
    private MCWebElement loginButton;

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id=\"fancybox-content\"]/div/footer/div")
    private MCWebElements footerButtonsContainer;
    
    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id=\"fancybox-content\"]/div/footer/div[2]/div/a")
    private MCWebElements loginUsingAccountNumber;

    @PageElement(findBy = FindBy.CLASS, valueToFind = "error")
    private MCWebElement errorMessage;

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id=\"form_login\"]/p/a[1]")
    private MCWebElement forgotUserIdLink;

    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//*[@id=\"form_login\"]/p/a[2]")
    private MCWebElement forgotPasswordLink;

    /**
     * @return the errorMessage
     */
    public MCWebElement getErrorMessage() {
        return errorMessage;
    }

    /**
     * @return the forgotPasswordLink
     */
    public MCWebElement getForgotPasswordLink() {
        return forgotPasswordLink;
    }

    /**
     * @return the pageTitle
     */
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    /**
     * @return the userIdInput
     */
    public MCWebElement getUserIdInput() {
        return userIdInput;
    }

    /**
     * @return the passwordInput
     */
    public MCWebElement getPasswordInput() {
        return passwordInput;
    }

    /**
     * @return the loginButton
     */   
    public MCWebElement getLoginButton() {
        return loginButton;
    }

    public boolean isLoginUsingAccountNumberButtonDisplayed() {
        if (footerButtonsContainer.getElements().size() > 1){
        	return true;
        } else {
        	return false;	
        }
    }
    

    public void typeUsername(String username) {
        userIdInput.sendKeys(username);
        log.info("Typing username text: " + username);
    }

    public void typePasswordInput(String password) {
        passwordInput.sendKeys(password);
        log.info("Typing password text: " + password);
    }

    public void performLogin() {
        loginButton.click();
        log.info("Clicked on Login Button.");
    }

    public void clickForgotUserId() {
        forgotUserIdLink.click();
        log.info("Clicked on Forgot User Id link");
    }

    public void clickForgotPassword() {
        forgotPasswordLink.click();
        log.info("Clicked on Forgot Password link");
    }

    
    public void clickLoginUsingAccountNumberButton(String buttonLinkName) {

        for (MCWebElement result : loginUsingAccountNumber.getElements()) {
            log.info("There is the link: " + result.getText());
            if (buttonLinkName.equalsIgnoreCase(result.getText())) {
                log.info("Clicking on Login Button: " + result.getText());
                result.click();
                break;
            }
        }
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("user_id")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("user_pwd")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"form_login\"]/fieldset/div[3]/div/button")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"form_login\"]/p/a[2]")));
        return conditions;
    }

}
