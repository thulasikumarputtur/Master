package com.mastercard.gto.gsd.mrs.ir.component;

import java.util.Collection;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

@Component
public class LoginFormResultsComponent extends AbstractComponent {
	
	@PageElement(findBy=FindBy.X_PATH, valueToFind="//*[@id=\"logged_panel\"]/ul/li[2]/a")
	private MCWebElement pageTitle;
	
	public String getUserName(){
		return pageTitle.getText();
	}

	@Override
	public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		return null;
	}

}
