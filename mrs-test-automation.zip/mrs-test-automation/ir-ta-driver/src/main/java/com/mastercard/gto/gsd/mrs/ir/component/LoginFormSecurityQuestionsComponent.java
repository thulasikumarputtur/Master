package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

@Component
public class LoginFormSecurityQuestionsComponent extends AbstractComponent {
	
    @PageElement(findBy = FindBy.X_PATH, valueToFind = "//div[@id='fancybox-content']/div/header/h3")
    private MCWebElement pageTitle;

    @PageElement(findBy = FindBy.ID, valueToFind = "ssn")
    private MCWebElement ssnInput;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_submit")
    private MCWebElement submitButton;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_cancel")
    private MCWebElement cancelButton;
    
    @PageElement(findBy = FindBy.CLASS, valueToFind = "error")
    private MCWebElement errorMessage;

    @PageElement(findBy = FindBy.ID, valueToFind = "birth_date")
    private MCWebElement birthDateInput;

    @PageElement(findBy = FindBy.ID, valueToFind = "mmn")
    private MCWebElement mothersMaidenNameInput;

    @PageElement(findBy = FindBy.ID, valueToFind = "phone")
    private MCWebElement phoneInput;

    @PageElement(findBy = FindBy.ID, valueToFind = "generic")
    private MCWebElement genericInfoInput;

    /**
     * Type date of birth.
     *
     * @param dateOfBirth the date of birth
     */
    public void typeDateOfBirth(String dateOfBirth){
        this.birthDateInput.sendKeys(dateOfBirth);
        log.info("Typing date of birth: " + dateOfBirth);
    }

    /**
     * Type mothers maiden name.
     *
     * @param mothersMaidenName the mothers maiden name
     */
    public void typeMothersMaidenName(String mothersMaidenName){
        this.mothersMaidenNameInput.sendKeys(mothersMaidenName);
        log.info("Typing mother's maiden name: " + mothersMaidenName);
    }

    /**
     * Type phone number.
     *
     * @param phoneNumber the phone number
     */
    public void typePhoneNumber(String phoneNumber){
        this.phoneInput.sendKeys(phoneNumber);
        log.info("Typing home phone number: "+ phoneNumber);
    }

    /**
     * Type generic info.
     *
     * @param genericInfo the generic info
     */
    public void typeGenericInfo(String genericInfo){
        this.genericInfoInput.sendKeys(genericInfo);
        log.info("Typing generic info: " + genericInfo);
    }

    /**
     * @return the errorMessage
     */
    public MCWebElement getErrorMessage() {
        return errorMessage;
    }

    /**
     * @return the pageTitle
     */
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    /**
     * @return the ssnInput
     */
    public MCWebElement getSsnInput() {
        return ssnInput;
    }
    
    public void typeSSN(String ssn) {
        ssnInput.sendKeys(ssn);
        log.info("Typing ssn: " + ssn);
    }
	
    
	public void clickSubmitButton(){
		submitButton.click();
		log.info("Clicked on Submit button");
	}

	@Override
	public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("ssn")));
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_submit")));
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("btn_cancel")));
		return conditions;
	}
	
}
