package com.mastercard.gto.gsd.mrs.ir.page;

import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * Created by e054649 on 12/21/2016.
 */

@Component
public class ManageAccountsPage extends AbstractPage {

    public void navigateToLandingPageUrl(String landingPageUrl){
        getFinder().getWebDriver().get(landingPageUrl);
    }

    @Override
    protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        return null;
    }
}
