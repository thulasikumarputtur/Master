package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import com.mastercard.testing.mtaf.ui.util.BrowserUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 5/29/2017.
 */

@Component
public class OnlineMallComponent extends AbstractComponent {

    public static final String BUTTON_MALL_LOCATOR = "//*[@id=\"mall\"]/a";

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = BUTTON_MALL_LOCATOR)
    private MCWebElement confirmationButton;

    @Autowired
    private BrowserUtils browserUtils;

    /**
     * Click on confirmation button.
     */
    public void clickOnConfirmationButton(){
        confirmationButton.click();
        log.info("Clicked on online mall confirmation button");
    }

    /**
     * Switch to last open window.
     */
    public void switchToLastOpenWindow() {
        browserUtils.switchToLastWindowOpened();
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath(BUTTON_MALL_LOCATOR)));

        return conditions;
    }
}
