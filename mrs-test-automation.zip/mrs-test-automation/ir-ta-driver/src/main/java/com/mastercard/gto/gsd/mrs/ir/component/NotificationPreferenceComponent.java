package com.mastercard.gto.gsd.mrs.ir.component;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 12/13/2016.
 */
@Component
public class NotificationPreferenceComponent extends AbstractComponent {

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "mobile_phone_num")
    private MCWebElement mobileNumberField;

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = "//*[@id=\"notification_preferences\"]/fieldset/div[2]/div[2]/label/input")
    private MCWebElement retypeMobileNumberField;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "email_addr")
    private MCWebElement emailAddressField;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "email_addr_cfm")
    private MCWebElement retypeEmailAddressField;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "notifPrefUpdBtn")
    private MCWebElement updateNotificationPreferenceButton;


    /**
     * Type mobile number.
     *
     * @param text the text
     */
    public void typeMobileNumber(String text){
        this.mobileNumberField.sendKeys(text);
        log.info("Typing the mobile number:" + text);
    }

    /**
     * Retype mobile number.
     *
     * @param text the text
     */
    public void retypeMobileNumber(String text){
        this.retypeMobileNumberField.sendKeys(text);
        log.info("Retyping the mobile number:" + text);
    }

    /**
     * Type email address.
     *
     * @param text the text
     */
    public void typeEmailAddress(String text){
        this.emailAddressField.sendKeys(text);
        log.info("Typing the mobile number:" + text);
    }

    /**
     * Retype email address.
     *
     * @param text the text
     */
    public void retypeEmailAddress(String text){
        this.retypeEmailAddressField.sendKeys(text);
        log.info("Retyping the email address:" + text);
    }

    /**
     * Clicks on the update button
     */
    public void clickOnSubmitButton() {
        this.updateNotificationPreferenceButton.click();
        log.info("Clicked on Update button");
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("mobile_phone_num")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("//*[@id=\"notification_preferences\"]/fieldset/div[2]/div[2]/label/input")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("email_addr")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("email_addr_cfm")));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id("notifPrefUpdBtn")));

        return conditions;
    }
}
