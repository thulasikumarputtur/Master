package com.mastercard.gto.gsd.mrs.ir.page;

import java.util.ArrayList;
import java.util.Collection;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import com.mastercard.testing.mtaf.bindings.element.ElementsBase.FindBy;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import com.mastercard.testing.mtaf.bindings.page.PageElement;

@Component
public class RegistrationPage2 extends AbstractPage {
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//form[@id='RegisterForm']/h2")
    private MCWebElement pageTitle;
		
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//form[@id='RegisterForm']/p")
    private MCWebElement formMessage;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='user_id']")
    private MCWebElement userIdLabel;
	
	@PageElement(findBy = FindBy.ID, valueToFind = "user_id")
    private MCWebElement userIdInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='password']")
    private MCWebElement passwordLabel;
	
	@PageElement(findBy = FindBy.ID, valueToFind = "user_pwd")
    private MCWebElement passwordInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='retype_password']")
    private MCWebElement passwordCfmLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "user_pwd_cfm")
    private MCWebElement passwordCfmInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='challenge_question_0']/span")
    private MCWebElement secQuestion0Label;

	@PageElement(findBy = FindBy.ID, valueToFind = "challenge_question0")
    private MCWebElement secQuestion0Selection;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='challenge_answer_0']")
    private MCWebElement answer0Label;

	@PageElement(findBy = FindBy.ID, valueToFind = "challenge_answer0")
    private MCWebElement answer0Input;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='challenge_answer_cfm_0']")
    private MCWebElement answer0CfmLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "challenge_answer_cfm0")
    private MCWebElement answer0CfmInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='challenge_question_1']/span")
    private MCWebElement secQuestion1Label;

	@PageElement(findBy = FindBy.ID, valueToFind = "challenge_question1")
    private MCWebElement secQuestion1Selection;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='challenge_answer_1']")
    private MCWebElement answer1Label;

	@PageElement(findBy = FindBy.ID, valueToFind = "challenge_answer1")
    private MCWebElement answer1Input;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='challenge_answer_cfm_1']")
    private MCWebElement answer1CfmLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "challenge_answer_cfm1")
    private MCWebElement answer1CfmInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='challenge_question_2']/span")
    private MCWebElement secQuestion2Label;

	@PageElement(findBy = FindBy.ID, valueToFind = "challenge_question2")
    private MCWebElement secQuestion2Selection;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='challenge_answer_2']")
    private MCWebElement answer2Label;

	@PageElement(findBy = FindBy.ID, valueToFind = "challenge_answer2")
    private MCWebElement answer2Input;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='challenge_answer_cfm_2']")
    private MCWebElement answer2CfmLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "challenge_answer_cfm2")
    private MCWebElement answer2CfmInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='email_address']")
    private MCWebElement emailLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "email_addr")
    private MCWebElement emailInput;
	
	@PageElement(findBy = FindBy.X_PATH, valueToFind = "//label[@for='email_address_cfm']")
    private MCWebElement emailCfmLabel;

	@PageElement(findBy = FindBy.ID, valueToFind = "email_addr_cfm")
    private MCWebElement emailCfmInput;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_next")
    private MCWebElement reg2NextButton;

    @PageElement(findBy = FindBy.ID, valueToFind = "btn_cancel")
    private MCWebElement reg2CancelButton;
	
	
    public MCWebElement getPageTitle() {
        return pageTitle;
    }

    public MCWebElement getFormMessage() {
        return formMessage;
    }

    /**
     * @return the Form Labels
     */
    public MCWebElement getUserIdLabel() {
        return userIdLabel;
    }

    public MCWebElement getPasswordLabel() {
        return passwordLabel;
    }

    public MCWebElement getPasswordCfmLabel() {
        return passwordCfmLabel;
    }

    public MCWebElement getSecQuestion0Label() {
        return secQuestion0Label;
    }

    public MCWebElement getAnswer0Label() {
        return answer0Label;
    }

    public MCWebElement getAnswer0CfmLabel() {
        return answer0CfmLabel;
    }

    public MCWebElement getSecQuestion1Label() {
        return secQuestion1Label;
    }

    public MCWebElement getAnswer1Label() {
        return answer1Label;
    }

    public MCWebElement getAnswer1CfmLabel() {
        return answer1CfmLabel;
    }

    public MCWebElement getSecQuestion2Label() {
        return secQuestion2Label;
    }

    public MCWebElement getAnswer2Label() {
        return answer2Label;
    }

    public MCWebElement getAnswer2CfmLabel() {
        return answer2CfmLabel;
    }

    public MCWebElement getEmailLabel() {
        return emailLabel;
    }

    public MCWebElement getEmailCfmLabel() {
        return emailCfmLabel;
    }
    
    /**
     * Form Inputs
     */
    public MCWebElement getUserIdInput() {
        return userIdInput;
    }

    public void typeUserIDInput(String regUserId) {
    	userIdInput.sendKeys(regUserId);
        log.info("Typing User Id: " + regUserId);
    }

    public MCWebElement getPasswordInput() {
        return passwordInput;
    }

    public void typePasswordInput(String regPassword) {
    	passwordInput.sendKeys(regPassword);
        log.info("Typing Password: " + regPassword);
    }

    public MCWebElement getPasswordCfmInput() {
        return passwordCfmInput;
    }

    public void typePasswordCfmInput(String regPasswordCfm) {
    	passwordCfmInput.sendKeys(regPasswordCfm);
        log.info("Typing Password Confirmation: " + regPasswordCfm);
    }

    public MCWebElement getSecQuestion0Selection() {
        return secQuestion0Selection;
    }

    public void selectSecQuestion0(String regSecQuestion0) {
    	secQuestion0Selection.getSelect().selectByVisibleText(regSecQuestion0);
        log.info("Selecting Sec Question 0: " + regSecQuestion0);
    }

    public MCWebElement getAnswer0Input() {
        return answer0Input;
    }

    public void typeAnswer0Input(String regAnswer0) {
    	answer0Input.sendKeys(regAnswer0);
        log.info("Typing Answer 0: " + regAnswer0);
    }

    public MCWebElement getAnswer0CfmInput() {
        return answer0CfmInput;
    }

    public void typeAnswer0CfmInput(String regAnswer0Cfm) {
    	answer0CfmInput.sendKeys(regAnswer0Cfm);
        log.info("Typing Answer 0 Confirmation: " + regAnswer0Cfm);
    }

    public MCWebElement getSecQuestion1Selection() {
        return secQuestion1Selection;
    }

    public void selectSecQuestion1(String regSecQuestion1) {
    	secQuestion1Selection.getSelect().selectByVisibleText(regSecQuestion1);
        log.info("Selecting Sec Question 1: " + regSecQuestion1);
    }

    public MCWebElement getAnswer1Input() {
        return answer1Input;
    }

    public void typeAnswer1Input(String regAnswer1) {
    	answer1Input.sendKeys(regAnswer1);
        log.info("Typing Answer 1: " + regAnswer1);
    }

    public MCWebElement getAnswer1CfmInput() {
        return answer1CfmInput;
    }

    public void typeAnswer1CfmInput(String regAnswer1Cfm) {
    	answer1CfmInput.sendKeys(regAnswer1Cfm);
        log.info("Typing Answer 1 Confirmation: " + regAnswer1Cfm);
    }

    public MCWebElement getSecQuestion2Selection() {
        return secQuestion2Selection;
    }

    public void selectSecQuestion2(String regSecQuestion2) {
    	secQuestion2Selection.getSelect().selectByVisibleText(regSecQuestion2);
        log.info("Selecting Sec Question 2: " + regSecQuestion2);
    }

    public MCWebElement getAnswer2Input() {
        return answer2Input;
    }

    public void typeAnswer2Input(String regAnswer2) {
    	answer2Input.sendKeys(regAnswer2);
        log.info("Typing Answer 2: " + regAnswer2);
    }

    public MCWebElement getAnswer2CfmInput() {
        return answer2CfmInput;
    }

    public void typeAnswer2CfmInput(String regAnswer2Cfm) {
    	answer2CfmInput.sendKeys(regAnswer2Cfm);
        log.info("Typing Answer 2 Confirmation: " + regAnswer2Cfm);
    }

    public MCWebElement getEmailInput() {
        return emailInput;
    }

    public void typeEmailInput(String regEmail) {
    	emailInput.sendKeys(regEmail);
        log.info("Typing Email: " + regEmail);
    }

    public MCWebElement getEmailCfmInput() {
        return emailCfmInput;
    }

    public void typeEmailCfmInput(String regEmailCfm) {
    	emailCfmInput.sendKeys(regEmailCfm);
        log.info("Typing Email: " + regEmailCfm);
    }
    

    /**
     * @return the submitButton
     */
    public MCWebElement getRegNextButton() {
        return reg2NextButton;
    }

    public void clickNextButton() {
    	reg2NextButton.click();
        log.info("Clicked on Next Button.");
    }

    /**
     * @return the cancelButton
     */
    public MCWebElement getCancelButton() {
        return reg2CancelButton;
    }

    public void clickCancelButton() {
    	reg2CancelButton.click();
        log.info("Clicked on Cancel Button.");
    }
    
    
	
	public String getCurrentUrl(){
		log.info("Current URL : " + getFinder().getWebDriver().getCurrentUrl());
		return getFinder().getWebDriver().getCurrentUrl();
	}
	

	@Override
	protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
		Collection<ExpectedCondition<WebElement>> conditions = new ArrayList<ExpectedCondition<WebElement>>();
		conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='RegisterForm']/h2")));
		return conditions;
	}

}
