package com.mastercard.gto.gsd.mrs.sm;

import java.util.ArrayList;
import java.util.List;

public class AllStories extends InternetRedemptionsStories {
	@Override
	 public List<String> storyPaths() {
		/*List<String> paths = new StoryFinder().findPaths(
				CodeLocations.codeLocationFromClass(this.getClass()), "**merchandiseRedemption.story", "");

		return paths;*/
		return new ArrayList<>(0);
	}
}