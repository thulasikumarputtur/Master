package com.mastercard.gto.gsd.mrs.sm.programmaintenance;

import com.mastercard.gto.gsd.mrs.sm.components.programmaintenance.ProgramMaintenanceComponent;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 10/10/2017.
 */
@Component
public class ProgramMaintenanceSteps {

    @Autowired
    private ProgramMaintenanceComponent programMaintenanceComponent;

    @When("sm user selects customer identifier $customerIdentifier")
    public void smUserSelectsCustomerIdentifier(@Named("customerIdentifier")String customerIdentifier){
        this.programMaintenanceComponent.selectCustomerIdentifier(customerIdentifier);
        this.programMaintenanceComponent.clickOnSubmitAllValues();
    }

    @Then("sm user should return to program maintenance page")
    private void smUserShouldReturnToProgramMainteancePage(){
        Assert.assertTrue("sm user should return to program maintenance page",
                this.programMaintenanceComponent.isLoaded());
    }
}
