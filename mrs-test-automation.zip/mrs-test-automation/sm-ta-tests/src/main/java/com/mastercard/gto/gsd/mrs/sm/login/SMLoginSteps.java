package com.mastercard.gto.gsd.mrs.sm.login;

import com.mastercard.gto.gsd.mrs.sm.domain.Properties;
import com.mastercard.gto.gsd.mrs.sm.page.LoginPage;
import com.mastercard.gto.gsd.mrs.sm.page.MCCWorkspacePage;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 3/7/2017.
 */
@Component
public class SMLoginSteps {

    @Autowired
    private LoginPage loginPage;
    @Autowired
    private MCCWorkspacePage mccWorkspacePage;
    @Autowired
    private Environment environment;

    @Given("I am at the login page")
    public void iAmAtTheLoginPage(){
        this.loginPage.navigateToLoginPage();
    }

    @When("I input the username and password")
    public void iInputTheUsernameAndPassword(){
        this.loginPage.inputUserID(environment.getProperty(Properties.USERNAME));
        this.loginPage.inputPassword(environment.getProperty(Properties.PASSWORD));

        this.loginPage.clickOnSignIn();
    }

    @Then("I will see the MCC workspace page")
    public void iWillSeeTheMCCWorkspacePage(){
        Assert.assertTrue("I will see the MCC workspace page", this.mccWorkspacePage.isLoaded());
    }
}
