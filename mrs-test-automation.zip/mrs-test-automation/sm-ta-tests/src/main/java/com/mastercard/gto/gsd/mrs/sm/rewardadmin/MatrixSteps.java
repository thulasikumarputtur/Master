package com.mastercard.gto.gsd.mrs.sm.rewardadmin;

import com.mastercard.gto.gsd.mrs.sm.components.TabsComponents;
import com.mastercard.gto.gsd.mrs.sm.components.rewardadmin.MatrixComponent;
import com.mastercard.gto.gsd.mrs.sm.components.rewardadmin.RedemptionCenterComponent;
import com.mastercard.gto.gsd.mrs.sm.components.rewardadmin.RewardMatrixItemComponent;
import com.mastercard.gto.gsd.mrs.sm.page.SystemMaintenancePage;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 3/27/2017.
 */
@Component
public class MatrixSteps {

    public static final String YES = "YES";
    public static final String NO = "NO";
    @Autowired
    private SystemMaintenancePage systemMaintenancePage;
    @Autowired
    private TabsComponents tabsComponents;
    @Autowired
    private MatrixComponent matrixComponent;
    @Autowired
    private RewardMatrixItemComponent rewardMatrixItemComponent;
    @Autowired
    private RedemptionCenterComponent redemptionCenterComponent;

    @When("sm user clicks on reward admin tab")
    public void smUserClicksOnRewardAdminTab(){
        systemMaintenancePage.clickOnRewardTab();
    }

    @When("sm user clicks on Matrix tab")
    public void smUserClickONMatrixTab(){
        this.tabsComponents.clickOnMatrixTab();
    }

    @When("sm user selects the matrix $matrixName")
    public void smUserSelectsTheMatrix(@Named("matrixName") String matrixName){
        this.matrixComponent.selectMatrix(matrixName);
    }

    @When("sm user clicks on item tab item tab")
    public void smUserClicksOnItemTab(){
        this.matrixComponent.clickOnItemTab();
    }

    @When("sm user selects the item $item")
    public void smUserSelectsTheItem(@Named("item")String item){
        this.rewardMatrixItemComponent.selectItem(item);
    }

    @When("sm user sets the point value $pointValue")
    public void smUserSetsThePointValue(@Named("pointValue")String pointValue){
        this.rewardMatrixItemComponent.typePointValue(pointValue);
    }

    @When("sm user sets the recurring option to $recurringOption")
    public void smUserSetsTheRecurringOption(@Named("recurringOption")String recurringOption){
        switch (recurringOption.toUpperCase()){
            case YES:
                this.rewardMatrixItemComponent.clickOnRecurringRedemptionYesRadioButton();
                break;
            case NO:
                this.rewardMatrixItemComponent.clickOnRecurringRedemptionNoRadioButton();
                break;
            default:
                break;
        }
    }

    @When("sm user clicks on update selected redemption centers button")
    public void smUserClickOnUpdateSelectedRedemeptionCenters(){
        this.redemptionCenterComponent.clickOnUpdateButton();
    }

    @When("sm user sets the redeemable option is to $redeemableOption")
    public void smUserSetsRedeemableOption(@Named("redeemableOption")String redeemableOption){
        this.matrixComponent.clickOnRedemptionCenterTab();

        switch (redeemableOption.toUpperCase()){
            case YES:
                this.redemptionCenterComponent.clickOnRedeemableYesRadioButton();
                break;
            case NO:
                this.redemptionCenterComponent.clickOnRedeemableNoRadioButton();
                break;
            default:
                break;
        }
    }

    @When("sm user click on update reward item button")
    public void smUserClickOnUpdateRewardItem(){
        this.rewardMatrixItemComponent.clickOnUpdateButton();
    }

    @Then("sm user will see the values persisted $pointValue, $recurringOption")
    public void smUserWillSeeTheValuePersisted(@Named("pointValue")String pointValue, @Named("recurringOption")String recurringOption){
        this.matrixComponent.clickOnRedemptionCenterTab();
        this.matrixComponent.clickOnItemTab();

        Assert.assertTrue(this.rewardMatrixItemComponent.getPointValueInput().getAttribute("value").equals(pointValue));
        switch(recurringOption.toUpperCase()){
            case YES:
                Assert.assertTrue(this.rewardMatrixItemComponent.getRecurringRedemptionRadioYes().isSelected());
                Assert.assertFalse(this.rewardMatrixItemComponent.getRecurringRedemptionRadioNo().isSelected());
                break;
            case NO:
                Assert.assertFalse(this.rewardMatrixItemComponent.getRecurringRedemptionRadioYes().isSelected());
                Assert.assertTrue(this.rewardMatrixItemComponent.getRecurringRedemptionRadioNo().isSelected());
                break;
            default:
                break;
        }
    }

}
