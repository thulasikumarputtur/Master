package com.mastercard.gto.gsd.mrs.sm.configuration;

import com.mastercard.testing.bdd.rest.configuration.BDDRestToolsConfig;
import com.mastercard.testing.mtaf.ui.configuration.MTAFWebToolsConfiguration;
import org.springframework.context.annotation.*;

/**
 * Created by e054649 on 3/7/2017.
 */

@Configuration
@ComponentScan(basePackages = {"com.mastercard.gto.gsd.mrs.sm"})
@PropertySources({@PropertySource("${sm.params}")})
@Import({MTAFWebToolsConfiguration.class,  BDDRestToolsConfig.class})
public class AppConfig {
}
