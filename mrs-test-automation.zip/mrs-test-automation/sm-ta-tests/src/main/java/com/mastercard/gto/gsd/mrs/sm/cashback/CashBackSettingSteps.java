package com.mastercard.gto.gsd.mrs.sm.cashback;

import com.mastercard.gto.gsd.mrs.sm.components.programparameters.CashbackRedemptionComponent;
import com.mastercard.gto.gsd.mrs.sm.components.programparameters.ProgramSelectionComponent;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 4/11/2017.
 */
@Component
public class CashBackSettingSteps {

    public static final String CHECKED = "checked";
    public static final String DISCONTINUED = "discontinued";
    @Autowired
    private CashbackRedemptionComponent cashbackRedemptionComponent;

    @Autowired
    private ProgramSelectionComponent programSelectionComponent;

    public static final String NONE = "None";

    @When("sm user clicks on cashback redemption settings")
    public void smUserClickOnCashbackRedemptionSettings() {
        this.programSelectionComponent.clickOnCashBackLink();
    }

    @When("sm user clicks on prgram maintenance")
    public void smUserClickOnProgramMaintenance() {
        this.programSelectionComponent.clickOnProgramMaintenaceLink();
    }

    @When("sm user updates the Pay with Rewards Lite option to $option")
    public void smUserUpdatePayWithRewardsLite(@Named("option") String option) {
        if (option.equalsIgnoreCase(CHECKED)) {
            this.cashbackRedemptionComponent.selectPayWithRewardsLiteCheckbox();
        } else {
            this.cashbackRedemptionComponent.unselectPayWithRewardsLiteCheckbox();
        }
    }

    @When("sm user updates the Pay with Rewards RTR option to $option")
    public void smUserUpdateThePayWithRewardRTR(@Named("option") String option) {
        if (option.equalsIgnoreCase(CHECKED)) {
            this.cashbackRedemptionComponent.selectPayWithRewardsRTRCheckbox();
        } else {
            this.cashbackRedemptionComponent.unselectPayWithRewardsRTRCheckbox();
        }
    }

    @When("sm user updates the Cash/Points Pursing to $option")
    public void smUserUpdateTheCashPointPursuing(@Named("option") String option) {
        if (option.equalsIgnoreCase(CHECKED)) {
            this.cashbackRedemptionComponent.selectCashPointsPursuing();
        } else {
            this.cashbackRedemptionComponent.unselectCashPointsPursuing();
        }
    }

    @When("sm user selects the cashback redemption model $redemptionModel")
    public void smUserSelectsCashbackRedemptionModel(@Named("redemptionModel") String redemptionModel) {
        this.cashbackRedemptionComponent.selectRedemptionModel(redemptionModel);

        try {
            this.cashbackRedemptionComponent.clickOnAlertAcceptButton();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @When("sm user clicks on update cashback redemption settings button")
    public void smClickOnUpdateCashbackRedemptionSetting() {
        this.cashbackRedemptionComponent.clickOnUpdateButton();
    }

    @When("sm user inputs the values for $rebateCredit, $mccNumber and $merchantID")
    public void smUserInputValueRebateCreditMccNumberMerchantID(@Named("rebateCredit") String rebateCredit,
                                                                @Named("mccNumber") String mccNumber,
                                                                @Named("merchantID") String merchantID) {

        this.cashbackRedemptionComponent.typeRebateCredit(rebateCredit);
        this.cashbackRedemptionComponent.typeMCCNumber(mccNumber);
        this.cashbackRedemptionComponent.typeMerchantID(merchantID);
    }

    @Then("sm user should see the cashback settings successful message $message")
    public void smUserShouldSeeCashbackSettingsSuccessfulMessage(@Named("message") String message) {
        if (this.cashbackRedemptionComponent.getAlertText().contains(DISCONTINUED))
            this.cashbackRedemptionComponent.clickOnAlertAcceptButton();

        Assert.assertTrue(this.cashbackRedemptionComponent.getAlertText().contains(message));
        this.cashbackRedemptionComponent.clickOnAlertAcceptButton();
    }
}
