package com.mastercard.gto.gsd.mrs.sm.sm;

import com.mastercard.gto.gsd.mrs.sm.components.programparameters.ProgramSelectionComponent;
import com.mastercard.gto.gsd.mrs.sm.page.SystemMaintenancePage;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 4/11/2017.
 */
@Component
public class ProgramParametersSteps {

    @Autowired
    private ProgramSelectionComponent programSelectionComponent;

    @Autowired
    private SystemMaintenancePage systemMaintenancePage;

    @When("sm user selects the program member $programMember")
    public void smUserSelectsProgramMember(@Named("programMember")String programMember){
        this.programSelectionComponent.selectProgramMember(programMember);
    }

    @When("sm user selects the programID $programID")
    public void smUserSelectsTheProgram(@Named("programID")String programID){

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.programSelectionComponent.selectProgram(programID);
    }

    @Given("sm user is on program parameters tab")
    public void smUserIsOnProgramParametersTab(){
        this.systemMaintenancePage.clickOnProgramParametersTab();
    }
}
