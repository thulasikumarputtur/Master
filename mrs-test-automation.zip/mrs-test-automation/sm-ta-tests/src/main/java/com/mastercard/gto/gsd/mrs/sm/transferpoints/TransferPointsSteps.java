package com.mastercard.gto.gsd.mrs.sm.transferpoints;

import com.mastercard.gto.gsd.mrs.sm.components.SystemSettingsComponent;
import com.mastercard.gto.gsd.mrs.sm.components.TabsComponents;
import com.mastercard.gto.gsd.mrs.sm.components.programparameters.ProgramSelectionComponent;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static junit.framework.Assert.assertTrue;

/**
 * Created by e054649 on 6/8/2017.
 */
@Component
public class TransferPointsSteps {

    @Autowired
    private ProgramSelectionComponent programSelectionComponent;

    @Autowired
    private SystemSettingsComponent systemSettingsComponent;

    @Autowired
    private TabsComponents tabsComponents;

    @When("sm user clicks on system settings")
    public void smUserClickOnSystemSettings(){
        this.programSelectionComponent.clickOnSystemSettingsLink();
    }

    @When("sm user selects manual point transfer method as $method")
    public void smUserSelectManulPointTransfer(@Named("method") String method){
        this.systemSettingsComponent.selectItemDropdown(method);
    }

    @When("sm user clicks on save system settings")
    public void smUserclickOnSaveSystemSettings(){
        this.systemSettingsComponent.clickOnUpdateButton();
    }

    @Then("sm user will see manual point transfer method as $method is persisted")
    public void smUserWillSeeManulPointTransferMethodPersisted(@Named("method")String method){
        assertTrue(String.format("sm user will see manual point transfer method as %s is persisted",method),
                method.equalsIgnoreCase(this.systemSettingsComponent
                        .getPointsMethodDropdown()
                        .getSelect()
                        .getFirstSelectedOption()
                        .getText()));
    }
}
