package com.mastercard.gto.gsd.mrs.sm;

import com.mastercard.gto.gsd.mrs.sm.configuration.AppConfig;
import com.mastercard.testing.mtaf.ui.MastercardUIStories;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public abstract class InternetRedemptionsStories extends MastercardUIStories {
	@Override
	public ApplicationContext getAnnotatedApplicationContext() {
		return new AnnotationConfigApplicationContext(AppConfig.class);
	}
}
