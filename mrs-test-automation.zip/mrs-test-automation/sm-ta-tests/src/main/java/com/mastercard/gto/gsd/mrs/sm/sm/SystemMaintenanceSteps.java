package com.mastercard.gto.gsd.mrs.sm.sm;

import com.mastercard.gto.gsd.mrs.sm.components.ApplicationsComponent;
import com.mastercard.gto.gsd.mrs.sm.domain.Properties;
import com.mastercard.gto.gsd.mrs.sm.page.MCCWorkspacePage;
import com.mastercard.gto.gsd.mrs.sm.page.SystemMaintenancePage;
import com.mastercard.testing.mtaf.ui.util.BrowserUtils;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 3/9/2017.
 */

@Component
public class SystemMaintenanceSteps {

    @Autowired
    private MCCWorkspacePage mccWorkspacePage;

    @Autowired
    private BrowserUtils browserUtils;

    @Autowired
    private SystemMaintenancePage systemMaintenancePage;

    @Autowired
    private ApplicationsComponent applicationsComponent;

    @Autowired
    private Environment environment;


    @When("I click on the application link")
    public void iClickOnTheApplicationLink() {
        this.mccWorkspacePage.getMccHeaderComponent().clickOnApplicationsButton();
    }

    @When("I click on the system maintenance link")
    public void iClickOnTheSystemMaintenanceLink() {
        this.applicationsComponent.clickOnSystemMaintenanceButton();
    }

    @When("Dummy <dummy>")
    public void dummy(@Named("dummy") String dummy){
        System.out.println(dummy);
    }

    @Then("I will see the system maintenance page")
    public void iWillSeeTheSystemMaintenancePage() {

        try{
            Thread.sleep(5000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Switch to new window opened
        this.systemMaintenancePage.switchToLastOpenWindow();
        systemMaintenancePage.waitUntilIsLoaded();

        Assert.assertTrue("I will see the system maintenance page", systemMaintenancePage.getTitle().equalsIgnoreCase(environment.getProperty(Properties.WEB_MAINTENANCE_APPLICATION_TEST)));
    }
}
