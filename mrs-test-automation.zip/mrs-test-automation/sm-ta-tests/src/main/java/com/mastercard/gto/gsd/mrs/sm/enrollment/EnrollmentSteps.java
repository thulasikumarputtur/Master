package com.mastercard.gto.gsd.mrs.sm.enrollment;

import com.mastercard.gto.gsd.mrs.sm.components.programparameters.ProgramSelectionComponent;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 6/30/2017.
 */

@Component
public class EnrollmentSteps {
    @Autowired
    private ProgramSelectionComponent programSelectionComponent;

    @When("sm user clicks on enrollment")
    public void smUserClicksOnEnrollment(){

    }

    @When("sm user selects program classification as $programClassification")
    public void smUserSelectsProgramClassification(@Named("programClassification") String programClassification){

    }

    @When("sm user clicks on update enrollment button")
    public void smUserClicksOnUpdateEnrollmentButton(){

    }

}
