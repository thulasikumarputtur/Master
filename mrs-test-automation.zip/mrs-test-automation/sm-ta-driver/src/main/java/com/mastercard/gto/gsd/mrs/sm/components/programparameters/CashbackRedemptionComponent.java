package com.mastercard.gto.gsd.mrs.sm.components.programparameters;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 4/11/2017.
 */
@Component
public class CashbackRedemptionComponent extends AbstractComponent {

    /**
     * The constant UPDATE_BUTTON_LOCATOR.
     */
    public static final String UPDATE_BUTTON_LOCATOR = "updateCashbackRedemptionSettings";
    /**
     * The constant METHOD_LITE_CHECKBOX_LOCATOR.
     */
    public static final String METHOD_LITE_CHECKBOX_LOCATOR = "cashback_redemption_method_lite_sw";
    /**
     * The constant METHOD_RTR_CHECKBOX_LOCATOR.
     */
    public static final String METHOD_RTR_CHECKBOX_LOCATOR = "cashback_redemption_method_rtr_sw";
    /**
     * The constant METHOD_PURSING_CHECKBOX_LOCATOR.
     */
    public static final String METHOD_PURSING_CHECKBOX_LOCATOR = "cashback_redemption_method_pursing_sw";

    /**
     * The constant REDEMPTION_MODEL_DROPDOWN_LOCATOR.
     */
    public static final String REDEMPTION_MODEL_DROPDOWN_LOCATOR = "cashback_redemption_cd";
    /**
     * The constant REBATE_CREDIT_INPUT_LOCATOR.
     */
    public static final String REBATE_CREDIT_INPUT_LOCATOR = "auto_cashback_rebate_credit";
    /**
     * The constant MCC_INPUT_LOCATOR.
     */
    public static final String MCC_INPUT_LOCATOR = "auto_cashback_mcc_txt";
    /**
     * The constant MERCHANT_ID_LOCATOR.
     */
    public static final String MERCHANT_ID_LOCATOR = "auto_cashback_merch_txt";


    @PageElement(findBy = ElementsBase.FindBy.NAME, valueToFind = UPDATE_BUTTON_LOCATOR)
    private MCWebElement updateButton;


    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = METHOD_LITE_CHECKBOX_LOCATOR)
    private MCWebElement methodLiteCheckbox;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = METHOD_RTR_CHECKBOX_LOCATOR)
    private MCWebElement methodRTRCheckbox;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = METHOD_PURSING_CHECKBOX_LOCATOR)
    private MCWebElement methodCashPointsCheckbox;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = REDEMPTION_MODEL_DROPDOWN_LOCATOR)
    private MCWebElement redemptionModelDropdown;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = REBATE_CREDIT_INPUT_LOCATOR)
    private MCWebElement rebateCreditInput;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = MCC_INPUT_LOCATOR)
    private MCWebElement mccNumberInput;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = MERCHANT_ID_LOCATOR)
    private MCWebElement merchantIDInput;


    /**
     * Click on update button.
     */
    public void clickOnUpdateButton() {
        this.updateButton.click();
    }


    /**
     * Select pay with rewards lite checkbox.
     */
    public void selectPayWithRewardsLiteCheckbox() {
        if (!this.methodLiteCheckbox.isSelected())
            this.methodLiteCheckbox.click();
    }

    /**
     * Unselect pay with rewards lite checkbox.
     */
    public void unselectPayWithRewardsLiteCheckbox() {
        if (this.methodLiteCheckbox.isSelected())
            this.methodLiteCheckbox.click();
    }

    /**
     * Select pay with rewards rtr checkbox.
     */
    public void selectPayWithRewardsRTRCheckbox() {
        if (!this.methodRTRCheckbox.isSelected())
            this.methodRTRCheckbox.click();
    }

    /**
     * Unselect pay with rewards rtr checkbox.
     */
    public void unselectPayWithRewardsRTRCheckbox() {
        if (this.methodRTRCheckbox.isSelected())
            this.methodRTRCheckbox.click();
    }

    /**
     * Select cash points pursuing.
     */
    public void selectCashPointsPursuing() {
        if (!this.methodCashPointsCheckbox.isSelected())
            this.methodCashPointsCheckbox.click();
    }

    /**
     * Unselect cash points pursuing.
     */
    public void unselectCashPointsPursuing() {
        if (this.methodCashPointsCheckbox.isSelected())
            this.methodCashPointsCheckbox.click();
    }

    /**
     * Get alert text string.
     *
     * @return the string
     */
    public String getAlertText(){
        return this.getFinder().getWebDriver().switchTo().alert().getText();
    }

    /**
     * Click on alert's accept button.
     */
    public void clickOnAlertAcceptButton(){
        this.getFinder().getWebDriver().switchTo().alert().accept();
    }

    /**
     * Select redemption model.
     *
     * @param redemptionModel the redemption model
     */
    public void selectRedemptionModel(String redemptionModel){
        this.redemptionModelDropdown.getSelect().selectByVisibleText(redemptionModel);
    }

    /**
     * Get current redemption model string.
     *
     * @return the string
     */
    public String getCurrentRedemptionModel(){
        return this.redemptionModelDropdown.getSelect().getFirstSelectedOption().getText();
    }

    /**
     * Type rebate credit.
     *
     * @param reabateCredit the reabate credit
     */
    public void typeRebateCredit(String reabateCredit){
        this.rebateCreditInput.sendKeys(reabateCredit);
    }

    /**
     * Type mcc number.
     *
     * @param mccNumber the mcc number
     */
    public void typeMCCNumber(String mccNumber){
        this.mccNumberInput.sendKeys(mccNumber);
    }

    /**
     * Type merchant id.
     *
     * @param merchantID the merchant id
     */
    public void typeMerchantID(String merchantID){
        this.merchantIDInput.sendKeys(merchantID);
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.name(UPDATE_BUTTON_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(METHOD_LITE_CHECKBOX_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(METHOD_RTR_CHECKBOX_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(METHOD_PURSING_CHECKBOX_LOCATOR)));

        return conditions;
    }

}
