package com.mastercard.gto.gsd.mrs.sm.components.rewardadmin;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.element.MCWebElements;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * Created by e054649 on 3/28/2017.
 */
@Component
public class RedemptionCenterComponent extends AbstractComponent {

    public static final String MATRIX_ITEMS_REDEMPTION_CENTERS_TABLE = "//*[@id=\"matrixItemsRedemptionCenters\"]/tbody/tr";
    public static final String UPDATE_BUTTON = "updatercssub";
    public static final int CHECK_BUTTON_INDEX = 0;
    public static final int ID_INDEX = 1;
    public static final int DESCRIPTION_INDEX = 2;
    public static final int RADIO_BUTTON_INDEX = 3;


    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = MATRIX_ITEMS_REDEMPTION_CENTERS_TABLE)
    private MCWebElements table;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = UPDATE_BUTTON)
    private MCWebElement updateButton;

    /**
     * Gets table.
     *
     * @return the table
     */
    public MCWebElements getTable() {
        return table;
    }

    private void findIRItem(String inputID){
        for(MCWebElement mcWebElement : table.getElements()){
            if(mcWebElement.tds().getElements().get(DESCRIPTION_INDEX).getText().equalsIgnoreCase("Internet Redemptions Center")){
                if(!mcWebElement.tds().getElements().get(CHECK_BUTTON_INDEX).input().isSelected())
                    mcWebElement.tds().getElements().get(CHECK_BUTTON_INDEX).input().click();
                mcWebElement.tds().getElements().get(RADIO_BUTTON_INDEX).inputs(By.id(inputID)).getElements().get(0).click();
                break;
            }
            log.info(mcWebElement.getTagName());
        }
    }

    public void clickOnRedeemableYesRadioButton(){
        findIRItem("redeemable_sw_yes");
    }

    public void clickOnRedeemableNoRadioButton(){
        findIRItem("redeemable_sw_no");
    }

    /**
     * Click on update button.
     */
    public void clickOnUpdateButton(){
        this.updateButton.click();
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        return null;
    }
}
