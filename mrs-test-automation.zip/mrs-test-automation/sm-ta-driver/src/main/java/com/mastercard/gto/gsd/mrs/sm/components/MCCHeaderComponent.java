package com.mastercard.gto.gsd.mrs.sm.components;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.element.MCWebElements;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import com.mastercard.testing.mtaf.ui.util.BrowserUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 3/7/2017.
 */
@Component
public class MCCHeaderComponent extends AbstractComponent {

    /**
     * The constant HEADER_NAVIGATION_MENU_LOCATOR.
     */
    public static final String HEADER_NAVIGATION_MENU_LOCATOR = "//*[@id=\"navigation-controls\"]/li/a";


    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = HEADER_NAVIGATION_MENU_LOCATOR)
    private MCWebElements header_menu;

    @Autowired
    private BrowserUtils browserUtils;

    /**
     * Click on menu item.
     *
     * @param menuItem the menu item
     */
    public void clickOnMenuItem(String menuItem) {
        for (MCWebElement element : this.header_menu.getElements()) {
            if (element.getText().equalsIgnoreCase(menuItem)) {
                element.click();
                return;
            }
        }
    }

    /**
     * Click on applications button.
     */
    public void clickOnApplicationsButton() {
        this.clickOnMenuItem("My Apps");
    }

    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath(HEADER_NAVIGATION_MENU_LOCATOR)));

        return conditions;
    }
}
