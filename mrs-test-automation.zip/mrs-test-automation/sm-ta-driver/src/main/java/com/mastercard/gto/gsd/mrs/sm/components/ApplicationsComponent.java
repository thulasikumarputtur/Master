package com.mastercard.gto.gsd.mrs.sm.components;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 6/8/2017.
 */

@Component
public class ApplicationsComponent extends AbstractComponent {
    /**
     * The constant MRS_APP_LOCATOR.
     */
    public static final String MRS_APP_LOCATOR = "//*[@id=\"myapps_results\"]/div[2]/div[3]/app-card/div[9]/div[3]/span[1]/app-handler/span/a";


    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = MRS_APP_LOCATOR)
    private MCWebElement mrsApp;

    /**
     * Click on system maintenance button.
     */
    public void clickOnSystemMaintenanceButton() {
        this.mrsApp.click();
        log.info("Clicked on MRS app");
    }

    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath(MRS_APP_LOCATOR)));

        return conditions;
    }
}
