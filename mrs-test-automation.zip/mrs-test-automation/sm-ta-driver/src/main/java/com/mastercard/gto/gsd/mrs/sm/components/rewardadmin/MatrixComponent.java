package com.mastercard.gto.gsd.mrs.sm.components.rewardadmin;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 3/20/2017.
 */
@Component
public class MatrixComponent extends AbstractComponent {

    public static final String ITEM_TAB_LOCATOR = "//*[@id=\"tabPaneMatrixRewardItemsMaint\"]/div[1]/h2[2]/a";
    public static final String MATRIX_DROPDOWN_LOCATOR = "matrixid";
    public static final String REDEMPTION_CENTER_TAB_LOCATOR = "//*[@id=\"tabPaneMatrixRewardItemsMaint\"]/div[1]/h2[4]/a";

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = MatrixComponent.ITEM_TAB_LOCATOR)
    private MCWebElement itemTab;

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = REDEMPTION_CENTER_TAB_LOCATOR)
    private MCWebElement redemptionCenterTab;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = MATRIX_DROPDOWN_LOCATOR)
    private MCWebElement matrixDropDown;




    /**
     * Select matrix.
     *
     * @param matrixName the matrix name
     */
    public void selectMatrix(String matrixName){
        this.matrixDropDown.getSelect().selectByVisibleText(matrixName);
    }

    /**
     * Click on Item tab.
     */
    public void clickOnItemTab(){
        itemTab.click();
        log.info("Clicked on the Matrix tab");
    }

    /**
     * Click on redemption center tab.
     */
    public void clickOnRedemptionCenterTab(){
        this.redemptionCenterTab.click();
        log.info("Clicked on redemption center tab");
    }


    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(MatrixComponent.ITEM_TAB_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath(MatrixComponent.REDEMPTION_CENTER_TAB_LOCATOR)));

        return conditions;
    }
}
