package com.mastercard.gto.gsd.mrs.sm.page;

import com.mastercard.gto.gsd.mrs.sm.components.MCCHeaderComponent;
import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * Created by e054649 on 3/7/2017.
 */

@Component
public class MCCWorkspacePage extends AbstractPage {

    @Autowired
    private MCCHeaderComponent mccHeaderComponent;

    public MCCHeaderComponent getMccHeaderComponent() {
        return mccHeaderComponent;
    }

    @Override
    protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        return mccHeaderComponent.isLoadedConditions();
    }
}
