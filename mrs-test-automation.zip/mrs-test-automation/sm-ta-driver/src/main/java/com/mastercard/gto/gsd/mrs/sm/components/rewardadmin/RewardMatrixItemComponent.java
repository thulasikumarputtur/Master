package com.mastercard.gto.gsd.mrs.sm.components.rewardadmin;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 3/20/2017.
 */
@Component
public class RewardMatrixItemComponent extends AbstractComponent {

    public static final String REC_REDEMP_YES_ID = "rec_redemp_yes";
    public static final String REC_REDEMP_NO_ID = "rec_redemp_no";
    public static final String POINT_VALUE_ID = "rmiPointValue";
    public static final String UPDATE_BUTTON_ID = "updatesub";
    public static final String ITEM_DESCRIPTION_DROPDOWN = "glbl_item_desc";


    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = REC_REDEMP_YES_ID)
    private MCWebElement recurringRedemptionRadioYes;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = "rec_redemp_no")
    private MCWebElement recurringRedemptionRadioNo;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = POINT_VALUE_ID)
    private MCWebElement pointValueInput;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = UPDATE_BUTTON_ID)
    private MCWebElement updateButton;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = ITEM_DESCRIPTION_DROPDOWN)
    private MCWebElement dropDownItems;

    /**
     * Gets point value input.
     *
     * @return the point value input
     */
    public MCWebElement getPointValueInput() {
        return pointValueInput;
    }

    /**
     * Gets recurring redemption radio no.
     *
     * @return the recurring redemption radio no
     */
    public MCWebElement getRecurringRedemptionRadioNo() {
        return recurringRedemptionRadioNo;
    }

    /**
     * Gets recurring redemption radio yes.
     *
     * @return the recurring redemption radio yes
     */
    public MCWebElement getRecurringRedemptionRadioYes() {
        return recurringRedemptionRadioYes;
    }

    /**
     * Click on recurring redemption yes radio button.
     */
    public void clickOnRecurringRedemptionYesRadioButton(){
        this.recurringRedemptionRadioYes.click();
        log.info("Clicked on recurring redemption yes radio button.");
    }

    /**
     * Click on recurring redemption no radio button.
     */
    public void clickOnRecurringRedemptionNoRadioButton(){
        this.recurringRedemptionRadioNo.click();
        log.info("Clicked on recurring redemption No radio button.");
    }

    public void typePointValue(String pointValue){
        this.pointValueInput.sendKeys(pointValue);
        log.info("Typed " + pointValue + " into point value input");
    }

    /**
     * Click on update button.
     */
    public void clickOnUpdateButton(){
        this.updateButton.click();
        log.info("Clicked on update button");
    }

    /**
     * Select an item.
     *
     * @param itemDescription the item description
     */
    public void selectItem(String itemDescription){
        this.dropDownItems.getSelect().selectByVisibleText(itemDescription);
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(POINT_VALUE_ID)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(REC_REDEMP_NO_ID)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(REC_REDEMP_YES_ID)));

        return conditions;
    }
}
