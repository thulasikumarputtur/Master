package com.mastercard.gto.gsd.mrs.sm.components.programparameters;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 4/11/2017.
 */
@Component
public class ProgramSelectionComponent extends AbstractComponent {

    public static final String MEMBER_LOCATOR = "parentaccess";
    public static final String PROGRAM_ID_LOCATOR = "program_id";
    public static final String CASHBACK_LINK_LOCATOR = "Cashback Redemption Settings";
    public static final String SYSTEM_SETTING_LINK_LOCATOR = "System Settings";
    public static final String ENROLLMENT_LINK_LOCATOR = "webfx-tree-object-5-anchor";
    public static final String INTERNET_CUSTOMER_SVC_LOCATOR = "Internet / Customer Svc";

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = MEMBER_LOCATOR)
    private MCWebElement memberDropDown;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = PROGRAM_ID_LOCATOR)
    private MCWebElement programDropDown;

    @PageElement(findBy = ElementsBase.FindBy.LINK, valueToFind = CASHBACK_LINK_LOCATOR)
    private MCWebElement cashBackLink;

    @PageElement(findBy = ElementsBase.FindBy.LINK, valueToFind = INTERNET_CUSTOMER_SVC_LOCATOR)
    private MCWebElement programMaintenanceLink;

    @PageElement(findBy = ElementsBase.FindBy.LINK, valueToFind = SYSTEM_SETTING_LINK_LOCATOR)
    private MCWebElement systemSettings;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = ENROLLMENT_LINK_LOCATOR)
    private MCWebElement enrollment;

    /**
     * Select program.
     *
     * @param program the program
     */
    public void selectProgram(String program){
        this.programDropDown.getSelect().selectByValue(program);
    }

    /**
     * Select program member.
     *
     * @param programMember the program member
     */
    public void selectProgramMember(String programMember){
        this.memberDropDown.getSelect().selectByValue(programMember);
    }

    /**
     * Click on cash back link.
     */
    public void clickOnCashBackLink() {
        this.cashBackLink.click();
    }

    /**
     * Click on program maintenance (Internet/Customer SVC) link.
     */
    public void clickOnProgramMaintenaceLink() {
        this.programMaintenanceLink.click();
    }

    /**
     * Click on transfer points link.
     */
    public void clickOnSystemSettingsLink(){
        this.systemSettings.click();
        log.info("Clicked on system settings link");
    }

    public void clickOnEnrollmentLink(){
        this.enrollment.click();
        log.info("Clicked on enrollment link.");
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(MEMBER_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(CASHBACK_LINK_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(PROGRAM_ID_LOCATOR)));

        return conditions;
    }
}
