package com.mastercard.gto.gsd.mrs.sm.domain;

/**
 * Created by e054649 on 3/7/2017.
 */
public final class Properties {

    public static final String SM_LANDING_PAGE_URLTEST_AUTOMATION = "sm_landingPageURLTestAutomation";
    public static final String USERNAME = "mcc_username";
    public static final String PASSWORD = "mcc_password";
    public static final String WEB_MAINTENANCE_APPLICATION_TEST = "systemMaintenanceTitle";

}
