package com.mastercard.gto.gsd.mrs.sm.page;

import com.mastercard.gto.gsd.mrs.sm.domain.Properties;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 3/2/2017.
 */
@Component
public class LoginPage extends AbstractPage {

    public static final String PASSWORD_INPUT_ID = "password";
    public static final String FAKE_PASSWORD_INPUT_ID = "ext-comp-1010";
    public static final String SIGN_IN_BUTTON_ID = "btnSubmit";
    public static final String USER_INPUT_ID = "userid";


    @PageElement(findBy = ElementsBase.FindBy.NAME, valueToFind = PASSWORD_INPUT_ID)
    private MCWebElement passwordInput;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = USER_INPUT_ID)
    private MCWebElement userIDInpunt;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = FAKE_PASSWORD_INPUT_ID)
    private MCWebElement fakePasswordInpunt;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = SIGN_IN_BUTTON_ID)
    private MCWebElement signInButton;

    @Autowired
    private Environment environment;


    /**
     * Click on sign in button.
     */
    public void clickOnSignIn(){
        this.signInButton.click();
    }

    /**
     * Input user id.
     *
     * @param userID the user id
     */
    public void inputUserID(String userID){
        this.userIDInpunt.sendKeys(userID);
    }

    /**
     * Input password.
     *
     * @param password the password
     */
    public void inputPassword(String password){
        /*this.fakePasswordInpunt.click();
        this.passwordInput = this.getFinder().findOne(ElementsBase.FindBy.ID, "ext-comp-1011");

        log.info("Is visible? " + this.passwordInput.isVisible());
        log.info("Is enabled? " + this.passwordInput.isEnabled());*/

        this.passwordInput.click();

        this.passwordInput.sendKeys(password);
    }

    /**
     * Navigate to login page.
     */
    public void navigateToLoginPage(){
        String url = environment.getProperty(Properties.SM_LANDING_PAGE_URLTEST_AUTOMATION);
        log.info("Navigating to URL: " + url);
        getFinder().getWebDriver().get(url);

    }

    @Override
    protected Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(USER_INPUT_ID)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(PASSWORD_INPUT_ID)));

        return conditions;
    }
}
