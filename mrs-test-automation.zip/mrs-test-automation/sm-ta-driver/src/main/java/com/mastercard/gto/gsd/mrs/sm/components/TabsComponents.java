package com.mastercard.gto.gsd.mrs.sm.components;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 3/20/2017.
 */
@Component
public class TabsComponents extends AbstractComponent {

    public static final String MATRIX_TAB_LOCATOR = "//*[@id=\"tabPaneMatrixConfig\"]/div[1]/h2[2]/a";

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = MATRIX_TAB_LOCATOR)
    private MCWebElement matrixTab;

    public static final String PROGRAM_PARAMETERS_TAB_LOCATOR = "//*[@id=\"tabPane0\"]/div[1]/h2[1]/a";

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = PROGRAM_PARAMETERS_TAB_LOCATOR)
    private MCWebElement programParametersTab;

    /**
     * Click on matrix tab.
     */
    public void clickOnMatrixTab(){
        matrixTab.click();
        log.info("Clicked on the Matrix tab.");
    }

    /**
     * Click on program parameters tab.
     */
    public void clickOnProgramParametersTab(){
        this.programParametersTab.click();
        log.info("Clicked on program parameters tab.");
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(MATRIX_TAB_LOCATOR)));

        return conditions;
    }
}
