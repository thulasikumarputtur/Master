package com.mastercard.gto.gsd.mrs.sm.page;

import com.mastercard.gto.gsd.mrs.sm.components.TabsComponents;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.AbstractPage;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 3/9/2017.
 */

@Component
public class SystemMaintenancePage extends AbstractPage {
    public static final String REWARD_TAB_LOCATOR = "//*[@id=\"tabPane0\"]/div[1]/h2[2]";
    public static final String PROGRAM_PARAMETERS_TAB_LOCATOR = "//*[@id=\"tabPane0\"]/div[1]/h2[1]";

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = REWARD_TAB_LOCATOR)
    private MCWebElement rewardTab;

    @PageElement(findBy = ElementsBase.FindBy.X_PATH, valueToFind = PROGRAM_PARAMETERS_TAB_LOCATOR)
    private MCWebElement programParametersTab;

    @Autowired
    private TabsComponents tabsComponents;

    /**
     * Click on Reward tab.
     */
    public void clickOnRewardTab() {
        rewardTab.click();
        log.info("Clicked on the Reward tab");
    }

    /**
     * Click on program parameters tab.
     */
    public void clickOnProgramParametersTab(){
        this.programParametersTab.click();
        log.info("Clicked on program parameters tab");
    }

    /**
     * Get title string.
     *
     * @return the string
     */
    public String getTitle() {
        return getFinder().getWebDriver().getTitle();
    }

    /**
     * Switch to last open window.
     */
    public void switchToLastOpenWindow() {

        this.getFinder().getWebDriver().close();
        for (String winHandle : getFinder().getWebDriver().getWindowHandles()) {
            getFinder().getWebDriver().switchTo().window(winHandle);
            System.out.println(winHandle);
        }
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath(REWARD_TAB_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.xpath(PROGRAM_PARAMETERS_TAB_LOCATOR)));

        return conditions;
    }
}
