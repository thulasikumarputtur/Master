package com.mastercard.gto.gsd.mrs.sm.components.programmaintenance;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 10/10/2017.
 */
@Component
public class ProgramMaintenanceComponent extends AbstractComponent {

    public static final String CUSTOMER_IDENTIFIER_DROPDOWN_LOCATOR = "parm_value_Internet_/_Customer_Svc_9";
    public static final String UPDATE_INTERNET_CUSTOMER_SVC_BUTTON_LOCATOR = "updateInternet_/_Customer_Svc";

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = CUSTOMER_IDENTIFIER_DROPDOWN_LOCATOR)
    private MCWebElement customerIdentifierDropdown;

    @PageElement(findBy = ElementsBase.FindBy.NAME, valueToFind = UPDATE_INTERNET_CUSTOMER_SVC_BUTTON_LOCATOR)
    private MCWebElement submitAllValues;


    /**
     * Select customer identifier.
     *
     * @param customerIdentifier the customer identifier
     */
    public void selectCustomerIdentifier(String customerIdentifier){
        this.customerIdentifierDropdown.getSelect().selectByValue(customerIdentifier);
        log.info("Selected the customer identifier: " + customerIdentifier);
    }

    /**
     * Click on submit all values.
     */
    public void clickOnSubmitAllValues(){
        this.submitAllValues.click();
        log.info("Clicked on submit all values button");
    }

    @Override
    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.name(UPDATE_INTERNET_CUSTOMER_SVC_BUTTON_LOCATOR)));

        return conditions;
    }
}
