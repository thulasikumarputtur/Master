package com.mastercard.gto.gsd.mrs.sm.components;

import com.mastercard.testing.mtaf.bindings.components.AbstractComponent;
import com.mastercard.testing.mtaf.bindings.element.ElementsBase;
import com.mastercard.testing.mtaf.bindings.element.MCWebElement;
import com.mastercard.testing.mtaf.bindings.page.PageElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by e054649 on 6/12/2017.
 */
@Component
public class SystemSettingsComponent extends AbstractComponent{

    /**
     * The constant BUTTON_UPDATE_LOCATOR.
     */
    public static final String BUTTON_UPDATE_LOCATOR = "updateSystemSettings";
    /**
     * The constant POINTS_METHOD_DROPDOWN_LOCATOR.
     */
    public static final String POINTS_METHOD_DROPDOWN_LOCATOR = "online_point_trans_method";

    @PageElement(findBy = ElementsBase.FindBy.NAME, valueToFind = BUTTON_UPDATE_LOCATOR)
    private MCWebElement buttonUpdate;

    @PageElement(findBy = ElementsBase.FindBy.ID, valueToFind = POINTS_METHOD_DROPDOWN_LOCATOR)
    private MCWebElement pointsMethodDropdown;

    /**
     * Select item dropdown.
     *
     * @param item the item
     */
    public void selectItemDropdown(String item){
        this.pointsMethodDropdown.getSelect().selectByVisibleText(item);
        log.info("Select on dropdown: " + item);
    }

    /**
     * Click on update button.
     */
    public void clickOnUpdateButton(){
        this.buttonUpdate.click();
        this.getFinder().getWebDriver().switchTo().alert().accept();
        log.info("Clicked on update button");
    }

    /**
     * Gets points method dropdown.
     *
     * @return the points method dropdown
     */
    public MCWebElement getPointsMethodDropdown() {
        return pointsMethodDropdown;
    }

    public Collection<ExpectedCondition<WebElement>> isLoadedConditions() {
        List<ExpectedCondition<WebElement>> conditions = new LinkedList<ExpectedCondition<WebElement>>();
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.id(POINTS_METHOD_DROPDOWN_LOCATOR)));
        conditions.add(ExpectedConditions.visibilityOfElementLocated(By.name(BUTTON_UPDATE_LOCATOR)));

        return conditions;
    }
}
