package com.mastercard.gto.gsd.mrs.ir.registration;

import com.mastercard.gto.gsd.mrs.ir.page.LandingPage;
import com.mastercard.gto.gsd.mrs.ir.page.RegistrationPage1;
import com.mastercard.gto.gsd.mrs.ir.page.RegistrationPage2;
import com.mastercard.gto.gsd.mrs.ir.page.RegistrationPage3;
import com.mastercard.gto.gsd.mrs.ir.util.ReadWriteAccountNumbers;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static org.junit.Assert.assertTrue;

@Component
public class RegistrationSteps {

	@Autowired
	LandingPage landingPage;

	@Autowired
	RegistrationPage1 registrationPage1;

	@Autowired
	RegistrationPage2 registrationPage2;

	@Autowired
	RegistrationPage3 registrationPage3;
	
	@Autowired
	ReadWriteAccountNumbers readWriteAccountNumbers;
		
	@When("I click on the top menu register $registerLinkName")
	public void performClickOnRegisterLink(@Named("registerLinkName") String registerLinkName){
		assertTrue("I click on the top menu register "+registerLinkName, 
				landingPage.clickOnTopRightLinkByName(registerLinkName));
	}
	
	@Then("I will see the Registration modal")
	public void iWillSeeRegistrationModal(){
		assertTrue("I see the Registration modal", landingPage.getregistrationModalComponent().isLoaded());
	}
	
	
	@Then("I will see the Registration title $registrationModalTitle")
	public void IWillSeeTitle(@Named("registrationModalTitle") String registrationModalTitle){
		assertTrue("I'll see the title : "+registrationModalTitle,
				landingPage.getregistrationModalComponent().getPageTitle().getText().equalsIgnoreCase(registrationModalTitle));
	}
	
	@Then("I will see the Account Type field label $accountTypeLabel")
	public void IWillSeeTheAccountTypeLabel(@Named("accountTypeLabel") String accountTypeLabel){
		assertTrue(accountTypeLabel,
				landingPage.getregistrationModalComponent().getAccountTypeLabel().getText().equalsIgnoreCase(accountTypeLabel));
	}
	
	@Then("I will see the Account Number field label $accountNumberLabel")
	public void IWillSeeTheAccountNumberLabel(@Named("accountNumberLabel") String accountNumberLabel){
		assertTrue(accountNumberLabel,
				landingPage.getregistrationModalComponent().getAccountNumberLabel().getText().equalsIgnoreCase(accountNumberLabel));
	}
	
	@Then("I will see the selection for Account Type the preselection label $accountTypePreSelection")
	public void IWillSeeTheAccountTypePreSelection(@Named("accountTypePreSelection") String accountTypePreSelection){
		assertTrue(accountTypePreSelection,
				landingPage.getregistrationModalComponent().getAccountTypeSelection().getSelect().getFirstSelectedOption().getText().equalsIgnoreCase(accountTypePreSelection));
	}
	
	@Then("I will see the input for Account Number the placeholder label $accountNumberPreFill")
	public void IWillSeeTheAccountNumberInput(@Named("accountNumberPreFill") String accountNumberPreFill){
		assertTrue(accountNumberPreFill,
				landingPage.getregistrationModalComponent().getAccountNumberInput().getAttribute("placeholder").equalsIgnoreCase(accountNumberPreFill));
	}
	
	@When("I select the account type $accountType")
	public void ISelectAcctType(@Named("accountType") String accountType){
		landingPage.getregistrationModalComponent().selectAccountType(accountType);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	@When("I type the account number $accountNumber")
	public void ITypeAcctNum(@Named("accountNumber") String accountNumber){
		landingPage.getregistrationModalComponent().typeAccountNumberInput(accountNumber);
	}
	
	@When("I type the new account number for program $programNumber")
	public void ITypeNewAcctNum(@Named("programNumber") String programNumber){
		String accountNumber = readWriteAccountNumbers.getNextAvailableAccountNumber(programNumber);
		landingPage.getregistrationModalComponent().typeAccountNumberInput(accountNumber);
	}
	
	@Then("I will see the account type as selected $accountType and account number as password field")
	public void IWillSeeAcctTypeAndAcctNum(@Named("accountType") String accountType){
		assertTrue(accountType,
				landingPage.getregistrationModalComponent().getAccountTypeSelection().getSelect().getFirstSelectedOption().getText().equalsIgnoreCase(accountType));
		assertTrue(LandingPage.PASSWORD,
				landingPage.getregistrationModalComponent().getAccountNumberInput().getAttribute("type").equalsIgnoreCase(LandingPage.PASSWORD));
	}
	
	@When("I click from registration modal on next button $regNextButtonName")
	public void IClickOnRegNext(@Named("regNextButtonName") String regNextButtonName){
		assertTrue(regNextButtonName, 
				landingPage.getregistrationModalComponent().getRegNextButton().getText().equalsIgnoreCase(regNextButtonName));
		
		landingPage.getregistrationModalComponent().clickNextButton();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * REGISTRATION PAGE 1
	 * */

	@Then("I will see the registration page 1 with title $reg1PageTitle")
	public void IWillSeeRegistrationPage1(@Named("reg1PageTitle") String reg1PageTitle){
		assertTrue("I see the Registration page 1", registrationPage1.isLoaded());
		assertTrue("I see the title: "+reg1PageTitle,
				registrationPage1.getPageTitle().getText().equalsIgnoreCase(reg1PageTitle));
	}
	
	@Then("I will see the registration form 1 message $reg1FormMessage")
	public void IWillSeeRegistrationForm1Msg(@Named("reg1FormMessage") String reg1FormMessage){
		assertTrue("I see the Registration form 1 message: "+reg1FormMessage,
				registrationPage1.getFormMessage().getText().equalsIgnoreCase(reg1FormMessage));
	}

	@Then("I will see the registration form 1 labels as $regCustomerNumLabel and $regNamePrefixLabel and $regFirstNameLabel and $regLastNameLabel and $regNameSuffixLabel and $regCountryLabel and $regAddress1Label and $regAddress2Label and $regCityLabel and $regStateLabel and $regZipLabel and $regBusPhoneLabel and $regFaxLabel and $regSsnLabel and $regBirthLabel")
	public void IWillSeeRegistrationForm1Labels(@Named("regCustomerNumLabel") String regCustomerNumLabel,
												@Named("regNamePrefixLabel") String regNamePrefixLabel,
												@Named("regFirstNameLabel") String regFirstNameLabel,
												@Named("regLastNameLabel") String regLastNameLabel,
												@Named("regNameSuffixLabel") String regNameSuffixLabel,
												@Named("regCountryLabel") String regCountryLabel, 
												@Named("regAddress1Label") String regAddress1Label, 
												@Named("regAddress2Label") String regAddress2Label, 
												@Named("regCityLabel") String regCityLabel, 
												@Named("regStateLabel") String regStateLabel, 
												@Named("regZipLabel") String regZipLabel, 
												@Named("regBusPhoneLabel") String regBusPhoneLabel, 
												@Named("regFaxLabel") String regFaxLabel, 
												@Named("regSsnLabel") String regSsnLabel, 
												@Named("regBirthLabel") String regBirthLabel){
		assertTrue("I see correct Customer Number label",
				registrationPage1.getCustomerNumberLabel().getText().equalsIgnoreCase(regCustomerNumLabel));
		assertTrue("I see correct Name Prefix label",
				registrationPage1.getNamePrefixLabel().getText().equalsIgnoreCase(regNamePrefixLabel));
		assertTrue("I see correct First Name label",
				registrationPage1.getFirstNameLabel().getText().equalsIgnoreCase(regFirstNameLabel));
		assertTrue("I see correct Last Name label",
				registrationPage1.getLastNameLabel().getText().equalsIgnoreCase(regLastNameLabel));
		assertTrue("I see correct Name Suffix label",
				registrationPage1.getNameSuffixLabel().getText().equalsIgnoreCase(regNameSuffixLabel));
		assertTrue("I see correct Country label",
				registrationPage1.getCountryLabel().getText().equalsIgnoreCase(regCountryLabel));
		assertTrue("I see correct Address 1 label",
				registrationPage1.getAddress1Label().getText().equalsIgnoreCase(regAddress1Label));
		assertTrue("I see correct Address 2 label",
				registrationPage1.getAddress2Label().getText().equalsIgnoreCase(regAddress2Label));
		assertTrue("I see correct City label",
				registrationPage1.getCityLabel().getText().equalsIgnoreCase(regCityLabel));
		assertTrue("I see correct State label",
				registrationPage1.getStateLabel().getText().equalsIgnoreCase(regStateLabel));
		assertTrue("I see correct Zip Code label",
				registrationPage1.getZipLabel().getText().equalsIgnoreCase(regZipLabel));
		assertTrue("I see correct Business Phone label",
				registrationPage1.getBusPhoneLabel().getText().toLowerCase().contains(regBusPhoneLabel));
		assertTrue("I see correct Fax Number label",
				registrationPage1.getFaxPhoneLabel().getText().toLowerCase().contains(regFaxLabel));
		assertTrue("I see correct SSN label",
				registrationPage1.getSsnLabel().getText().equalsIgnoreCase(regSsnLabel));
		assertTrue("I see correct Birth Date label",
				registrationPage1.getBirthLabel().getText().equalsIgnoreCase(regBirthLabel));
	}
	
	 
	@When("I input the values in the registration form 1 for program $programNumber and $regNamePrefix and $regFirstName  and $regLastName and $regNameSuffix and $regCountry and $regAddress1 and $regAddress2 and $regCity and $regState and $regZip and $regBusPhone and $regFax and $regSsn and $regBirth")
	public void IWillInputValuesInRegistrationForm1(@Named("programNumber") String programNumber,
													@Named("regNamePrefix") String regNamePrefix,
													@Named("regFirstName") String regFirstName,
													@Named("regLastName") String regLastName,
													@Named("regNameSuffix") String regNameSuffix,
													@Named("regCountry") String regCountry, 
													@Named("regAddress1") String regAddress1, 
													@Named("regAddress2") String regAddress2, 
													@Named("regCity") String regCity, 
													@Named("regState") String regState, 
													@Named("regZip") String regZip, 
													@Named("regBusPhone") String regBusPhone, 
													@Named("regFax") String regFax, 
													@Named("regSsn") String regSsn, 
													@Named("regBirth") String regBirth){
		String accountNumber = readWriteAccountNumbers.getNextAvailableAccountNumber(programNumber);
		registrationPage1.typeCustomerNumberInput(accountNumber);
		registrationPage1.typeNamePrefixInput(regNamePrefix);
		registrationPage1.typeFirstNameInput(regFirstName);
		registrationPage1.typeLastNameInput(regLastName);
		registrationPage1.typeNameSuffixInput(regNamePrefix);
		registrationPage1.selectCountry(regCountry);
		registrationPage1.typeAddress1Input(regAddress1);
		registrationPage1.typeAddress2Input(regAddress2);
		registrationPage1.typeCityInput(regCity);
		registrationPage1.typeStateInput(regState);
		registrationPage1.typeZipInput(regZip);
		registrationPage1.typeBusPhoneInput(regBusPhone);
		registrationPage1.typeFaxPhoneInput(regFax);
		registrationPage1.typeBirthInput(regBirth); //this cannot be last because a dialog box appear on top of the Terms&Conditions checkbox.
		registrationPage1.typeSsnInput(regSsn);
	}
	
	@When("I select to accept the terms and conditions <regTermsAndCondLabel>")
	public void IClickOnSelectTermsAndCond(@Named("regTermsAndCondLabel") String regTermsAndCondLabel){
		assertTrue(regTermsAndCondLabel, 
				registrationPage1.getTermsAndCondText().getText().equalsIgnoreCase(regTermsAndCondLabel));
		
		registrationPage1.checkTermsAndCondCheckbox();
	}

	@When("I select to accept the terms and conditions for user profile")
	public void IClickOnSelectTermsAndCondUserProfile(){
		registrationPage1.checkTermsAndCondCheckbox();
	}

	@When("I click from registration page 1 on next button <reg1NextButtonName>")
	public void IClickOnRegPage1Next(@Named("reg1NextButtonName") String reg1NextButtonName){
		assertTrue(reg1NextButtonName, 
				registrationPage1.getRegNextButton().getText().equalsIgnoreCase(reg1NextButtonName));
		
		registrationPage1.clickNextButton();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * REGISTRATION PAGE 2
	 */

	@Then("I will see the registration page 2 with title $reg2PageTitle")
	public void IWillSeeRegistrationPage2(@Named("reg2PageTitle") String reg2PageTitle){
		assertTrue("I see the Registration page 2", registrationPage2.isLoaded());
		assertTrue("I see the title: "+reg2PageTitle,
				registrationPage2.getPageTitle().getText().equalsIgnoreCase(reg2PageTitle));
	}
	
	@Then("I will see the registration form 2 message $reg2FormMessage")
	public void IWillSeeRegistrationForm2Msg(@Named("reg2FormMessage") String reg2FormMessage){
		assertTrue("I see the Registration form 2 message: "+reg2FormMessage,
				registrationPage2.getFormMessage().getText().equalsIgnoreCase(reg2FormMessage));
	}

	@Then("I will see the registration form 2 labels as $regUserIdLabel and $regPasswordLabel and $regPasswordCfmLabel and $regSecQuestion0Label and $regAnswer0Label and $regAnswer0CfmLabel and $regSecQuestion1Label and $regAnswer1Label and $regAnswer1CfmLabel and $regSecQuestion2Label and $regAnswer2Label and $regAnswer2CfmLabel and $regEmailLabel and $regEmailCfmLabel")
	public void IWillSeeRegistrationForm2Labels(@Named("regUserIdLabel") String regUserIdLabel, 
											   	@Named("regPasswordLabel") String regPasswordLabel, 
											   	@Named("regPasswordCfmLabel") String regPasswordCfmLabel, 
											   	@Named("regSecQuestion0Label") String regSecQuestion0Label, 
											   	@Named("regAnswer0Label") String regAnswer0Label, 
											   	@Named("regAnswer0CfmLabel") String regAnswer0CfmLabel,
											   	@Named("regSecQuestion1Label") String regSecQuestion1Label, 
											   	@Named("regAnswer1Label") String regAnswer1Label, 
											   	@Named("regAnswer1CfmLabel") String regAnswer1CfmLabel,
											   	@Named("regSecQuestion2Label") String regSecQuestion2Label, 
											   	@Named("regAnswer2Label") String regAnswer2Label, 
											   	@Named("regAnswer2CfmLabel") String regAnswer2CfmLabel, 
											   	@Named("regEmailLabel") String regEmailLabel, 
											   	@Named("regEmailCfmLabel") String regEmailCfmLabel){
		assertTrue("I see correct User Id label",
				registrationPage2.getUserIdLabel().getText().equalsIgnoreCase(regUserIdLabel));
		assertTrue("I see correct Password label",
				registrationPage2.getPasswordLabel().getText().equalsIgnoreCase(regPasswordLabel));
		assertTrue("I see correct Password Confirmation label",
				registrationPage2.getPasswordCfmLabel().getText().equalsIgnoreCase(regPasswordCfmLabel));
		assertTrue("I see correct Security Question 0 label",
				registrationPage2.getSecQuestion0Label().getText().equalsIgnoreCase(regSecQuestion0Label));
		assertTrue("I see correct Security Answer 0 label",
				registrationPage2.getAnswer0Label().getText().equalsIgnoreCase(regAnswer0Label));
		assertTrue("I see correct Security Answer 0 Confirmation label",
				registrationPage2.getAnswer0CfmLabel().getText().equalsIgnoreCase(regAnswer0CfmLabel));
		assertTrue("I see correct Security Question 1 label",
				registrationPage2.getSecQuestion1Label().getText().equalsIgnoreCase(regSecQuestion1Label));
		assertTrue("I see correct Security Answer 1 label",
				registrationPage2.getAnswer1Label().getText().equalsIgnoreCase(regAnswer1Label));
		assertTrue("I see correct Security Answer 1 Confirmation label",
				registrationPage2.getAnswer1CfmLabel().getText().equalsIgnoreCase(regAnswer1CfmLabel));
		assertTrue("I see correct Security Question 2 label",
				registrationPage2.getSecQuestion2Label().getText().equalsIgnoreCase(regSecQuestion2Label));
		assertTrue("I see correct Security Answer 2 label",
				registrationPage2.getAnswer2Label().getText().equalsIgnoreCase(regAnswer2Label));
		assertTrue("I see correct Security Answer 2 Confirmation label",
				registrationPage2.getAnswer2CfmLabel().getText().equalsIgnoreCase(regAnswer2CfmLabel));
		assertTrue("I see correct Email label",
				registrationPage2.getEmailLabel().getText().equalsIgnoreCase(regEmailLabel));
		assertTrue("I see correct Email Confirmation label",
				registrationPage2.getEmailCfmLabel().getText().equalsIgnoreCase(regEmailCfmLabel));
	}
	
	 
	@When("I input the values in the registration form 2 for program <programNumber> and $regPassword and $regPasswordCfm and $regSecQuestion0 and $regAnswer0 and $regAnswer0Cfm and $regSecQuestion1 and $regAnswer1 and $regAnswer1Cfm and $regSecQuestion2 and $regAnswer2 and $regAnswer2Cfm")
	public void IWillInputValuesInRegistrationForm2(@Named("programNumber") String programNumber, 
												   	@Named("regPassword") String regPassword, 
												   	@Named("regPasswordCfm") String regPasswordCfm, 
												   	@Named("regSecQuestion0") String regSecQuestion0, 
												   	@Named("regAnswer0") String regAnswer0, 
												   	@Named("regAnswer0Cfm") String regAnswer0Cfm,
												   	@Named("regSecQuestion1") String regSecQuestion1, 
												   	@Named("regAnswer1") String regAnswer1, 
												   	@Named("regAnswer1Cfm") String regAnswer1Cfm,
												   	@Named("regSecQuestion2") String regSecQuestion2, 
												   	@Named("regAnswer2") String regAnswer2, 
												   	@Named("regAnswer2Cfm") String regAnswer2Cfm){
		String acctNum = readWriteAccountNumbers.getNextAvailableAccountNumber(programNumber);
		registrationPage2.typeUserIDInput("user" + acctNum);
		registrationPage2.typePasswordInput(regPassword);
		registrationPage2.typePasswordCfmInput(regPasswordCfm);
		registrationPage2.selectSecQuestion0(regSecQuestion0);
		registrationPage2.typeAnswer0Input(regAnswer0);
		registrationPage2.typeAnswer0CfmInput(regAnswer0Cfm);
		registrationPage2.selectSecQuestion1(regSecQuestion1);
		registrationPage2.typeAnswer1Input(regAnswer1);
		registrationPage2.typeAnswer1CfmInput(regAnswer1Cfm);
		registrationPage2.selectSecQuestion2(regSecQuestion2);
		registrationPage2.typeAnswer2Input(regAnswer2);
		registrationPage2.typeAnswer2CfmInput(regAnswer2Cfm);
		registrationPage2.typeEmailInput(acctNum + "@mail.com");
		registrationPage2.typeEmailCfmInput(acctNum + "@mail.com");
	}

	@When("I input the values in the profile form $accountNumber and $regPassword and $regPasswordCfm and $regSecQuestion0 and $regAnswer0 and $regAnswer0Cfm and $regSecQuestion1 and $regAnswer1 and $regAnswer1Cfm and $regSecQuestion2 and $regAnswer2 and $regAnswer2Cfm")
	public void IWillInputValuesInProfileForm(@Named("regPassword") String regPassword,
											  		@Named("accountNumber") String accountNumber,
													@Named("regPasswordCfm") String regPasswordCfm,
													@Named("regSecQuestion0") String regSecQuestion0,
													@Named("regAnswer0") String regAnswer0,
													@Named("regAnswer0Cfm") String regAnswer0Cfm,
													@Named("regSecQuestion1") String regSecQuestion1,
													@Named("regAnswer1") String regAnswer1,
													@Named("regAnswer1Cfm") String regAnswer1Cfm,
													@Named("regSecQuestion2") String regSecQuestion2,
													@Named("regAnswer2") String regAnswer2,
													@Named("regAnswer2Cfm") String regAnswer2Cfm){
		registrationPage2.typeUserIDInput("user" + accountNumber);
		registrationPage2.typePasswordInput(regPassword);
		registrationPage2.typePasswordCfmInput(regPasswordCfm);
		registrationPage2.selectSecQuestion0(regSecQuestion0);
		registrationPage2.typeAnswer0Input(regAnswer0);
		registrationPage2.typeAnswer0CfmInput(regAnswer0Cfm);
		registrationPage2.selectSecQuestion1(regSecQuestion1);
		registrationPage2.typeAnswer1Input(regAnswer1);
		registrationPage2.typeAnswer1CfmInput(regAnswer1Cfm);
		registrationPage2.selectSecQuestion2(regSecQuestion2);
		registrationPage2.typeAnswer2Input(regAnswer2);
		registrationPage2.typeAnswer2CfmInput(regAnswer2Cfm);
		registrationPage2.typeEmailInput(accountNumber + "@mail.com");
		registrationPage2.typeEmailCfmInput(accountNumber + "@mail.com");
	}
	
	@When("I click from registration page 2 on next button $reg2NextButtonName")
	public void IClickOnRegPage2Next(@Named("reg2NextButtonName") String reg2NextButtonName){
		assertTrue(reg2NextButtonName, 
				registrationPage2.getRegNextButton().getText().contains(reg2NextButtonName));
		
		registrationPage2.clickNextButton();
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * REGISTRATION PAGE 3
	 */

	@Then("I will see the registration page 3 with title $reg3PageTitle")
	public void IWillSeeRegistrationPage3(@Named("reg3PageTitle") String reg3PageTitle){
		assertTrue("I see the Registration page 3", registrationPage3.isLoaded());
		assertTrue("I see the title: "+reg3PageTitle,
				registrationPage3.getPageTitle().getText().equalsIgnoreCase(reg3PageTitle));
	}
	
	@Then("I will see the registration success message $regSuccessMessage")
	public void IWillSeeRegistrationSuccessMsg(@Named("regSuccessMessage") String regSuccessMessage){
		assertTrue("I see the Registration success message: "+regSuccessMessage,
				registrationPage3.getFormMessage().getText().equalsIgnoreCase(regSuccessMessage));
	}
	
	@When("I click from registration page 3 on return button $reg3ReturnButtonName for program <programNumber>")
	public void IClickOnRegPage3Return(@Named("reg3ReturnButtonName") String reg3ReturnButtonName,
									   @Named("programNumber") String programNumber){
		assertTrue(reg3ReturnButtonName, 
				registrationPage3.getRegReturnButton().getText().equalsIgnoreCase(reg3ReturnButtonName));
		readWriteAccountNumbers.setNextAvailableAccountNumberAsUsed(programNumber);
		registrationPage3.clickReturnButton();
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	
	
}
