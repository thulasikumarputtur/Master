package com.mastercard.gto.gsd.mrs.ir.redemptions;


import com.mastercard.gto.gsd.mrs.ir.component.NavigationMenuComponent;
import com.mastercard.gto.gsd.mrs.ir.page.PayWithRewardsPage;
import jline.internal.Log;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@Component
public class CashbackRedemptionsSteps {

	public static final String ACCOUNT_STATUS_TEXT = "Current Status for this Account";
	public static final String ENABLED = "ENABLED";
	public static final String DISABLED = "DISABLED";
	@Autowired
    NavigationMenuComponent navigationMenuComponent;
    @Autowired
    private PayWithRewardsPage payWithRewardsPage;

    // NAVIGATE TO PWR PAGE
    @Then("User should not see navigation menu item $navMenuItem")
    public void userShouldNotSeeNavItem(@Named("navMenuItem") String navMenuItem){
        assertTrue("Navigation menu item " + navMenuItem + " is not present.",
        		!navigationMenuComponent.navigationItemIsPresent(navMenuItem));
    }
    
    @Then("User should see navigation menu item $navMenuItem")
    public void userShouldSeeNavItem(@Named("navMenuItem") String navMenuItem){
        assertTrue("Navigation menu item " + navMenuItem + " is present.",
        		navigationMenuComponent.navigationItemIsPresent(navMenuItem));
    }
    
    @When("User clicks on navigation menu item $navMenuItem")
    public void clickOnNavItemLink(@Named("navMenuItem") String navMenuItem) {
    	navigationMenuComponent.clickOnNavigationItem(navMenuItem);
    }

	@Then("User should see the tab $tabName")
	public void userShouldSeeTheTab(@Named("tabName")String tabName){
		assertTrue(String.format("User should see the tab %s", tabName), payWithRewardsPage.isTabPresent(tabName));
	}
	
	@Then("User should see Pay with Rewards page")
	public void userShouldSeePWRPage(){
		assertTrue("PWR page is displayed.", payWithRewardsPage.getPageTitleText().equalsIgnoreCase("Pay with Rewards"));
	}
    
	// SELECT PWR CARD
    @Then("User should see Select PWR Card button")
    public void selectPWRCardButtonIsAvailable() {
		assertTrue("PWR Select Card button is displayed.", payWithRewardsPage.checkSelectCardButtonIsVisible());
    }
    
    @Then("User should not see Select PWR Card button")
    public void selectPWRCardButtonIsNotAvailable() {
		assertTrue("PWR Select Card button is not displayed.", !payWithRewardsPage.checkSelectCardButtonIsVisible());
    }

    @Then("User should see Update PWR Card button")
    public void updatePWRCardButtonIstAvailable() {
		assertTrue("PWR Update Card button is displayed.", payWithRewardsPage.checkUpdateCardButtonIsVisible());
    }

    @Then("User should not see Update PWR Card button")
    public void updatePWRCardButtonIsNotAvailable() {
		assertTrue("PWR Update Card button is not displayed.", !payWithRewardsPage.checkUpdateCardButtonIsVisible());
    }
    
    @When("User clicks on Select PWR Card button")
    public void clickOnSelectPWRCardButton() {
    	payWithRewardsPage.clickSelectCardButton();
    }
    
    @When("User clicks on Update PWR Card button")
    public void clickOnUpdatePWRCardButton() {
    	payWithRewardsPage.clickUpdateCardButton();
    }
	
	@Then("User should see PWR card selection modal")
	public void cardSelectionPWRIsAvailable(){
		assertTrue("PWR card selection modal is displayed.", payWithRewardsPage.checkSelectCardIsVisible());
	}

	@Then("User should see Automatic Pay with Rewards title")
	public void userShouldSeeAutomaticWIthRewards(){
		assertTrue("User should see Automatic Pay with Rewards title",
				payWithRewardsPage.checkAutomaticPayWithRewardsIsVisible());
	}
	
    @When("User selects and confirm a card")
    public void selectAndConfirmCardPWR(){
    	payWithRewardsPage.selectCardDropDownValue(1);
    	payWithRewardsPage.clickEnrollPWRCardButton();
    }
	
	@Then("a card enrollment $confirmation message should be displayed")
	public void confirmPWRCardEnrollIsDisplayed(@Named("confirmation") String message){
		String pwrSuccessMessage = payWithRewardsPage.getEnrollPWRSuccessMessageText();
		Log.info(pwrSuccessMessage);
		Log.info(message);
		assertTrue("Confirmation of card enrollment is displayed.", pwrSuccessMessage.contains(message));
	}
	
	// MANUAL PWR
	@Then("User should see the Manual PWR button")
	public void manualPWRButtonIsAvailable(){
		assertTrue("Manual PWR button is displayed.", payWithRewardsPage.checkManualPayButtonIsVisible());
	}

	@Then("User should not see the Manual PWR button")
	public void manualPWRButtonIsNotAvailable(){
		assertTrue("Manual PWR button is not displayed.", !payWithRewardsPage.checkManualPayButtonIsVisible());
	}
	
    @When("User clicks on Redeem Points for PWR button")
    public void clickOnRedeemPointsPWR() {
    	payWithRewardsPage.clickManualPayButton();
    }
	
	@Then("Manual Pay with Rewards section should be available")
	public void manualPWRIsAvailable(){
		assertTrue("Manual PWR section is displayed.", payWithRewardsPage.checkTypePWRAmountFieldIsVisible());
	}
	
	@When("User inputs $amount dollars amount to be redeemed")
    public void userInputsAmount(@Named("amount") int amount) {
    	payWithRewardsPage.typePWRAmount(amount);
    }
	
	@Then("the remaining points should be calculated")
	public void calculateRemainingPWRPoints() throws InterruptedException{
		payWithRewardsPage.clickCalculateButton();
		Thread.sleep(100);
		assertTrue("Remaining points correctly calculated.", payWithRewardsPage.getPointsRemainingValue()==payWithRewardsPage.getPointsAvailableValue()-payWithRewardsPage.getPointsToRedeemValue());
	}
    
    @When("User clicks on Continue with PWR button")
    public void clickOnContinuePWR() {
    	payWithRewardsPage.clickContinueManualPWRButton();
    }
	
	@Then("a PWR confirmation question should be displayed")
	public void confirmPWRButtonIsAvailable(){
		assertTrue("Confirm PWR button is displayed.", payWithRewardsPage.checkConfirmManualPWRButtonIsVisible());
	}
    
    @When("User clicks on Confirm PWR button")
    public void clickOnConfirmPWR() {
    	payWithRewardsPage.clickConfirmManualPWRButton();
    }
	
	@Then("a PWR message $pwrConfirmation should be displayed")
	public void confirmPWRIsDisplayed(@Named("pwrConfirmation") String pwrConfirmation){
		String pwrSuccessMessage = payWithRewardsPage.getManualPWRSuccessMessageText();
		Log.info(pwrSuccessMessage);
		Log.info(pwrConfirmation);
		assertTrue("Confirmation of PWR is displayed.", pwrSuccessMessage.contains(pwrConfirmation));
	}

	@Then("User should see RTR options")
	public void userShouldSeeRTROptions(){
		assertTrue("User should see RTR options",
				this.payWithRewardsPage.getAccountStatusLabel().getText().equalsIgnoreCase(ACCOUNT_STATUS_TEXT));
	}

	@When("User clicks on $tabName tab")
	public void userClicksOnTab(@Named("tabName")String tabName){
		this.payWithRewardsPage.clickOnTab(tabName);
	}

	@When("User clicks on Enabled for All Transactions button")
	public void userClickOnEnabledForAllTransactions(){
		this.payWithRewardsPage.clickOnEnabledForAllTransactionsButton();
	}

	@When("User clicks on Enabled Only for Next Transaction button")
	public void userClicksOnEnabledOnlyForNextTransaction(){
		this.payWithRewardsPage.clickOnEnabledOnlyForNextTransactionButton();
	}

	@When("User clicks on Disable Pay with Rewards button")
	public void userClicksOnDisablePayWithRewards(){
		this.payWithRewardsPage.clickOnDisablePayWithRewardsButton();
	}

	@Then("User should see Enabled for All Transactions button $status")
	public void userShouldSeeEnableForllTransactionButton(@Named("$status")String status){
		switch(status.toUpperCase()){
			case "ENABLED":
				assertTrue("User should see Enabled for All Transactions button " + status,
						this.payWithRewardsPage.getEnabledAllTransactionButton().isEnabled());
				break;
			case "DISABLED":
				assertTrue("User should see Enabled for All Transactions button " + status,
						!this.payWithRewardsPage.getEnabledAllTransactionButton().isEnabled());
				break;
		}
	}

	@Then("User should see Enabled Only for Next Transaction button $status")
	public void userShouldSeeEnableOnlyForNextTransactionButton(@Named("$status")String status){
		switch(status.toUpperCase()){
			case "ENABLED":
				assertTrue("User should see Enabled Only for Next Transaction button " + status,
						this.payWithRewardsPage.getEnabledOnlyNextTransactionButton().isEnabled());
				break;
			case "DISABLED":
				assertTrue("User should see Enabled Only for Next Transaction button " + status,
						!this.payWithRewardsPage.getEnabledOnlyNextTransactionButton().isEnabled());
				break;
		}
	}


	@Then("User should see Disable Pay with Rewards button $status")
	public void userShouldSeeEnableDisablePayWithRewardsButton(@Named("$status")String status){
		switch(status.toUpperCase()){
			case ENABLED:
				assertTrue("User should see Disable Pay with Rewards button " + status,
						this.payWithRewardsPage.getDisablePayWithRewardsButton().isEnabled());
				break;
			case DISABLED:
				assertTrue("User should see Disable Pay with Rewards button " + status,
						!this.payWithRewardsPage.getDisablePayWithRewardsButton().isEnabled());
				break;
		}
	}

	@Then("User should see current status as $currentStatus")
	public void userShouldSeeCurrentStatus(@Named("currentStatus")String currentStatus){
		assertTrue("User should see current status as " + currentStatus,
				this.payWithRewardsPage.getCurrentStatusLabel().getText().equalsIgnoreCase(currentStatus));
	}

	@When("User inputs the minimum cash amount $amount")
	public void userInputsMinimumCashAmount(@Named("amount")String amount){
		this.payWithRewardsPage.typeMinimumAmount(amount);
		this.payWithRewardsPage.clickOnApplyThresholdButton();
	}

	@Then("The confirmation message should be $visibility")
	public void theConfirmationMessageShouldBe(@Named("visibility")String visibility){

		String message = "The confirmation message should be " + visibility;
		switch (visibility.toUpperCase()){
			case ENABLED:
				assertTrue(message,
						this.payWithRewardsPage.checkConfirmationMessageVisibility());
				break;
			case DISABLED:
				assertFalse(message,
						this.payWithRewardsPage.checkConfirmationMessageVisibility());
				break;
		}
	}
}