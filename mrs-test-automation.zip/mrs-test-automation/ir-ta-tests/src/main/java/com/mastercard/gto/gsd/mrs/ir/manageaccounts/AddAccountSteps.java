package com.mastercard.gto.gsd.mrs.ir.manageaccounts;

import com.mastercard.gto.gsd.mrs.ir.component.AddAccountComponent;
import com.mastercard.gto.gsd.mrs.ir.domain.Properties;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 12/22/2016.
 */

@Component
public class AddAccountSteps {

    @Autowired
    private AddAccountComponent addAccountComponent;

    @Autowired
    private Environment environment;

    @When("I pass valid values in add account section")
    public void iPassValidValueInAddAccount(){
        this.addAccountComponent.selectBankProduct(environment.getProperty(Properties.ACCOUNT_TYPE));
        this.addAccountComponent.typeAccountNumber(environment.getProperty(Properties.ACCOUNT_NUMBER));
        this.addAccountComponent.typeAccountNickName(environment.getProperty(Properties.ACCOUNT_NICKNAME));
    }
}
