package com.mastercard.gto.gsd.mrs.ir.login;

import com.mastercard.gto.gsd.mrs.ir.component.PointBalanceComponent;
import com.mastercard.gto.gsd.mrs.ir.page.LandingPage;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static org.junit.Assert.assertTrue;

@Component
public class LoginSteps {

	@Autowired
	LandingPage landingPage;
	
	@Autowired
	PointBalanceComponent pointBalanceComponent;
	
	
	@Given("User is on the login Page $landingPageURL")
	public void UserIsOnLandingPage(@Named("landingPageURL") String landingPageURL){
		landingPage.navigateToLandingPageUrl(landingPageURL);
	}
	
	@Then("User should see the Login button text $loginButtonText")
	public void UserShouldSeeLoginButtonText(@Named("loginButtonText") String loginButtonText){
		assertTrue("User sees Login button text: "+loginButtonText,
				landingPage.getLoginButtonText().equalsIgnoreCase(loginButtonText));
	}
	
	@When("User clicks on the top menu login $loginLinkName")
	public void performClickOnLoginLink(@Named("loginLinkName") String loginLinkName){
		assertTrue("I click on the top menu login "+loginLinkName, 
				landingPage.clickOnTopRightLinkByName(loginLinkName));
	}
	
	@Then("User should see the Login modal")
	public void iWillSeeLoginMdal(){
		assertTrue("I see the Login modal", landingPage.getLoginFormComponent().isLoaded());
	}
	
	
	@Then("User should see the Login title $loginModalTitle")
	public void UserShouldSeeTitle(@Named("loginModalTitle") String loginModalTitle){
		assertTrue("User sees the title : "+loginModalTitle,
				landingPage.getLoginFormComponent().getPageTitle().getText().equalsIgnoreCase(loginModalTitle));
	}
	
	@Then("User should see the input for username the placeholder label $usernameLabel")
	public void IWillSeeTheUsernameInput(@Named("usernameLabel") String usernameLabel){
		assertTrue(usernameLabel,
				landingPage.getLoginFormComponent().getUserIdInput().getAttribute("placeholder").equalsIgnoreCase(usernameLabel));
	}
	
	@Then("User should see the input for password the placeholder label $passwordLabel")
	public void IWillSeeThePasswordInput(@Named("passwordLabel") String passwordLabel){
		assertTrue(passwordLabel,
				landingPage.getLoginFormComponent().getPasswordInput().getAttribute("placeholder").equalsIgnoreCase(passwordLabel));
	}
	
	@When("User types username $username and password $password")
	public void ITypeUserNameAndPassword(@Named("username") String userId, @Named("password") String password){
		landingPage.getLoginFormComponent().typeUsername(userId);
		landingPage.getLoginFormComponent().typePasswordInput(password);
	}
	
	@Then("User should see the username as text and password as password field")
	public void IWillSeeUsernameAndPassword(){
		assertTrue(LandingPage.TEXT,
				landingPage.getLoginFormComponent().getUserIdInput().getAttribute("type").equalsIgnoreCase(LandingPage.TEXT));
		assertTrue(LandingPage.PASSWORD,
				landingPage.getLoginFormComponent().getPasswordInput().getAttribute("type").equalsIgnoreCase(LandingPage.PASSWORD));
	}
	
	@When("User clicks on button login $loginButtonName")
	public void IClickOnLogin(@Named("loginButtonName") String loginButtonLabel){
		assertTrue(loginButtonLabel, 
				landingPage.getLoginFormComponent().getLoginButton().getText().equalsIgnoreCase(loginButtonLabel));
		
		landingPage.getLoginFormComponent().performLogin();
	}
	
	@Then("User should see the security questions modal")
	public void IWillSeeSecurityQuestionModal(){
		landingPage.getLoginFormAuthComponent().isLoaded();
	}
	
	@When("User types security answers $answer0 and $answer1")
	public void ITypeSecurityAnswers(@Named("answer0") String answer0, @Named("answer1") String answer1){
		landingPage.getLoginFormAuthComponent().typeAnswer0(answer0);
		landingPage.getLoginFormAuthComponent().typeAnswer1(answer1);
	}
	
	@Then("User should see the answers as password fields")
	public void IWillSeeAnswersFields(){
		assertTrue(LandingPage.PASSWORD,
				landingPage.getLoginFormAuthComponent().getAnswer0Input().getAttribute("type").equalsIgnoreCase(LandingPage.PASSWORD));
		assertTrue(LandingPage.PASSWORD,
				landingPage.getLoginFormAuthComponent().getAnswer1Input().getAttribute("type").equalsIgnoreCase(LandingPage.PASSWORD));
	}

	@When("User clicks on button submitSecurityAnswers")
	public void IClickOnSubmitSecurityAnswers(){
		landingPage.getLoginFormAuthComponent().clickSubmit();
	}
	
	@Then("User should see the validation message")
	public void IWillSeeValidationoMessage(){
		landingPage.getLoginFormComponent().isLoaded();
		
		assertTrue("I will see the validation message", 
				landingPage.getLoginFormComponent().getErrorMessage().isVisible());
	}
	
	@Then("User should see the validation message content $message")
	public void IWillSeeValidationoMessageContent(@Named("message") String message){
		assertTrue("I will see the validation message "+message, 
				landingPage.getLoginFormComponent().getErrorMessage().getText().equals(message));
	}
	
	
	//Login Using Account Number Steps
	@When("User clicks on Login by Account Number $loginAccountNumberButton button")
	public void IWillClickLoginButton(@Named("loginAccountNumberButton") String loginButtonLabel){
		landingPage.getLoginFormComponent().clickLoginUsingAccountNumberButton(loginButtonLabel);
	}
	
	@Then("User should see the Login modal for account")
	public void IWillSeeLoginModalForAccount(){
		assertTrue("I'll see the modal for account : ",
				landingPage.getLoginFormAccountComponent().isLoaded());
	}

	@Then("User should see accountType as dropdown field and accountNumber as password field")
	public void IWillSeeAccountType(){
		assertTrue(LandingPage.DROPDOWN,
				landingPage.getLoginFormAccountComponent().getAccountTypeList().getTagName()
				.equalsIgnoreCase(LandingPage.DROPDOWN));
		
		assertTrue(LandingPage.PASSWORD,
				landingPage.getLoginFormAccountComponent().getAccountNumberInput().getAttribute("type")
				.equalsIgnoreCase(LandingPage.PASSWORD));
	}

	@Then("User should not see the accountType dropdown field")
	public void UserShouldNotSeeAccountTypeField(){
		assertTrue("User does not see the accountType dropdown field",
				!landingPage.getLoginFormAccountComponent().isAccountTypeListDisplayed());
	}
	
	@When("User selects $cardProductName from account type list drop down")
	public void ISelectAccountType(@Named("cardProductName") String cardProductName){
		landingPage.getLoginFormAccountComponent().selectDropDownValue(cardProductName);
		
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		landingPage.getLoginFormAccountComponent().waitUntilIsLoaded();

	}
	
	@When("User types account number $bankAccountNumber")
	public void ITypeCardNumber(@Named("bankAccountNumber") String cardNumber){
		landingPage.getLoginFormAccountComponent().typeCardNumber(cardNumber);
	}
	
	@When("User clicks on button submitAcctNumber")
	public void IWillClickOnLoginButton(){
		landingPage.getLoginFormAccountComponent().clickLoginUsingAccountNumberSubmitButton();
	}

	@Then("User should see the error message <errorMessage>")
	public void iWillSeeTheErrorMessage(@Named("errorMessage")String errorMessage){
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		assertTrue("User should see the error message", landingPage.getLoginFormAccountComponent().getStatusMessage().getText().equalsIgnoreCase(errorMessage));
	}
	
	@Then("User should not see Login by Account Number button displayed")
	public void UserShouldNotSeeLoginByAcctNumBtnDisplayed(){
		assertTrue("User does not see the Login using Account Number button",
				!landingPage.getLoginFormComponent().isLoginUsingAccountNumberButtonDisplayed());
	}
	
	//Verification: NO QUESTIONS
	@Then("User should see the confirm Submit modal")
	public void UserShouldSeeTheConfirmSubmitModal(){
		assertTrue("User sees the modal for Submit confirmation",
				landingPage.getLoginFormNoQuestionComponent().isLoaded());
	}
	
	@When("User clicks on button submitLogin")
	public void UserClicksOnSubmitLogin(){
		landingPage.getLoginFormNoQuestionComponent().clickSubmitButton();
	}

	//Verification: BIRTHDATE
	@Then("User should see the confirm Birthdate modal")
	public void UserShouldSeeTheConfirmBirthdateModal(){
		assertTrue("User sees the modal for Birthdate confirmation",
				landingPage.getLoginFormBirthdateComponent().isLoaded());
	}
	
	@When("User types Birthdate $loginBirthdate")
	public void UserTypesBirthdate(@Named("loginBirthdate") String loginBirthdate){
		landingPage.getLoginFormBirthdateComponent().typeBirthdate(loginBirthdate);
	}

	@When("User clicks on button submitBirthdate")
	public void UserClicksOnSubmitBirthdate(){
		landingPage.getLoginFormBirthdateComponent().clickSubmitButton();
	}

	//Verification: GENERIC
	@Then("User should see the confirm Generic modal")
	public void UserShouldSeeTheConfirmGenericModal(){
		assertTrue("User sees the modal for Generic confirmation",
				landingPage.getLoginFormGenericComponent().isLoaded());
	}
	
	@When("User types Generic $loginGeneric")
	public void UserTypesGeneric(@Named("loginGeneric") String loginGeneric){
		landingPage.getLoginFormGenericComponent().typeGeneric(loginGeneric);
	}

	@When("User clicks on button submitGeneric")
	public void UserClicksOnSubmitGeneric(){
		landingPage.getLoginFormGenericComponent().clickSubmitButton();
	}

	//Verification: MOTHER'S MAIDEN NAME
	@Then("User should see the confirm MothersMaidenName modal")
	public void UserShouldSeeTheConfirmMothersMaidenNameModal(){
		assertTrue("User sees the modal for MothersMaidenName confirmation",
				landingPage.getLoginFormMotherNameComponent().isLoaded());
	}
	
	@When("User types MothersMaidenName $loginMothersMaidenName")
	public void UserTypesMothersMaidenName(@Named("loginMothersMaidenName") String loginMothersMaidenName){
		landingPage.getLoginFormMotherNameComponent().typeMotherName(loginMothersMaidenName);
	}

	@When("User clicks on button submitMothersMaidenName")
	public void UserClicksOnSubmitMothersMaidenName(){
		landingPage.getLoginFormMotherNameComponent().clickSubmitButton();
	}
	
	//Verification: SSN
	@Then("User should see the confirm SSN modal")
	public void UserShouldSeeTheConfirmSsnModal(){
		assertTrue("User sees the modal for SSN confirmation",
				landingPage.getLoginFormSecurityQuestionsComponent().isLoaded());
	}
	
	@When("User types SSN $loginSSN")
	public void UserTypesSsn(@Named("loginSSN") String loginSSN){
		landingPage.getLoginFormSecurityQuestionsComponent().typeSSN(loginSSN);
	}

	@When("User types values for $loginSSN, $loginBirthdate, $loginMothersMaidenName, $loginPhone, $loginGeneric")
	public void userTypesValuesForLogin(@Named("$loginSSN")String loginSSN,
										@Named("$loginBirthDate")String loginBirthDate,
										@Named("$loginMotherMaidenName")String loginMotherMaidenName,
										@Named("$loginPhone")String loginPhone,
										@Named("$loginGeneric")String loginGeneric){
		this.landingPage.getLoginFormSecurityQuestionsComponent().typeSSN(loginSSN);
		//this.landingPage.getLoginFormSecurityQuestionsComponent().typeDateOfBirth(loginBirthDate);
		this.landingPage.getLoginFormSecurityQuestionsComponent().typeMothersMaidenName(loginMotherMaidenName);
		//this.landingPage.getLoginFormSecurityQuestionsComponent().typePhoneNumber(loginPhone);
		this.landingPage.getLoginFormSecurityQuestionsComponent().typeGenericInfo(loginGeneric);
	}
	
	@Then("User should see the ssn as password field")
	public void UserShouldSeeSsnFields(){
		assertTrue(LandingPage.PASSWORD,
				landingPage.getLoginFormSecurityQuestionsComponent().getSsnInput().getAttribute("type").equalsIgnoreCase(LandingPage.PASSWORD));
	}

	@When("User clicks on button submitSsn")
	public void UserClicksOnSubmitSsn(){
		landingPage.getLoginFormSecurityQuestionsComponent().clickSubmitButton();
	}

	//Verification: PHONE NUMBER
	@Then("User should see the confirm PhoneNumber modal")
	public void UserShouldSeeTheConfirmPhoneNumberModal(){
		assertTrue("User sees the modal for PhoneNumber confirmation",
				landingPage.getLoginFormPhoneNumberComponent().isLoaded());
	}
	
	@When("User types PhoneNumber $loginPhone")
	public void UserTypesPhoneNumber(@Named("loginPhone") String loginPhone){
		landingPage.getLoginFormPhoneNumberComponent().typePhone(loginPhone);
	}

	@When("User clicks on button submitPhoneNumber")
	public void UserClicksOnSubmitPhoneNumber(){
		landingPage.getLoginFormPhoneNumberComponent().clickSubmitButton();
	}
	
	//Post Login
	@Then("User should see post login page $userNameText")
	public void IWillSeePostLoginPage(@Named("userNameText") String userName){
		assertTrue(userName,
				landingPage.getLoginFormResultsComponent().getUserName().equalsIgnoreCase(userName));
		landingPage.saveCsrfToken();
	}
	
	@Given("User is logged in")
	public void userisLoggedIn(){
		assertTrue("User is logged in.", pointBalanceComponent.isLoaded());
	}
	
}
