package com.mastercard.gto.gsd.mrs.ir.util;

import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.charset.Charset;

@Component
public class ReadWriteAccountNumbers {
 
	/*public static void main(String[] args){
        String s = getNewAccountNumber();
		System.out.println(s);
	}*/

    public String getNextAvailableAccountNumber(String progNumber) {
        String filePath = "./src/main/resources/properties/testData_AccountNumbers_" + progNumber + ".txt";
        String accountNumber = null;

        try {

            File inFile = new File(filePath);

            if (!inFile.isFile()) {
                System.out.println("Parameter is not an existing file");
                return null;
            }

            BufferedReader br = new BufferedReader(
                    new InputStreamReader(new FileInputStream(filePath), Charset.defaultCharset()));

            String line = null;

            //Read from the original file
            while ((line = br.readLine()) != null) {
                String values[] = line.split("\\|");

                if (values[1].equals("0")) {
                    accountNumber = values[0];
                    break;
                }
            }
            br.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return accountNumber;
    }

    public String setNextAvailableAccountNumberAsUsed(String progNumber) {
        String filePath = "./src/main/resources/properties/testData_AccountNumbers_" + progNumber + ".txt";
        String accountNumber = null;

        try {

            File inFile = new File(filePath);

            if (!inFile.isFile()) {
                System.out.println("Parameter is not an existing file");
                return null;
            }

            //Construct the new file that will later be renamed to the original filename.
            File tempFile = new File(inFile.getAbsolutePath() + ".tmp");

            Charset defaultCharset = Charset.defaultCharset();
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), defaultCharset));
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(tempFile), defaultCharset));

            String line = null;
            boolean gotOne = false;

            //Read from the original file and write to the new
            //Changes the flag of the first available account number.
            while ((line = br.readLine()) != null) {

                String [] values = line.split("\\|");
                if ((values[1].equals("0")) && (!gotOne)) {
                    accountNumber = values[0];
                    line = accountNumber.concat("|1");
                    gotOne = true;
                }

                pw.println(line);
                pw.flush();
            }
            pw.close();
            br.close();

            //Delete the original file
            if (!inFile.delete()) {
                System.out.println("Could not delete file");
                return null;
            }

            //Rename the new file to the filename the original file had.
            if (!tempFile.renameTo(inFile))
                System.out.println("Could not rename file");

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return accountNumber;
    }

}
