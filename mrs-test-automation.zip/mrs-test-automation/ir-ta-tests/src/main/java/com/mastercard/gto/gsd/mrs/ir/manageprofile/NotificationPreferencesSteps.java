package com.mastercard.gto.gsd.mrs.ir.manageprofile;

import com.mastercard.gto.gsd.mrs.ir.component.NotificationPreferenceComponent;
import com.mastercard.gto.gsd.mrs.ir.domain.Properties;
import com.mastercard.gto.gsd.mrs.ir.page.ManageProfilePage;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import static org.junit.Assert.assertTrue;

/**
 * Created by e054649 on 12/13/2016.
 */

@Component
public class NotificationPreferencesSteps {

    @Autowired
    private NotificationPreferenceComponent notificationPreferenceComponent;

    @Autowired
    private ManageProfilePage manageProfilePage;

    @Autowired
    private Environment environment;

    private static final String INVALID_EMAIL = "@#_INVALID";
    private static final String INVALID_MOBILE = "321FADAFDSA";

    @When("I pass valid values in mobile number and email fields")
    public void iPassValidValuesNotificationPreference(){
        this.notificationPreferenceComponent.typeEmailAddress(environment.getProperty(Properties.NOTIFICATION_PREFERENCE_EMAIL));
        this.notificationPreferenceComponent.typeMobileNumber(environment.getProperty(Properties.NOTIFICATION_PREFERENCE_MOBILE_NUMBER));

        this.notificationPreferenceComponent.retypeEmailAddress(environment.getProperty(Properties.NOTIFICATION_PREFERENCE_EMAIL));
        this.notificationPreferenceComponent.retypeMobileNumber(environment.getProperty(Properties.NOTIFICATION_PREFERENCE_MOBILE_NUMBER));
        this.notificationPreferenceComponent.clickOnSubmitButton();
    }

    @When("I pass valid values in mobile number and invalid value in the email field")
    public void iPassValidMobileInvalidEMailNotificationPreference(){
        this.notificationPreferenceComponent.typeEmailAddress(INVALID_EMAIL);
        this.notificationPreferenceComponent.retypeEmailAddress(INVALID_EMAIL);

        this.notificationPreferenceComponent.typeMobileNumber(environment.getProperty(Properties.NOTIFICATION_PREFERENCE_MOBILE_NUMBER));
        this.notificationPreferenceComponent.retypeMobileNumber(environment.getProperty(Properties.NOTIFICATION_PREFERENCE_MOBILE_NUMBER));
        this.notificationPreferenceComponent.clickOnSubmitButton();
    }

    @When("I pass invalid values in mobile number and email fields")
    public void iPassInvalidValuesNotificationPreference(){
        this.notificationPreferenceComponent.typeEmailAddress(INVALID_EMAIL);
        this.notificationPreferenceComponent.retypeEmailAddress(INVALID_EMAIL);

        this.notificationPreferenceComponent.typeMobileNumber(INVALID_MOBILE);
        this.notificationPreferenceComponent.retypeMobileNumber(INVALID_MOBILE);
        this.notificationPreferenceComponent.clickOnSubmitButton();
    }

    @When("I pass valid value in email and different value in retype email field")
    public void iPassValidMobileEMailNotificationPreference(){
        this.notificationPreferenceComponent.typeEmailAddress(environment.getProperty(Properties.NOTIFICATION_PREFERENCE_EMAIL));
        this.notificationPreferenceComponent.retypeEmailAddress("a@b.com");

        this.notificationPreferenceComponent.typeMobileNumber(environment.getProperty(Properties.NOTIFICATION_PREFERENCE_MOBILE_NUMBER));
        this.notificationPreferenceComponent.retypeMobileNumber(environment.getProperty(Properties.NOTIFICATION_PREFERENCE_MOBILE_NUMBER));
        this.notificationPreferenceComponent.clickOnSubmitButton();
    }

    @Then("I will see the update notification preference successful message")
    public void iWillSuccessfulMessage() {
        assertTrue("I will see the successful message",
                this.manageProfilePage.getSuccessMessage().getText().equalsIgnoreCase("Your request has been performed successfully."));
    }

}
