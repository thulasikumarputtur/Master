package com.mastercard.gto.gsd.mrs.ir.redemptions;


import com.mastercard.gto.gsd.mrs.ir.domain.CsfrToken;
import com.mastercard.gto.gsd.mrs.ir.page.ItemDetailsPage;
import com.mastercard.gto.gsd.mrs.ir.page.ShoppingCartPage;
import org.eclipse.jetty.util.annotation.Name;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static org.junit.Assert.assertTrue;

@Component
public class RedemptionsSteps {

    @Autowired
    ItemDetailsPage itemDetailsPage;

    @Autowired
    ShoppingCartPage shoppingCartPage;

    @Given("I am on the redemption Page $landingPageURL")
    public void iAmOnLandingPage(@Named("landingPageURL") String landingPageURL) {

        StringBuilder sb = new StringBuilder(landingPageURL);
        sb.append("/shop?csrf_token=");
        sb.append(CsfrToken.getCrfsToken());

        shoppingCartPage.navigateToPage(sb.toString());
    }

    @When("I search for the item $item")
    public void iSearchFortheItemDescription(@Name("$redemptionItemDesc")String $redemptionItemDesc){
        this.itemDetailsPage.getItemDetailsLoggedInComponent().typeSearch($redemptionItemDesc);
        this.itemDetailsPage.getItemDetailsLoggedInComponent().clickOnSearchButton();
    }

    @When("I see the redemption item link")
    public void iSeeTheRedemptionItemLink() {
        itemDetailsPage.getItemDetailsLoggedInComponent().isLoadedConditions();
    }

    @When("I click the redemption item by description $redemptionItemName")
    public void iClickRedemption(@Named("redemptionItemName") String redemptionItemName) {
        assertTrue("I will click the redemption item with name " + redemptionItemName,
                itemDetailsPage.getItemDetailsLoggedInComponent().clickOnRedemptionItemByDesc(redemptionItemName));

    }

    @Then("I will see the redeem message $message")
    public void iWillSeeTheRedemmMessage(@Named("message")String message){
        assertTrue(String.format("I will see the redeem message %s", message),
                this.itemDetailsPage.getItemDetailsLoggedInComponent().getMessage().getText().equalsIgnoreCase(message));

    }

    @Then("I will verify the Item description $redemptionItemName")
    public void iWillVerifyItem(@Named("redemptionItemName") String redemptionItemName) {
        assertTrue("I will verify the Item description " + redemptionItemName,
                itemDetailsPage.getItemDetailsLoggedInComponent().getRedemptionItemDescText().equalsIgnoreCase(redemptionItemName));
    }

    @When("I check the auto-redemption checkbox")
    public void iCheckTheAutoRedemptionCheckBox(){
        if(!this.itemDetailsPage.getItemDetailsLoggedInComponent().getItemRecurRedeemCheckBox().isSelected()){
            this.itemDetailsPage.getItemDetailsLoggedInComponent().clickOnCheckBox();
        }
    }

    @When("I input the frequency to $value")
    public void iInputTheFrequency(@Named("value")String value){
        this.itemDetailsPage.getItemDetailsLoggedInComponent().inputFrequency(value);
    }

    @When("I select the item quantity to $value")
    public void iSelectQuantity(@Named("value") String value) {
        itemDetailsPage.getItemDetailsLoggedInComponent().selectQuantityValueTo(value);
    }

    @When("I click Add To Cart Button")
    public void iClickAddToCart() {
        itemDetailsPage.getItemDetailsLoggedInComponent().clickAddToCardButton();
    }

    @Then("I will see the view shopping cart page")
    public void iWillSeeShoppingCartPage() {
        assertTrue("I will see the view shopping cart page",
                shoppingCartPage.getViewShoppingCartLoggedInComponent().isLoaded());
    }

    @When("I click the CheckOut Button")
    public void iClickCheckOut() {
        shoppingCartPage.getViewShoppingCartLoggedInComponent().clickCheckOutButton();
    }

    @Then("I will see the checkout page")
    public void iWillSeeCheckoutPage() {
        assertTrue("I will see the checkout page",
                shoppingCartPage.getCheckoutLoggedInComponent().isLoaded());
    }

    @When("I click the change address button")
    public void iClickChangeAddressButton() {
        shoppingCartPage.getCheckoutLoggedInComponent().clickChangeAddressButton();
    }

    @When("I click on send to different address")
    public void iClickSendToDifferentAddressButton() {
        shoppingCartPage.getCheckoutLoggedInComponent().clickOnSendToDifferentAddress();
    }

    @Then("I will see the Shipping Address Selection modal page")
    public void iWillSeeShippingAddressSelectionPage() {
        assertTrue("I will see the Shipping Address Selection modal page",
                shoppingCartPage.getShippingAddressSelectionModalComponent().isLoaded());
    }

    @Then("I will see the the address $shipName in the Shipping Address Selection modal page")
    public void iWillSeeAddressInShippingAddressSelectionPage(@Named("$shipName") String shippingName) {
        assertTrue("I will see the the address in the Shipping Address Selection modal page",
                shoppingCartPage.getShippingAddressSelectionModalComponent().addressShippingNameCount(shippingName) >= 1);

    }

    @Then("I will see two addresses $shipName in the Shipping Address Selection modal page")
    public void iWillSeeTwoAddressesInShippingAddressSelectionPage(@Named("$shipName") String shippingName) {

        assertTrue("I will see at least two addresses $shipName in the Shipping Address Selection modal page",
                shoppingCartPage.getShippingAddressSelectionModalComponent().addressShippingNameCount(shippingName) == 2);
    }

    @When("I click the Add Shipping Address button")
    public void iClickAddShippingAddressButton() {
        shoppingCartPage.getShippingAddressSelectionModalComponent().clickAddShippingAddressButton();
    }

    @When("I click the Edit Shipping Address button")
    public void iClickEditShippingAddressButon() {
        shoppingCartPage.getShippingAddressSelectionModalComponent().clickOnEditShippingAddressButton();
    }

    @When("I click the Delete Shipping Address button")
    public void iClickDeleteShippingAddressButon() {
        shoppingCartPage.getShippingAddressSelectionModalComponent().clickOnDeleteShippingAddressButton();
    }

    @Then("I will see the Add Shipping Address modal page")
    public void iWillSeeAddShippingAddressModalPage() {
        assertTrue("I will see the Add Shipping Address modal page",
                shoppingCartPage.getShippingAddressInclusionModalComponent().isLoaded());
    }

    @When("I input the values in the add address modal page $shipCountry and $shipName and $shipAddress1 and $shipCity and $shipPhone")
    public void IWillInputValuesInRegistrationForm1(@Named("shipCountry") String shipCountry,
                                                    @Named("shipName") String shipName,
                                                    @Named("shipAddress1") String shipAddress1,
                                                    @Named("shipCity") String shipCity,
                                                    @Named("shipPhone") String shipPhone) {
        shoppingCartPage.getShippingAddressInclusionModalComponent().selectShippingCountry(shipCountry);
        shoppingCartPage.getShippingAddressInclusionModalComponent().typeShippingNameInput(shipName);
        shoppingCartPage.getShippingAddressInclusionModalComponent().clickAddressTypeResidentialRadioButton();
        shoppingCartPage.getShippingAddressInclusionModalComponent().typeShippingAddress1Input(shipAddress1);
        shoppingCartPage.getShippingAddressInclusionModalComponent().typeShippingCityInput(shipCity);
        shoppingCartPage.getShippingAddressInclusionModalComponent().typeShippingPhoneInput(shipPhone);
    }

    @When("I click on the submit Address button")
    public void iClickSubmitShippingAddressButton() {
        shoppingCartPage.getShippingAddressInclusionModalComponent().clickSubmitButton();
    }

    @When("I select the shipping address")
    public void iSelectShippingAddress() {
        shoppingCartPage.getShippingAddressSelectionModalComponent().clickSelectAddressRadioButton();
    }

    @When("I click the Ship to This button")
    public void iClickShitToThisButton() {
        shoppingCartPage.getShippingAddressSelectionModalComponent().clickShipToAddressButton();
    }

    @Then("I will see address information on the text box containg $shipName and $shipAddress1 and $shipCity")
    public void iWillSeeAddressInfo(@Named("shipName") String shipName,
                                    @Named("shipAddress1") String shipAddress1,
                                    @Named("shipCity") String shipCity) {
        assertTrue(shoppingCartPage.getCheckoutLoggedInComponent().getShippingAddressInfoBox().getText().contains(shipName));
        assertTrue(shoppingCartPage.getCheckoutLoggedInComponent().getShippingAddressInfoBox().getText().contains(shipAddress1));
        assertTrue(shoppingCartPage.getCheckoutLoggedInComponent().getShippingAddressInfoBox().getText().contains(shipCity));
    }

    @When("I enter email address as $emailAddress")
    public void iWillTypeEmailAdress(@Named("emailAddress") String emailId) {
        shoppingCartPage.getCheckoutLoggedInComponent().typeEmailAddressInput(emailId);
    }

    @When("I enter confirm email address as $emailAddress")
    public void iWillTypeConfirmEmailAdress(@Named("emailAddress") String emailId) {
        shoppingCartPage.getCheckoutLoggedInComponent().typeConfirmEmailAddressInput(emailId);
    }

    @When("I click Continue Button")
    public void iWillClickContinue() {
        shoppingCartPage.getCheckoutLoggedInComponent().clickContinueButton();
    }

    @Then("I will see the review order information page")
    public void iWillSeeReviewOrderInformationPage() {
        assertTrue("I will see the review order information page",
                shoppingCartPage.getReviewOrderInformationLoggedInComponent().isLoaded());
    }

    @Then("I will verify the final order page with $verifyText")
    public void iWillVerifyReviewText(@Named("verifyText") String verifyText) {
        assertTrue("I will verify the final order page with " + verifyText,
                shoppingCartPage.getReviewOrderInformationLoggedInComponent().verifyReviewOrderPage(verifyText));
    }

    @When("I click on review continue Button")
    public void iWillClickReivewContinueButton() {
        shoppingCartPage.getReviewOrderInformationLoggedInComponent().clickReviewContinueButton();
    }

    @Then("I will see the complete checkout page")
    public void iWillSeeCompleteCheckoutPage() {
        assertTrue("I will see the complete checkout page",
                shoppingCartPage.getCompleteCheckoutComponent().isLoaded());
    }

    @When("I click final check out Button")
    public void iWillClickFinalCheckOut() {
        shoppingCartPage.getCompleteCheckoutComponent().clickCheckOutCompleteButton();
    }

    @Then("I will see the complete checkout confirmation page")
    public void iWillSeeCompleteCheckoutConfirmationPage() {
        assertTrue("I will see the complete checkout page",
                shoppingCartPage.getCompleteCheckoutConfirmationComponent().isLoaded());
    }

    @Then("I will verify the checkout confirmation page with $confirmationText")
    public void iWillVerifyConfirmationText(@Named("confirmationText") String confirmationText) {
        assertTrue("I will verify the checkout confirmation " + confirmationText,
                shoppingCartPage.getCompleteCheckoutConfirmationComponent().verifyCheckoutCompleteFormText(confirmationText));
    }

    @When("I click ok submit Button")
    public void iWillClickOkSubmitButton() {
        shoppingCartPage.getCompleteCheckoutConfirmationComponent().clickOkSubmitButton();
    }
}