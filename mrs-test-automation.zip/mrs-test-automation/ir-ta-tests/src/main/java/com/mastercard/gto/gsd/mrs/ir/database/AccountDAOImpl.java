package com.mastercard.gto.gsd.mrs.ir.database;

import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Created by e054649 on 7/19/2017.
 */
public class AccountDAOImpl implements AccountDAO {

    @Autowired
    private DatabaseDataFactory dataBase;

    @Override
    public void deleteAccount(String accountNumber) {
        try{
            Connection con = dataBase.getMRSDataSource().getConnection();
            PreparedStatement stm = con.prepareStatement("update audit_rec set rqst_dt = sysdate - 2, resp_dt = sysdate - 2 where rqst_dt > sysdate - 1 and upper(created_by_user_id) like 'TA%'");
            stm.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }
}