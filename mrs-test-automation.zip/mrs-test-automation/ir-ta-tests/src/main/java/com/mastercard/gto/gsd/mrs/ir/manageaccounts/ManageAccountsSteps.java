package com.mastercard.gto.gsd.mrs.ir.manageaccounts;

import com.mastercard.gto.gsd.mrs.ir.domain.CsfrToken;
import com.mastercard.gto.gsd.mrs.ir.domain.Properties;
import com.mastercard.gto.gsd.mrs.ir.page.ManageAccountsPage;
import org.jbehave.core.annotations.Given;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 12/21/2016.
 */
@Component
public class ManageAccountsSteps {

    @Autowired
    private ManageAccountsPage manageAccountsPage;

    @Autowired
    private Environment environment;

    @Given("I am on the manage accounts section")
    public void iAmOnTheManageAccounts(){
        StringBuilder sb = new StringBuilder(environment.getProperty(Properties.LANDING_PAGE_URL_TEST_AUTOMATION));
        sb.append("/add-accounts?csrf_token=");
        sb.append(CsfrToken.getCrfsToken());

        manageAccountsPage.navigateToLandingPageUrl(sb.toString());
    }

}
