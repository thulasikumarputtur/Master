package com.mastercard.gto.gsd.mrs.ir.forgotpassword;

import com.mastercard.gto.gsd.mrs.ir.component.*;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static org.junit.Assert.assertTrue;

/**
 * Class used to wrap forgot Password steps.
 */

@Component
public class ForgotPasswordSteps {

    @Autowired
    private LoginFormComponent loginFormComponent;

    @Autowired
    private ForgotUserIdComponent forgotUserIdComponent;

    @Autowired
    private ForgotPasswordComponent forgotPasswordComponent;

    @Autowired
    private SecurityQuestionsComponent securityQuestionsComponent;

    @Autowired
    private ForgotPasswordResetFormComponent forgotPasswordResetFormComponent;

    @Autowired
    private ForgotPasswordConfirmationComponent forgotPasswordConfirmationComponent;

    @When("User clicks on forgot user id link")
    public void clickOnForgotUserIdLink() {
        this.loginFormComponent.clickForgotUserId();
    }

    @Then("User should see the Forgot User Id modal")
    public void userShouldSeeForgotUserIdModal() {
        assertTrue("User sees the Forgot User Id modal", forgotUserIdComponent.isLoaded());
    }

    @Then("User should see the forgot User Id message <forgotUserIdMsg>")
    public void seeForgotUserIdMsg(@Named("forgotUserIdMsg")String forgotUserIdMsg){
    	assertTrue("User sees the forgot user id message: " + forgotUserIdMsg,
                forgotUserIdComponent.getForgotUserIdMsgText().equals(forgotUserIdMsg));
    }

    @When("User clicks on Close button")
    public void clickOnCloseLink() {
        this.forgotUserIdComponent.clickCloseButton();;
    }

    @When("User clicks on forgot password link")
    public void clickOnForgotPasswordLink() {
        this.loginFormComponent.clickForgotPassword();
    }

    @Then("User should see the Forgot Password modal")
    public void userShouldSeeForgotPasswordModal() {
        assertTrue("User sees the Forgot Password modal", forgotPasswordComponent.isLoaded());
    }

    @When("User types the userId as <userID>")
    public void inputUserID(@Named("userID") String userID) {
        forgotPasswordComponent.typeUserId(userID);
    }

    @When("User clicks on submit button")
    public void clickOnSubmit() {
        forgotPasswordComponent.clickSubmitButton();
    }

    @Then("User should see the forgot password validation message")
    public void userShouldSeeValidationoMessage() {
        forgotPasswordComponent.isLoaded();

        assertTrue("User sees the validation message",
                forgotPasswordComponent.getErrorMessage().isVisible());
    }

    @Then("User should see the forgot password validation message content <message>")
    public void userShouldSeeValidationoMessageContent(@Named("message") String message) {
        assertTrue("User seesee the validation message " + message,
                forgotPasswordComponent.getErrorMessage().getText().equals(message));
    }

    @Then("User should see the security question modal")
    public void userShouldSeeSecurityQuestionModal(){
        assertTrue("User sees the Security Question modal", securityQuestionsComponent.isLoaded());
    }

    @When("User types the first answer <firstAnswer>")
    public void typeFirstAnswer(@Named("firstAnswer")String firstAnswer){
        this.securityQuestionsComponent.typeFirstAnswer(firstAnswer);
    }

    @When("User types the second answer <secondAnswer>")
    public void typeSecondAnswer(@Named("secondAnswer")String secondAnswer){
        this.securityQuestionsComponent.typeSecondAnswer(secondAnswer);
    }

    @When("User clicks on security questions submit button")
    public void clickOnSecurityQuestionSubmitButton(){
        this.securityQuestionsComponent.clickOnSubmitButton();
    }

    @Then("User should see the wrong security answer message <wrongSecAnswerMsg>")
    public void seeWrongSecAnswerMsg(@Named("wrongSecAnswerMsg")String wrongSecAnswerMsg){
    	assertTrue("User sees the wrong security answer message: " + wrongSecAnswerMsg,
                securityQuestionsComponent.getWrongAnswerMsgText().equals(wrongSecAnswerMsg));
    }

    @Then("User should see the forgot password reset modal")
    public void userShouldSeeResetPasswordModal(){
        assertTrue("User sees the Reset Password modal", forgotPasswordResetFormComponent.isLoaded());
    }

    @When("User types the new <password>")
    public void typeNewPassword(@Named("password")String password){
        this.forgotPasswordResetFormComponent.typePassword(password);
    }

    @When("User retypes the new <password>")
    public void retypeNewPassword(@Named("password")String password){
        this.forgotPasswordResetFormComponent.reTypePassword(password);
    }

    @When("User clicks on reset modal submit button")
    public void clickOnResetModalSubmitButton(){
        this.forgotPasswordResetFormComponent.clickOnSubmitButton();
    }
    
    @Then("User should see the invalid password message <invalidPassMsg>")
    public void seeInvalidPassMsg(@Named("invalidPassMsg")String invalidPassMsg){
    	assertTrue("User sees the invalid password message: " + invalidPassMsg + "\r\nMessage found: " +
                        forgotPasswordResetFormComponent.getInvalidPasswordMsgText(),
                forgotPasswordResetFormComponent.getInvalidPasswordMsgText().equals(invalidPassMsg));
    }

    @Then("User should see the reset password validation modal")
    public void userShouldSeeResetPasswordValitionModal(){
        assertTrue("User sees the Reset Password Validation modal", forgotPasswordConfirmationComponent.isLoaded());
    }

    @Then("User should see the reset password validation message")
    public void userShouldSeeResetPasswordValidationoMessage() {
        assertTrue("User sees the reset password validation message",
                forgotPasswordConfirmationComponent.getSuccessMessage().isVisible());
    }

    @Then("User should see the reset password validation message content <message>")
    public void userShouldSeeResetPasswordValidationMessageContent(@Named("message") String message) {
        assertTrue("User sees the reset password validation message " + message,
                forgotPasswordConfirmationComponent.getSuccessMessage().getText().equals(message));
    }

    @Then("User should exit the forgot password process clicking in the Ok button")
    public void exitProcessClickingOnButton(){
        this.forgotPasswordConfirmationComponent.clickOnOkButton();
    }
}
