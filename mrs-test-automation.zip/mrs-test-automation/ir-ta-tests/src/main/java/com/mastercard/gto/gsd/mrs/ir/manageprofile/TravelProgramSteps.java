package com.mastercard.gto.gsd.mrs.ir.manageprofile;

import com.mastercard.gto.gsd.mrs.ir.component.TravelProgramComponent;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 5/30/2017.
 */

@Component
public class TravelProgramSteps {

    @Autowired
    private TravelProgramComponent travelProgramComponent;
    
    @When("I input the values for travel program name $programName and for travel program membership number $programNumber")
    public void iInputValuesTravelProgramNameAndProgramNumber(@Named("programName")String programName,
                                                              @Named("programNumber") String programNumber){
        this.travelProgramComponent.typeProgramName(programName);
        this.travelProgramComponent.typeProgramNumber(programNumber);
        this.travelProgramComponent.clickOnAddButton();
    }

    @When("I edit the values for travel program name $programName and for travel program membership number $programNumber")
    public void iEditValuesTravelProgramNameAndProgramNumber(@Named("programName")String programName,
                                                             @Named("programNumber") String programNumber){
        this.travelProgramComponent.selectRadioButtonEdit();
        this.travelProgramComponent.editProgramName(programName);
        this.travelProgramComponent.editProgramNumber(programNumber);
        this.travelProgramComponent.clickOnEditButton();
    }

    @When("I select the existing travel program")
    public void iSelectExistingTravelProgram(){
        this.travelProgramComponent.selectRadioButtonEdit();
    }

    @When("I click on remove travel program button")
    public void iSelectRemoveTravelProgramButton(){
        this.travelProgramComponent.clickOnRemoveButton();
    }

    @When("I confirm the travel program removal")
    public void iConfirmTravelProgramRemoval(){
        this.travelProgramComponent.clickOnOkAlertButton();
    }
}
