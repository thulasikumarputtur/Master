package com.mastercard.gto.gsd.mrs.ir.onlinetabs;

import com.mastercard.gto.gsd.mrs.ir.component.OnlineMallComponent;
import com.mastercard.gto.gsd.mrs.ir.component.OnlineTravelComponent;
import com.mastercard.gto.gsd.mrs.ir.page.ThirdPartyOnlineMallPage;
import com.mastercard.gto.gsd.mrs.ir.page.ThirdPartyOnlineTravelPage;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 5/24/2017.
 */
@Component
public class OnlineTabsSteps {

    @Autowired
    private OnlineMallComponent onlineMallComponent;

    @Autowired
    private OnlineTravelComponent onlineTravelComponent;

    @Autowired
    private ThirdPartyOnlineMallPage thirdPartyOnlineMallPage;

    @Autowired
    private ThirdPartyOnlineTravelPage thirdPartyOnlineTravelPage;

    @When("User clicks on online mall confirmation button")
    public void userClickOnOnlineMallConfirmationButton(){
        this.onlineMallComponent.clickOnConfirmationButton();
    }

    @When("User clicks on online travel confirmation button")
    public void userClickOnOnlineTravelConfirmationButton(){
        this.onlineMallComponent.clickOnConfirmationButton();
    }

    @Then("User should see the third-party online mall $pageTitle")
    public void userShouldSeeTheThirdPartyOnlineMall(@Named("pageTitle")String pageTitle){
        try{
            Thread.sleep(5000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Switch to new window opened
        this.onlineMallComponent.switchToLastOpenWindow();
        thirdPartyOnlineMallPage.waitUntilIsLoaded();

        Assert.assertTrue("User should see the third-party online mall",
                pageTitle.equalsIgnoreCase(thirdPartyOnlineMallPage.getPageTitle()));

    }

    @Then("User should see the third-party online travel $pageTitle")
    public void userShouldSeeTheThirdPartyOnlineTravel(@Named("pageTitle")String pageTitle){

        try{
            Thread.sleep(5000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Switch to new window opened
        this.onlineTravelComponent.switchToLastOpenWindow();
        thirdPartyOnlineTravelPage.waitUntilIsLoaded();

        Assert.assertTrue("User should see the third-party online travel",
                pageTitle.equalsIgnoreCase(thirdPartyOnlineTravelPage.getPageTitle()));

    }
}
