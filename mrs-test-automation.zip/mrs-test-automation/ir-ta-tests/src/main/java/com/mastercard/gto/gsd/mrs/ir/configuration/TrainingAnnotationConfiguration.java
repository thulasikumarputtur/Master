package com.mastercard.gto.gsd.mrs.ir.configuration;

import com.mastercard.gto.gsd.mrs.sm.configuration.AppConfig;
import com.mastercard.testing.bdd.rest.configuration.BDDRestToolsConfig;
import com.mastercard.testing.mtaf.ui.configuration.MTAFWebToolsConfiguration;
import org.springframework.context.annotation.*;

@Configuration
@ComponentScan(basePackages = {"com.mastercard.gto.gsd.mrs.ir", "com.mastercard.gto.gsd.mrs.sm"})
@PropertySources({@PropertySource("${ir.params}"), @PropertySource("${sm.params}")})
@Import({MTAFWebToolsConfiguration.class,  BDDRestToolsConfig.class, AppConfig.class})
public class TrainingAnnotationConfiguration {
}
