package com.mastercard.gto.gsd.mrs.ir.manageprofile;

import com.mastercard.gto.gsd.mrs.ir.component.SecurityInformationComponent;
import com.mastercard.gto.gsd.mrs.ir.domain.Properties;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 11/17/2016.
 */
@Component
public class SecurityInformationSteps {

    @Autowired
    private Environment environment;
    @Autowired
    private SecurityInformationComponent securityInformationComponent;

    private static final String INVALID_ANSWER = "@#_INVALID";

    @When("I pass valid values in security questions, answers and retype answers fields")
    public void iPassValidValuesInTheFields(){
        this.securityInformationComponent.selectChallengeQuestion(securityInformationComponent.getChallengeQuestions0(), environment.getProperty(Properties.REG_SEC_QUESTION0));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswer0(), environment.getProperty(Properties.UCB_REWARDS_003_SEC_ANSWER));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswerConfirmation0(), environment.getProperty(Properties.UCB_REWARDS_003_SEC_ANSWER));

        this.securityInformationComponent.selectChallengeQuestion(securityInformationComponent.getChallengeQuestions1(), environment.getProperty(Properties.REG_SEC_QUESTION1));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswer1(), environment.getProperty(Properties.UCB_REWARDS_003_SEC_ANSWER));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswerConfirmation1(), environment.getProperty(Properties.UCB_REWARDS_003_SEC_ANSWER));

        this.securityInformationComponent.selectChallengeQuestion(securityInformationComponent.getChallengeQuestions2(), environment.getProperty(Properties.REG_SEC_QUESTION2));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswer2(), environment.getProperty(Properties.UCB_REWARDS_003_SEC_ANSWER));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswerConfirmation2(), environment.getProperty(Properties.UCB_REWARDS_003_SEC_ANSWER));

        this.securityInformationComponent.clickOnSubmitButton();
    }

    @When("I pass invalid values in security questions, answers and retype answers fields")
    public void iPassInvalidValuesInTheFields(){
        this.securityInformationComponent.selectChallengeQuestion(securityInformationComponent.getChallengeQuestions0(), environment.getProperty(Properties.ACCOUNT_TYPE_PRESELECTION));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswer0(), INVALID_ANSWER);
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswerConfirmation0(), INVALID_ANSWER);

        this.securityInformationComponent.selectChallengeQuestion(securityInformationComponent.getChallengeQuestions1(), environment.getProperty(Properties.ACCOUNT_TYPE_PRESELECTION));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswer1(), INVALID_ANSWER);
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswerConfirmation1(), INVALID_ANSWER);

        this.securityInformationComponent.selectChallengeQuestion(securityInformationComponent.getChallengeQuestions2(), environment.getProperty(Properties.ACCOUNT_TYPE_PRESELECTION));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswer2(), INVALID_ANSWER);
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswerConfirmation2(), INVALID_ANSWER);

        this.securityInformationComponent.clickOnSubmitButton();
    }

    @When("I pass valid value in security answer and invalid value in retype answer field")
    public void iPassValidSecurityQuestionInvalidRetypeAnswer(){
        this.securityInformationComponent.selectChallengeQuestion(securityInformationComponent.getChallengeQuestions0(), environment.getProperty(Properties.REG_SEC_QUESTION0));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswer0(), environment.getProperty(Properties.UCB_REWARDS_003_SEC_ANSWER));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswerConfirmation0(), INVALID_ANSWER);

        this.securityInformationComponent.selectChallengeQuestion(securityInformationComponent.getChallengeQuestions1(), environment.getProperty(Properties.REG_SEC_QUESTION1));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswer1(), environment.getProperty(Properties.UCB_REWARDS_003_SEC_ANSWER));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswerConfirmation1(), environment.getProperty(Properties.UCB_REWARDS_003_SEC_ANSWER));

        this.securityInformationComponent.selectChallengeQuestion(securityInformationComponent.getChallengeQuestions2(), environment.getProperty(Properties.REG_SEC_QUESTION2));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswer2(), environment.getProperty(Properties.UCB_REWARDS_003_SEC_ANSWER));
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswerConfirmation2(), environment.getProperty(Properties.UCB_REWARDS_003_SEC_ANSWER));

        this.securityInformationComponent.clickOnSubmitButton();
    }

    @When("I pass null values in security answers and retype security answers")
    public void iPassNullValues(){

        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswer0(), null);
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswerConfirmation0(), null);

        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswer1(), null);
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswerConfirmation1(), null);

        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswer2(), null);
        this.securityInformationComponent.inputChallengeAnswer(securityInformationComponent.getChallengeAnswerConfirmation2(), null);

        this.securityInformationComponent.clickOnSubmitButton();
    }
}
