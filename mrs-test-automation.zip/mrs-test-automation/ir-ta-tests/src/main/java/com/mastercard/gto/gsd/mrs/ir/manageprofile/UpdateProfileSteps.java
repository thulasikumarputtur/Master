package com.mastercard.gto.gsd.mrs.ir.manageprofile;

import com.mastercard.gto.gsd.mrs.ir.component.UpdateProfileComponent;
import com.mastercard.gto.gsd.mrs.ir.domain.CsfrToken;
import com.mastercard.gto.gsd.mrs.ir.page.ManageProfilePage;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static org.junit.Assert.assertTrue;

/**
 * Created by e054649 on 11/11/2016.
 */

@Component
public class UpdateProfileSteps {

    @Autowired
    private UpdateProfileComponent updateProfileComponent;

    @When("I input the values in the section for <userId> and <newPassword> and <retypeNewPassword>")
    public void iInputTheValuesInSection(@Named("userId") String userId, @Named("newPassword")String newPassword,
                                          @Named("retypeNewPassword")String retypeNewPassword){

        updateProfileComponent.typeUserId(userId);
        updateProfileComponent.typePassword(newPassword);
        updateProfileComponent.reTypePassword(retypeNewPassword);
    }

    @When("I click on the update profile submit button")
    public void iClickOnTheUpdateProfileSubmitButton(){
        updateProfileComponent.clickOnSubmitButton();
    }
}
