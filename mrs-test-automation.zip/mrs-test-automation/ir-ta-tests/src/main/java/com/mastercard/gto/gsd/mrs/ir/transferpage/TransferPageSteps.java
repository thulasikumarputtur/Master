package com.mastercard.gto.gsd.mrs.ir.transferpage;

import com.mastercard.gto.gsd.mrs.ir.component.PointBalanceComponent;
import com.mastercard.gto.gsd.mrs.ir.domain.CsfrToken;
import com.mastercard.gto.gsd.mrs.ir.domain.Properties;
import com.mastercard.gto.gsd.mrs.ir.page.TransferPointsPage;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import static org.junit.Assert.assertTrue;


/**
 * Created by e054649 on 6/12/2017.
 */
@Component
public class TransferPageSteps {

    @Autowired
    private Environment environment;

    @Autowired
    private TransferPointsPage transferPointsPage;

    @Autowired
    private PointBalanceComponent pointBalanceComponent;

    private int beforeTransferAmount;
    private int afterTransferAmount;

    @Given("I am on the transfer page")
    public void iAmOnTheTransferPage(){
        StringBuilder sb = new StringBuilder(environment.getProperty(Properties.URL_UCB_REWARDS_001));
        sb.append("/point-transfer?csrf_token=");
        sb.append(CsfrToken.getCrfsToken());

        transferPointsPage.navigateToLandingPageUrl(sb.toString());
        beforeTransferAmount = pointBalanceComponent.getPointBalanceAmount();
    }

    @When("I select the origin account $originAccount")
    public void iSelectTheOriginAccount(@Named("originAccount")String originAccount){
        this.transferPointsPage.selectOriginAccountNumber(originAccount);
    }

    @When("I select the transfer page account type $accountType")
    public void iSelectTheTransferPageAccountType(@Named("accountType")String accountType){
        this.transferPointsPage.selectRecipientAccountType(accountType);
    }

    @When("I input the recipient account number $recipientAccountNumber")
    public void iInputTheRecipientAccountNumber(@Named("recipientAccountNumber")String recipientAccountNumber){
        this.transferPointsPage.typeRecipientAccountNumber(recipientAccountNumber);
    }

    @When("I input the recipient last name $lastName")
    public void iInputRecipientLastName(@Named("lastName")String lastName){
        this.transferPointsPage.typeRecipientLastName(lastName);
    }

    @When("I click on transfer points next button")
    public void iClickOnTransferPointNextButton(){
        this.transferPointsPage.clickOnButtonNext();
    }

    @When("I input the transfer point amount $points")
    public void iInputTheTransferPointAmount(@Named("pointsToTransfer")String pointsToTransfer){
        this.transferPointsPage.typeTransferAmount(pointsToTransfer);
    }

    @When("I click on confirm transfer ok button")
    public void iClickOnConfirmTransferOkButton(){
        this.transferPointsPage.clickOnOkButton();
    }

    @Then("I will see the transfer complete message")
    public void iWillSeeTheTransferCompleteMessage(){
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String successfulMessage = "Your request has been performed successfully. Please see your Account Information to see the transfer detail.";

        System.out.println("System out: " + transferPointsPage.getTransferCompleteMessage().getText());
        assertTrue("I will see the transfer complete message", successfulMessage.equalsIgnoreCase(
                transferPointsPage.getTransferCompleteMessage().getText()));
    }

    @Then("I click on return to main page button")
    public void iClickOnReturnToMainPageButton(){
        this.transferPointsPage.clickOnReturnToMainPage();
        afterTransferAmount = this.pointBalanceComponent.getPointBalanceAmount();
    }

    @Then("I will see the points amount decrease by $pointsToTransfer")
    public void iWillSeeThePointsAmountDecrease(@Named("pointsToTransfer")String pointsToTransfer){
        assertTrue("I will see the points amount decrease by " + pointsToTransfer,
                (beforeTransferAmount - afterTransferAmount) == Integer.parseInt(pointsToTransfer));
    }
}
