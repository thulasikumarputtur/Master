package com.mastercard.gto.gsd.mrs.ir.rewardsummary;

import com.mastercard.gto.gsd.mrs.ir.domain.CsfrToken;
import com.mastercard.gto.gsd.mrs.ir.page.RewardSummaryPage;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 5/23/2017.
 */
@Component
public class RewardsSummarySteps {

    @Autowired
    private RewardSummaryPage rewardSummaryPage;


    @Given("User is on the rewards summary page $landingPageURL")
    public void userIsOnRewardsSummaryPage(@Named("landingPageURL") String landingPageURL) {

        StringBuilder sb = new StringBuilder(landingPageURL);
        sb.append("/my-points?csrf_token=");
        sb.append(CsfrToken.getCrfsToken());

        rewardSummaryPage.navigateToLandingPageUrl(sb.toString());
    }

    @Then("User should see the rewards summary sections")
    public void userShouldSeeRewardSummarySections(){
        rewardSummaryPage.isLoaded();
    }
}
