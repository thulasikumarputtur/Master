package com.mastercard.gto.gsd.mrs.ir.database;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

/**
 * Created by e054649 on 7/19/2017.
 */
public class DatabaseDataFactory {

    @Autowired
    Environment properties;

    public BasicDataSource getMRSDataSource() {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setMaxActive(1);

        dataSource.setDriverClassName(properties.getProperty("database.driver"));
        dataSource.setUrl(properties.getProperty("database.url"));
        dataSource.setUsername(properties.getProperty("database.user"));
        dataSource.setPassword(properties.getProperty("database.password"));

        return dataSource;
    }
}
