package com.mastercard.gto.gsd.mrs.ir.landing;

import static org.junit.Assert.assertTrue;

import org.jbehave.core.annotations.Then;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.gto.gsd.mrs.ir.page.LandingPage;

@Component
public class LandingComponentCheckSteps {

	@Autowired
	LandingPage landingPage;
	
	@Then("User should see the Top menu left links")
	public void userShouldSeeLeftMenu(){
		assertTrue("User sees the Top menu left links", landingPage.isTopNavItemsLeftDisplayed());
	}
	
	@Then("User should see the Top menu right links")
	public void userShouldSeeRightMenu(){
		assertTrue("User sees the Top menu right links", landingPage.isTopNavItemsRightDisplayed());
	}
	
	@Then("User should not see the Shop Catalog link")
	public void userShouldNotSeeShopCatalogLink(){
		assertTrue("User sees the catalog", !landingPage.isShopCatalogLinkDisplayed());
	}
	
	@Then("User should see the catalog")
	public void userShouldSeeCatalog(){
		assertTrue("User sees the catalog", landingPage.isCatalogListDisplayed());
	}
	
	@Then("User should not see the catalog")
	public void userShouldNotSeeCatalog(){
		assertTrue("User does not see the catalog", !landingPage.isCatalogListDisplayed());
	}
	
	@Then("User should see the catalog items")
	public void userShouldSeeCatalogItems(){
		assertTrue("User sees the catalog items", !landingPage.getItemList().getElements().isEmpty());
	}
	
	@Then("User should see the point value of catalog items")
	public void userShouldSeePointValues(){
		assertTrue("User sees the point value of items", landingPage.isItemPriceDisplayed());
	}
	
	@Then("User should not see the point value of catalog items")
	public void userShouldNotSeePointValues(){
		assertTrue("User does not see the point value of items", !landingPage.isItemPriceDisplayed());
	}
	
	@Then("User should see the see more link")
	public void userShouldSeeSeeMoreLink(){
		assertTrue("User sees the see more link", landingPage.getSeeMoreLink().isVisible());
	}
	
	
	
	// WHEN BACK TO LANDING PAGE
	@Then("User should see the landing page")
	public void userShouldSeeLandingPage(){
		assertTrue("User sees the Landing page", landingPage.isLoaded());
	}
}
