package com.mastercard.gto.gsd.mrs.ir.domain;

/**
 * Created by e054649 on 11/17/2016.
 */
public final class Properties {

    public static final String LANDING_PAGE_URL_TEST_AUTOMATION = "landingPageURLTestAutomation";

    public final static String REG_SEC_QUESTION0="regSecQuestion0";
    public final static String REG_ANSWER0="regAnswer0";
    public final static String REG_ANSWER0_CFM="regAnswer0Cfm";
    public final static String REG_FIRST_NAME = "regFirstName";
    public final static String REG_LAST_NAME = "regLastName";
    public final static String REG_COUNTRY = "regCountry";
    public final static String REG_ADDRESS1 = "regAddress1";
    public final static String REG_ADDRESS2 = "regAddress2";
    public final static String REG_CITY = "regCity";
    public final static String REG_STATE = "regState";
    public final static String REG_ZIP = "regZip";
    public final static String REG_BUSINESS_PHONE = "regBusPhone";
    public final static String REG_LOGIN_PHONE = "loginPhone";
    public final static String REG_FAX = "regFax";
    public final static String REG_SSN = "regSsn";
    public final static String REG_BIRTH = "loginBirthdate";

    public final static String REG_SEC_QUESTION1="regSecQuestion1";
    public final static String REG_ANSWER1="regAnswer1";
    public final static String REG_ANSWER1_CFM="regAnswer1Cfm";

    public final static String REG_SEC_QUESTION2="regSecQuestion2";
    public final static String REG_ANSWER2="regAnswer2";
    public final static String REG_ANSWER2_CFM="regAnswer2Cfm";

    public final static String ACCOUNT_TYPE_PRESELECTION = "accountTypePreSelection";

    public final static String NOTIFICATION_PREFERENCE_EMAIL="notificationPreferenceEmail";
    public final static String NOTIFICATION_PREFERENCE_MOBILE_NUMBER="notificationPreferenceMobileNumber";

    public final static String ACCOUNT_TYPE = "accountType";
    public final static String ACCOUNT_NUMBER = "accountNumber";
    public final static String ACCOUNT_NICKNAME = "accountNickname";

    public final static String URL_UCB_REWARDS_001 = "urlUcbRewards001";
    public final static String UCB_REWARDS_003_SEC_ANSWER = "ucbrewards003SecAnswer";
    public final static String UCB_GOOD_STANDING_LOGIN_FIRST_NAME = "goodStandingLoginFirstName";
    public final static String UCB_GOOD_STANDING_LOGIN_LAST_NAME = "goodStandingLoginLastName";
    public final static String UCB_LOGIN_SSN = "loginSSN";


}

