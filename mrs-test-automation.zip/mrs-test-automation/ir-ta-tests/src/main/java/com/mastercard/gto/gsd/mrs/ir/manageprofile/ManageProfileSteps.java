package com.mastercard.gto.gsd.mrs.ir.manageprofile;

import com.mastercard.gto.gsd.mrs.ir.domain.CsfrToken;
import com.mastercard.gto.gsd.mrs.ir.domain.Properties;
import com.mastercard.gto.gsd.mrs.ir.page.ManageProfilePage;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import static org.junit.Assert.assertTrue;

/**
 * Created by e054649 on 11/17/2016.
 */
@Component
public class ManageProfileSteps {

    @Autowired
    private ManageProfilePage manageProfilePage;
    @Autowired
    private Environment environment;

    @Given("I am on them update profile page")
    public void iAmLoggedOnTheMainPage(@Named("landingPageURL") String landingPageURL) {

        StringBuilder sb = new StringBuilder(landingPageURL);
        sb.append("/update-profile?csrf_token=");
        sb.append(CsfrToken.getCrfsToken());

        manageProfilePage.navigateToLandingPageUrl(sb.toString());
    }

    @Given("I am on the security information section")
    public void iAmOnTheSecurityInformationSection(){
        this.iAmLoggedOnTheMainPage(environment.getProperty(Properties.URL_UCB_REWARDS_001));
        this.manageProfilePage.getSecurityInformationSection().clickOnChildLink();
    }

    @Given("I am on the notification preference section")
     public void iAmOnTheNotificationPreferenceSection(){
        this.iAmLoggedOnTheMainPage(environment.getProperty(Properties.URL_UCB_REWARDS_001));
        this.manageProfilePage.getNotificationPreferenceSection().clickOnChildLink();
    }

    @Given("I am on the travel program section")
    public void iAmOnTheTravelProgramSection(){
        this.iAmLoggedOnTheMainPage(environment.getProperty(Properties.URL_UCB_REWARDS_001));
        this.manageProfilePage.getTravelProgramSection().clickOnChildLink();
    }

    @Given("I am on the card holder information section")
    public void iAmOnTheCardHolderInformationSection(){
        this.iAmLoggedOnTheMainPage(environment.getProperty(Properties.URL_UCB_REWARDS_001));
        this.manageProfilePage.getCardHolderInformation().clickOnChildLink();
    }

    @Then("I will see the successful message")
    public void iWillSuccessfulMessage() {
        assertTrue("I will see the successful message",
                this.manageProfilePage.getSuccessMessage().getText().equalsIgnoreCase("Your profile has been successfully updated."));
    }

    @Then("I will see the error message")
    public void iWillSeeTheErrorMessage() {
        assertTrue("I will see the error message", this.manageProfilePage.getErrorMessage().getText().equalsIgnoreCase("Please make sure your answers are valid for the highlighted fields below."));
    }
}
