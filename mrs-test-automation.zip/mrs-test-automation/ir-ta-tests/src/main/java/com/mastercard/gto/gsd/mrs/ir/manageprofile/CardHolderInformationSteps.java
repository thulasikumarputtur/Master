package com.mastercard.gto.gsd.mrs.ir.manageprofile;

import com.mastercard.gto.gsd.mrs.ir.component.CardHolderComponent;
import com.mastercard.gto.gsd.mrs.ir.domain.Properties;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * Created by e054649 on 12/15/2016.
 */
@Component
public class CardHolderInformationSteps {

    @Autowired
    private Environment environment;
    @Autowired
    private CardHolderComponent cardHolderComponent;

    private static final String INVALID = "@#_INVALID";

    @When("I pass valid values in card holder information section")
    public void iPassValidValuesCardHolder(){

        this.cardHolderComponent.typeFirstName(environment.getProperty(Properties.UCB_GOOD_STANDING_LOGIN_FIRST_NAME));
        this.cardHolderComponent.typeLastName(environment.getProperty(Properties.UCB_GOOD_STANDING_LOGIN_LAST_NAME));
        this.cardHolderComponent.selectCountry(environment.getProperty(Properties.REG_COUNTRY));
        this.cardHolderComponent.typeAddress1(environment.getProperty(Properties.REG_ADDRESS1));
        //this.cardHolderComponent.typeAddress2(environment.getProperty(Properties.REG_ADDRESS2));
        //this.cardHolderComponent.typeCity(environment.getProperty(Properties.REG_CITY));
        this.cardHolderComponent.typeState(environment.getProperty(Properties.REG_STATE));
        //this.cardHolderComponent.typeZip(environment.getProperty(Properties.REG_ZIP));
        this.cardHolderComponent.typeBusinessPhone(environment.getProperty(Properties.REG_LOGIN_PHONE));
        //this.cardHolderComponent.typeFaxNumber(environment.getProperty(Properties.REG_FAX));
        this.cardHolderComponent.typeSSN(environment.getProperty(Properties.UCB_LOGIN_SSN));
        this.cardHolderComponent.typeDateOfBirth(environment.getProperty(Properties.REG_BIRTH));

        this.cardHolderComponent.clickOnSubmitButton();
    }

    @When("I pass invalid values in card holder information section")
    public void iPassInvalidValuesCardHolder(){

        this.cardHolderComponent.typeFirstName(INVALID);
        this.cardHolderComponent.typeLastName(INVALID);
        //TODO this.cardHolderComponent.selectCountry(INVALID); Check best way to implement this
        this.cardHolderComponent.typeAddress1(INVALID);
        //this.cardHolderComponent.typeAddress2(INVALID);
        //this.cardHolderComponent.typeCity(INVALID);
        this.cardHolderComponent.typeState(INVALID);
        //this.cardHolderComponent.typeZip(INVALID);
        this.cardHolderComponent.typeBusinessPhone(INVALID);
        //this.cardHolderComponent.typeFaxNumber(INVALID);
        this.cardHolderComponent.typeSSN(INVALID);
        this.cardHolderComponent.typeDateOfBirth(INVALID);

        this.cardHolderComponent.clickOnSubmitButton();
    }
}
