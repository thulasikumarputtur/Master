package com.mastercard.gto.gsd.mrs.ir;

import org.jbehave.core.io.CodeLocations;
import org.jbehave.core.io.StoryFinder;

import java.util.List;

public class AllStories extends InternetRedemptionsStories {
	@Override
	public List<String> storyPaths() {
		List<String> paths = new StoryFinder().findPaths(
				CodeLocations.codeLocationFromClass(this.getClass()), "**/*.story", "");
		return paths;
	}
}