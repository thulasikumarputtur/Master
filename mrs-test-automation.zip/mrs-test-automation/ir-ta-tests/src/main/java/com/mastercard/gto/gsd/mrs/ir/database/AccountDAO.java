package com.mastercard.gto.gsd.mrs.ir.database;

/**
 * Created by e054649 on 7/19/2017.
 */
public interface AccountDAO {

    /**
     * Delete the account
     *
     * @param accountNumber
     */
    void deleteAccount(String accountNumber);
}
